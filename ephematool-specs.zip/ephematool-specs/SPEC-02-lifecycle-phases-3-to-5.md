# SPEC-02 — Lifecycle engine: Phases 3, 4, 5

Requirements covered: STAT-01/02/05/06, ENV-03 (P3) · STAT-03/04 (P4) · ENV-04…08 (P5). Roadmap success criteria are quoted as **SC**.
Reference code (compiled and tested in this bundle): `code/envstate`, `code/health`, `code/reaper`, `code/webhook`, `code/migrations`.

## Shared design rules
1. **One state machine, CAS only** (`envstate.Advance`). The reconciler, webhook worker, reaper, destroy handler and UI actions all call it; nobody writes `state` directly.
2. **Three observed sources, one verdict**: DB record, GitHub Actions run, Kubernetes. Observations are stored as *signals* with timestamps; the UI shows the verdict plus the signals (P4).
3. **Webhooks are hints, polling is truth.** Every webhook handler only enqueues `env:reconcile{id}`.
4. All new asynq tasks use `TaskID = <kind>:<env-id>` (dedupe), `Retention` ≥ 1 h, and carry the traceparent (existing tracing middleware).

---
## Phase 3 — Inventory, Lifecycle & Destroy

### P3.1 Inventory API & UI (SC1)
`GET /api/environments?state=&owner=&repo=&limit=&cursor=` — keyset pagination on `(created_at DESC, id)`, `next_cursor` opaque (base64 of the pair). Response items: `id, repo, ref, sha, pr_number, owner, url, state, expires_at, created_at, verdict` (P4 adds `verdict`). Index: `environments_owner_active` + a new `(created_at DESC, id)` index.
UI: table with filter chips for the six states; `data-testid=env-state`; empty/error/loading states; row → detail.
Tests: `test_list_filters_and_pagination` (ephematest), Go unit test for cursor encode/decode round-trip and tamper rejection (return 400).

### P3.2 Convergence after a missed webhook (SC2) — the reconciler
`env:reconcile` runs (a) when a webhook arrives, (b) on every `env:sweep` tick (`ENV_SWEEP_INTERVAL`), (c) after startup for every non-terminal env.
```
for env in non-terminal environments (batch, FOR UPDATE SKIP LOCKED, oldest-checked first):
    run = github.GetRun(env.run_id)                     # ETag conditional GET (D-16)
    switch:
      env.state == provisioning && run.completed && run.conclusion == success -> start probe loop (do NOT mark running yet)
      env.state == provisioning && run.completed && run.conclusion != success -> Advance(provisioning -> failed, reason=conclusion)
      env.state == provisioning && now > created+PROVISION_DEADLINE            -> Advance(-> failed, "deadline")
    env.last_reconciled_at = now
```
Acceptance (Go integration, fake GitHub): complete a run with **no** webhook delivered → env reaches `running`/`failed` within `2 × ENV_SWEEP_INTERVAL`. Add the `ephematest` variant by dropping deliveries with the fake's `POST /__fake/webhooks/pause`.

### P3.3 Failure drill-down (SC3)
`GET /api/environments/{id}/diagnostics` → `{ run_url, run_logs_url, jobs:[{name,conclusion,url}], k8s_events:[{at,type,reason,message,object}] }`.
* Run URLs are links, not proxied logs (GitHub requires auth for log download; link to `html_url`).
* K8s events: the API uses a **read-only** ServiceAccount restricted to `events`, `pods` get/list in namespaces labelled `ephematool.io/env-id`; cap at 50 events, newest first, messages truncated to 500 chars and passed through the secret redactor (SPEC-03 P7.4).
* Access: any session role may read (viewer included); events for a destroyed env are served from the stored last snapshot (`environment_diagnostics` jsonb column written when entering `failed`/`destroying`).

### P3.4 Destroy with confirmation (SC4)
`DELETE /api/environments/{id}` → **202**; body = env in `destroying`. Authorisation: owner or admin; viewers 403 (`test_viewer_cannot_destroy_someone_elses_env`). Idempotent: repeating returns 202/200 with the current record.
Worker `env:destroy`:
1. `Advance(running|failed|requested|provisioning → destroying)`; audit `destroy.request` (actor = user, or `system` for TTL/PR close).
2. Dispatch the teardown workflow **or** (kind v1) run the fenced provisioner `teardown.sh`; store `teardown_run_id`.
3. Poll the cluster: namespace `NotFound` **and** no PVs labelled with the env id → `Advance(destroying → destroyed)`. **The UI says "destroyed" only from this transition** (SC4). If the namespace is stuck `Terminating` > `DESTROY_DEADLINE` → keep `destroying`, raise `destroy_stuck` alert, show finalizers in diagnostics (never force-remove finalizers automatically).
4. UI confirmation: modal requiring the user to type the environment id (not "DELETE") — prevents wrong-row destroys.

### P3.5 Orphans (SC5)
`GET /api/orphans` (admin): namespaces matching `ephematool.io/managed=true` whose `env-id` is absent from the DB or whose env is `destroyed`. Implementation: `env:sweep` lists labelled namespaces (informer or list every sweep), diffs against `SELECT id FROM environments`, stores results in `orphan_findings(namespace, first_seen, last_seen)`. Actions: **report only** in P3; adoption/cleanup is a separate admin action `POST /api/orphans/{ns}/destroy` with confirmation, audited.
Acceptance: create a labelled namespace by hand → appears within one sweep; destroy the env record's namespace normally → never listed; `test_reconciler_finds_no_cluster_orphans` passes after a full ephematest run.

### P3 exit
`ephematest tests --expect-phase 3` green (list/pagination, destroy, idempotent destroy, owner authz, orphans, `test_destroy_leaves_no_orphan_namespace` on kind).

---
## Phase 4 — Live health & drift

### P4.1 Signals (collected by `env:probe`, every `ENV_PROBE_INTERVAL`, backing off to `ENV_PROBE_WINDOW`; steady-state every 60 s for running envs)
| Signal | Source | Never derived from |
|---|---|---|
| `RecordRunning` | DB `state` | — |
| `WorkflowSuccess` | Actions run conclusion | probe |
| `NamespaceExists` | kube API (Active) | DB |
| `WorkloadReady` | Deployments `availableReplicas == replicas` | probe |
| `ProbeOK` | HTTP GET through the gateway with a **platform probe token** (bypasses the interactive gate, never the env-bound check) expecting the template's `healthPath` 2xx within `ENV_PROBE_TIMEOUT` | workflow |

Store latest signals in `environment_signals(env_id, signal, value, observed_at)` (upsert) — not in `environments` (keeps the hot row small).

### P4.2 Verdict — use `code/health` verbatim
`health.Classify` implements SC1–SC3: workflow green + failing probe ⇒ `not_live`; record running + namespace gone ⇒ `drifted` with `conflicts:["record=running vs namespace=missing"]`; any unobserved required signal ⇒ `unchecked` (never `live`). `health.Debounce(history, 3)` prevents flapping: a single failed probe leaves the label unchanged, three consecutive flag it; recovery is immediate. 7 unit tests pass (`go test ./health`).
API: `GET /api/environments/{id}/health` → `{verdict, conflicts[], signals{…,observed_at}, reason}`; list items carry `verdict`.
UI: badge Live / Not live / Drifted / Unchecked; drifted rows expand to the conflicting signals with timestamps.
**Drift is reported, never auto-repaired** in P4 (auto-heal is a P7+ option behind an admin setting).

### P4.3 Metrics/alerts (feeds SPEC-04 P-09)
`ephematool_env_verdict{verdict}` gauge (count of envs per verdict — bounded cardinality: no env id label, see cardinality pitfall), `ephematool_env_drifted_seconds` histogram, alert on `drifted > 0 for 15m`.

### P4 exit
`ephematest --expect-phase 4`: `test_health_reports_probe_and_workflow_signals`, `test_failed_env_is_never_reported_healthy`; plus a kind test that deletes the namespace out-of-band and expects `drifted` within 2 probe cycles.

---
## Phase 5 — TTL, extension, auto-teardown

### P5.1 Mandatory expiry (SC1)
Create sets `expires_at = now + ttl` (default `ENV_DEFAULT_TTL`, hard cap `ENV_MAX_LIFETIME` from `created_at`) via `reaper.Policy.NewExpiry`. The column is `NOT NULL` + CHECK (already in migration 00002). Inventory shows a countdown.

### P5.2 Reaper — exactly once across restarts (SC1, SC3)
No in-memory timers. `env:sweep` (every `ENV_SWEEP_INTERVAL`, leader-independent) runs the claim statement documented in `code/reaper/ttl.go`:
```sql
WITH due AS (SELECT id FROM environments WHERE state IN ('running','failed') AND expires_at <= now()
             ORDER BY expires_at LIMIT $1 FOR UPDATE SKIP LOCKED)
UPDATE environments e SET state='destroying', state_version=state_version+1, updated_at=now()
  FROM due WHERE e.id=due.id RETURNING e.id;
```
**Verified on Postgres 16:** 20 due rows, 8 concurrent claimers, batches of 4 → 20 claimed, 20 unique (no duplicates, none missed). For each returned id, in the same transaction: audit `ttl.expired`, then enqueue `env:destroy` with `TaskID=destroy:<id>` (duplicate enqueue is a no-op). A restart mid-expiry just re-runs the sweep: rows already `destroying` are not re-claimed, and a lost enqueue is repaired by the P3 reconciler (it re-enqueues destroy for `destroying` rows idle > 2 min).

### P5.3 Extension with cap (SC2)
`POST /api/environments/{id}/extend {ttl_seconds}` → 200 with new `expires_at`; 422 for non-positive/over-per-extension; 409 when not running or already expired; 422 `cap_exceeded` when `new_expiry − created_at > ENV_MAX_LIFETIME` (cap on **total** lifetime, so repeated small extensions can't evade it — `reaper.Policy.Extend`, tests pass). SQL is optimistic and loses cleanly against the reaper:
```sql
UPDATE environments SET expires_at=$2, ttl_extensions=ttl_extensions+1, updated_at=now()
 WHERE id=$1 AND state='running' AND expires_at > now() AND expires_at=$3;   -- rows=0 => 409
```
Authorisation: owner or admin. Audit `ttl.extend` with old/new expiry.

### P5.4 PR close → teardown (SC4) — needs the webhook receiver (SPEC-04 P-06)
`pull_request` events with `action in (closed)` (merged or not) enqueue `env:destroy` for every non-terminal env with `(repo, pr_number)` (index exists). Also handled by the reconciler: each sweep lists open PR state for envs with a `pr_number` (ETag) so a lost webhook still tears down within one sweep. Fork PRs: environments are never created from fork refs (pitfall 7/8), so no special case at close.

### P5.5 Pre-expiry PR comment (SC5)
`reaper.NeedsWarning(expires, now, ENV_WARN_WINDOW, expiry_warned_at != nil)`; claim with `UPDATE … SET expiry_warned_at=now() WHERE id=$1 AND expiry_warned_at IS NULL RETURNING id` and only the winner posts the comment (idempotent). Comment body: URL, expiry (UTC + relative), link to extend in the dashboard. Extending clears `expiry_warned_at` so a new warning is possible. If the env has no PR, skip.

### P5 exit
`ephematest --expect-phase 5`: `test_ttl_expiry_destroys_environment`, `test_extend_before_expiry_prevents_destroy`, `test_extend_ttl_and_cap`; restart test `test_restart_during_provisioning_still_converges`; Go test: kill the worker (`docker compose kill worker`) with 5 envs expiring, restart, assert each destroyed exactly once (count `ttl.expired` audit rows == 5).
