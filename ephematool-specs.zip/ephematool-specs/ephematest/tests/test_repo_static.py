"""Repo-level conformance (no running stack): hygiene, drift, supply chain, production readiness.
Run with --repo-root /path/to/ephematool."""
import json, re, subprocess
from pathlib import Path
import pytest
import yaml

pytestmark = pytest.mark.requires("repo")


@pytest.fixture(scope="module")
def root(settings) -> Path: return Path(settings.repo_root)


def files(root, *globs):
    out = []
    for g in globs:
        out += [p for p in root.glob(g) if p.is_file() and ".git/" not in str(p) and "node_modules" not in str(p)]
    return out


# ------------------------------------------------------------- Phase 1 invariants
@pytest.mark.phase(1)
def test_migrations_are_contiguous_and_paired(root):
    mig = sorted((root / "internal/store/migrations").glob("*.sql"))
    assert mig, "no migrations"
    nums = [int(re.match(r"(\d+)_", m.name).group(1)) for m in mig]
    assert nums == list(range(1, len(nums) + 1)), f"migration numbering gap: {nums}"
    for m in mig:
        t = m.read_text()
        assert "-- +goose Up" in t, f"{m.name} lacks goose Up"
        assert "-- +goose Down" in t, f"{m.name} lacks goose Down (rollback story)"


@pytest.mark.phase(1)
def test_d09_prefixes_only_in_generated_files(root):
    """Port of scripts/verify.d/conventions.sh."""
    bad = []
    for p in files(root, "cmd/**/*.go", "internal/**/*.go", "web/src/**/*.ts", "web/src/**/*.tsx", "deploy/**/*.yaml", "deploy/**/*.json"):
        n = str(p)
        if ".gen." in n or n.endswith("_test.go") or n.endswith("conventions/telemetry.json"): continue
        t = p.read_text(errors="ignore")
        if "ephematool.io/" in t or "ephematool.env." in t: bad.append(str(p.relative_to(root)))
    assert not bad, f"hand-written D-09 prefixes: {bad}"


@pytest.mark.phase(1)
def test_openapi_is_valid_and_paths_documented(root):
    spec = json.loads((root / "api/openapi.json").read_text())
    assert spec["openapi"].startswith("3.")
    for path in ("/api/status", "/api/me", "/api/auth/config", "/api/auth/logout"):
        assert path in spec["paths"], f"{path} missing from api/openapi.json"


@pytest.mark.phase(1)
def test_compose_declares_all_ten_status_services(root):
    c = yaml.safe_load((root / "deploy/compose.yaml").read_text())
    for svc in ("api", "worker", "postgres", "redis", "otel-collector", "tempo", "loki", "prometheus", "grafana"):
        assert svc in c["services"], f"compose lacks {svc}"


@pytest.mark.phase(1)
def test_collector_config_has_three_signal_pipelines(root):
    c = yaml.safe_load((root / "deploy/otel/collector.yaml").read_text())
    pipes = c["service"]["pipelines"]
    kinds = {name.split("/")[0] for name in pipes}      # pipelines may be named e.g. traces/platform
    assert {"traces", "metrics", "logs"} <= kinds, f"pipelines: {sorted(pipes)}"
    assert "memory_limiter" in json.dumps(pipes), "collector pipelines need a memory_limiter processor"


@pytest.mark.phase(1)
def test_no_secrets_committed(root):
    tracked = subprocess.run(["git", "-C", str(root), "ls-files"], capture_output=True, text=True).stdout.split()
    assert ".env" not in tracked, ".env is tracked"
    pat = re.compile(r"(ghp_[A-Za-z0-9]{36}|github_pat_[A-Za-z0-9_]{50,}|-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----|AKIA[0-9A-Z]{16})")
    hits = [f for f in tracked if (root / f).is_file() and (root / f).stat().st_size < 1_000_000
            and pat.search((root / f).read_text(errors="ignore"))]
    assert not hits, f"secret-looking material in: {hits}"


@pytest.mark.phase(1)
def test_env_example_covers_every_config_variable(root):
    cfg = (root / "internal/config/config.go").read_text()
    names = set(re.findall(r'env:"([A-Z0-9_]+)', cfg)) or set(re.findall(r'"([A-Z][A-Z0-9_]{3,})"', cfg))
    example = (root / ".env.example").read_text()
    missing = sorted(n for n in names if n not in example)
    assert not missing, f".env.example lacks: {missing}"


# ------------------------------------------------------------- Phase 2 invariants
@pytest.mark.phase(2)
def test_config_validate_checks_every_probe_setting(root):
    """Regression for the defect found in review: PROBE_TIMEOUT missing from validate.go `checks`."""
    v = (root / "internal/config/validate.go").read_text()
    m = re.search(r"checks\s*:?=\s*\[\][^{]*\{(.*?)\n\t\}", v, re.S)
    assert m, "checks slice not found in validate.go"
    assert re.search(r"\bc\.ProbeTimeout\b", m.group(1)), "PROBE_TIMEOUT is not in the positive-duration checks slice"


@pytest.mark.phase(2)
def test_audit_events_table_is_append_only(root):
    sql = "\n".join(p.read_text() for p in (root / "internal/store/migrations").glob("*.sql"))
    assert "audit_events" in sql
    assert re.search(r"(BEFORE\s+(UPDATE|DELETE).*audit_events|REVOKE\s+(UPDATE|DELETE).*audit_events)", sql, re.S | re.I), \
        "no trigger/REVOKE protecting audit_events from UPDATE/DELETE"


@pytest.mark.phase(2)
def test_environments_state_has_check_constraint(root):
    sql = "\n".join(p.read_text() for p in (root / "internal/store/migrations").glob("*.sql"))
    assert "environments" in sql and re.search(r"CHECK\s*\(\s*state\s+IN", sql, re.I), "environments.state lacks a CHECK"


# ------------------------------------------------------------- Phase 7 / productionization
@pytest.mark.phase(7)
def test_ci_workflow_exists_and_runs_verification(root):
    wf = list((root / ".github/workflows").glob("*.y*ml"))
    assert wf, "no GitHub Actions workflow (SPEC-04 P-01)"
    body = "\n".join(p.read_text() for p in wf)
    for needle in ("go test", "bazel", "npm"):
        assert needle in body, f"CI does not run '{needle}'"


@pytest.mark.phase(7)
def test_images_are_pinned_not_latest(root):
    bad = []
    for p in files(root, "deploy/**/*.yaml", "deploy/**/*.yml", "Dockerfile", "web/Dockerfile"):
        for line in p.read_text().splitlines():
            m = re.match(r"\s*(image:|FROM)\s+(\S+)", line)
            if m and (m.group(2).endswith(":latest") or (":" not in m.group(2) and "$" not in m.group(2) and m.group(2) != "scratch")):
                bad.append(f"{p.relative_to(root)}: {line.strip()}")
    assert not bad, bad


@pytest.mark.phase(7)
def test_dockerfiles_run_as_non_root(root):
    bad = [str(p.relative_to(root)) for p in files(root, "Dockerfile", "web/Dockerfile", "**/Dockerfile")
           if not re.search(r"^USER\s+(?!root)", p.read_text(), re.M)]
    assert not bad, f"no non-root USER in: {bad}"


@pytest.mark.phase(7)
def test_production_deploy_artifact_exists(root):
    assert (root / "deploy/helm/ephematool/Chart.yaml").exists() or (root / "deploy/k8s").exists(), "no production deploy manifests (SPEC-04 P-03)"


@pytest.mark.phase(7)
def test_http_server_has_full_timeouts(root):
    src = (root / "cmd/api/main.go").read_text()
    for t in ("ReadTimeout", "WriteTimeout", "IdleTimeout"):
        assert t in src, f"http.Server missing {t} (slowloris)"


@pytest.mark.phase(7)
def test_docs_are_not_stale(root):
    claude = (root / "CLAUDE.md").read_text()
    assert not re.search(r"Fastify|Drizzle|pg-boss", claude), "CLAUDE.md describes a stack the repo does not use (Go)"
    assert (root / "docs").is_dir() and (root / "SECURITY.md").exists(), "docs/ and SECURITY.md missing"
