package envstate

import (
	"context"
	"errors"
	"sync"
	"sync/atomic"
	"testing"
)

type memStore struct {
	mu     sync.Mutex
	state  State
	events []string
}

func (m *memStore) CAS(_ context.Context, _ string, from, to State, actor, reason string) (bool, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if m.state != from {
		return false, nil
	}
	m.state = to
	m.events = append(m.events, string(from)+">"+string(to))
	return true, nil
}

func TestEdges(t *testing.T) {
	legal := [][2]State{{Requested, Provisioning}, {Provisioning, Running}, {Provisioning, Failed}, {Running, Destroying}, {Failed, Destroying}, {Destroying, Destroyed}}
	for _, e := range legal {
		if !CanTransition(e[0], e[1]) {
			t.Errorf("%s->%s should be legal", e[0], e[1])
		}
	}
	illegal := [][2]State{{Running, Provisioning}, {Running, Requested}, {Destroyed, Running}, {Failed, Running}, {Destroying, Running}, {Requested, Running}}
	for _, e := range illegal {
		if CanTransition(e[0], e[1]) {
			t.Errorf("%s->%s should be illegal", e[0], e[1])
		}
	}
}

func TestEveryStateEventuallyReachesDestroyed(t *testing.T) {
	for s := range edges {
		seen, stack := map[State]bool{}, []State{s}
		ok := s == Destroyed
		for len(stack) > 0 && !ok {
			c := stack[len(stack)-1]
			stack = stack[:len(stack)-1]
			if seen[c] {
				continue
			}
			seen[c] = true
			for _, n := range edges[c] {
				if n == Destroyed {
					ok = true
				}
				stack = append(stack, n)
			}
		}
		if !ok {
			t.Errorf("%s can never reach destroyed (leak by construction)", s)
		}
	}
}

func TestAdvanceIllegalAndUnknown(t *testing.T) {
	m := &memStore{state: Running}
	if err := Advance(context.Background(), m, "x", Running, Provisioning, "t", ""); !errors.Is(err, ErrIllegalTransition) {
		t.Fatalf("got %v", err)
	}
	if err := Advance(context.Background(), m, "x", "bogus", Running, "t", ""); !errors.Is(err, ErrIllegalTransition) {
		t.Fatalf("got %v", err)
	}
}

// Exactly one of N concurrent actors (webhook, reaper, SRE click, poller) wins the same transition.
func TestConcurrentAdvanceHasExactlyOneWinner(t *testing.T) {
	m := &memStore{state: Running}
	var wins, losses int32
	var wg sync.WaitGroup
	for i := 0; i < 64; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			switch err := Advance(context.Background(), m, "x", Running, Destroying, "t", ""); {
			case err == nil:
				atomic.AddInt32(&wins, 1)
			case errors.Is(err, ErrLostRace):
				atomic.AddInt32(&losses, 1)
			default:
				t.Error(err)
			}
		}()
	}
	wg.Wait()
	if wins != 1 || losses != 63 || len(m.events) != 1 {
		t.Fatalf("wins=%d losses=%d events=%v", wins, losses, m.events)
	}
}
