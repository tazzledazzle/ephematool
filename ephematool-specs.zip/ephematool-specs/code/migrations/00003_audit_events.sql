-- +goose Up
-- Append-only audit log, enforced by the DATABASE (D-19/D-24): the runtime role can only INSERT/SELECT and a
-- trigger rejects UPDATE/DELETE/TRUNCATE even for the table owner. Migrations run as the owner role; the app
-- connects as ephematool_app.
CREATE TABLE audit_events (
    seq         bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    at          timestamptz NOT NULL DEFAULT now(),
    actor       text        NOT NULL,              -- login, or 'system'
    action      text        NOT NULL,              -- env.create, env.denied, provision.ok, ttl.expired, destroy.request, ...
    env_id      text,                              -- no FK: the log must survive environment deletion
    from_state  text,
    to_state    text,
    reason      text,
    trace_id    text,
    detail      jsonb       NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX audit_events_env ON audit_events (env_id, seq);

-- +goose StatementBegin
CREATE FUNCTION audit_events_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'audit_events is append-only (% blocked)', TG_OP USING ERRCODE = 'insufficient_privilege';
END $$;
-- +goose StatementEnd
CREATE TRIGGER audit_events_no_update BEFORE UPDATE OR DELETE ON audit_events
    FOR EACH ROW EXECUTE FUNCTION audit_events_immutable();
CREATE TRIGGER audit_events_no_truncate BEFORE TRUNCATE ON audit_events
    FOR EACH STATEMENT EXECUTE FUNCTION audit_events_immutable();

-- Runtime role: created by deploy (password from a secret); privileges granted here if it exists.
-- +goose StatementBegin
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'ephematool_app') THEN
        GRANT SELECT, INSERT ON audit_events TO ephematool_app;
        GRANT USAGE ON SEQUENCE audit_events_seq_seq TO ephematool_app;
        GRANT SELECT, INSERT, UPDATE ON environments TO ephematool_app;    -- no DELETE: environments are tombstoned, not removed
    END IF;
END $$;
-- +goose StatementEnd

-- +goose Down
DROP TRIGGER audit_events_no_truncate ON audit_events;
DROP TRIGGER audit_events_no_update ON audit_events;
DROP FUNCTION audit_events_immutable();
DROP TABLE audit_events;
