-- +goose Up
-- Environments: one row per preview environment. `state` is changed ONLY via compare-and-set (internal/envstate).
CREATE TABLE environments (
    id               text PRIMARY KEY CHECK (id ~ '^pv-[a-z0-9]{10}$'),          -- server-generated; becomes namespace + host label (D-03)
    owner_login      text        NOT NULL,
    repo             text        NOT NULL CHECK (repo ~ '^[A-Za-z0-9-]+/[A-Za-z0-9_.-]+$'),
    ref              text        NOT NULL,
    sha              text        NOT NULL CHECK (sha ~ '^[0-9a-f]{40}$'),         -- resolved at create time, never a moving ref
    pr_number        integer,
    template         text        NOT NULL,
    template_values  jsonb       NOT NULL DEFAULT '{}'::jsonb,                    -- validated against values.schema.json; secrets only as {"secretRef": name}
    state            text        NOT NULL DEFAULT 'requested'
                     CHECK (state IN ('requested','provisioning','running','failed','destroying','destroyed')),
    state_version    bigint      NOT NULL DEFAULT 0,
    failure_reason   text,
    run_id           bigint,                                                      -- GitHub Actions run (D-15 correlation)
    url              text,
    created_at       timestamptz NOT NULL DEFAULT now(),
    updated_at       timestamptz NOT NULL DEFAULT now(),
    expires_at       timestamptz NOT NULL,
    ttl_extensions   integer     NOT NULL DEFAULT 0,
    expiry_warned_at timestamptz,
    CHECK (expires_at > created_at),
    CHECK (state <> 'running' OR url IS NOT NULL)
);
CREATE INDEX environments_owner_active ON environments (owner_login) WHERE state NOT IN ('failed','destroyed');
CREATE INDEX environments_repo_active  ON environments (repo)        WHERE state NOT IN ('failed','destroyed');
CREATE INDEX environments_expiry       ON environments (expires_at)   WHERE state IN ('running','failed');
CREATE INDEX environments_pr           ON environments (repo, pr_number) WHERE pr_number IS NOT NULL AND state NOT IN ('destroying','destroyed');

-- +goose Down
DROP TABLE environments;
