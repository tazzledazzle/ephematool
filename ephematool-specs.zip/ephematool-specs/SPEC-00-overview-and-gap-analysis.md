# SPEC-00 — Ephematool: Gap Analysis, Sequencing and Decisions

Repo reviewed: `tazzledazzle/ephematool` (clone of default branch, `.planning/STATE.md` dated 2026-10-12).
Method: read README/CLAUDE.md/.planning (PROJECT, REQUIREMENTS, ROADMAP, STATE, research, Phase 1 and 2 context/plans/reviews) and the code and deploy tree, then ran the new `ephematest` repo checks against the checkout (results in §3).
**Limitation:** the sandbox had no route to the Go module proxy, so Go unit/integration tests and the docker/kind stack were *not* run. Everything about runtime behaviour is from reading code and plans, not from executing them.

## 1. What Ephematool is
An SRE dashboard to create, observe and destroy ephemeral preview environments (K8s namespaces provisioned by GitHub Actions `workflow_dispatch`), OpenTelemetry-first. Stack: Go (huma API, asynq/Redis worker, Postgres + goose + sqlc + pgx, scs sessions), GitHub OAuth (PKCE + org/team allowlist), React 19/Vite SPA behind nginx, Bazel bzlmod build, docker-compose dev stack (OTel Collector, Tempo, Loki, Prometheus, Grafana).

## 2. Where it actually stands

| Area | State | Evidence |
|---|---|---|
| Phase 1 — telemetry spine + GitHub login | **Built**; human UAT with a real GitHub OAuth App still open (issues #1, #2) | `internal/auth`, `internal/status`, `deploy/`, `scripts/verify.d/*`, STATE.md |
| Phase 2 — secure preview environment | **Designed (17 plans), essentially unexecuted** — only the config contract from plan 02-02 is visible in code; no env tables, no create API, no worker handlers, no UI | `cmd/worker/main.go` only runs ping/heartbeat; `internal/store/migrations` has only users; 17 PLAN.md files, no SUMMARYs |
| Phases 3–7 | **Roadmap only**, no plans (`Plans: TBD`) | ROADMAP.md |
| Production readiness | **Not scoped by any phase** (CI, deploy manifests, HA, backups, security headers, runbooks…) | no `.github/`, no `deploy/helm|k8s`, no docs/ |

Roadmap numbering used everywhere below: P1 Telemetry+Login · P2 Create secure env · P3 Inventory/Lifecycle/Destroy · P4 Live health + drift · P5 TTL/extension/auto-teardown · P6 Per-env telemetry views · P7 Quota & secrets guardrails.

## 3. Defects and drift found (verified)

`ephematest` repo tests were run against the checkout at `--expect-phase 7`: **8 failed, 8 passed**. The failures are real gaps:

| ID | Finding | Verified by | Fix in |
|---|---|---|---|
| D-1 | `CLAUDE.md` still describes TypeScript/Fastify/Drizzle/pg-boss; the code is Go. GSD tooling that reads it will mislead agents | `test_docs_are_not_stale` | SPEC-04 P-10 |
| D-2 | `internal/config/validate.go`: `PROBE_TIMEOUT` is missing from the positive-duration `checks` slice (it is only used in a relational check) | `test_config_validate_checks_every_probe_setting` | SPEC-01 §A1 |
| D-3 | Same file: stale "Rule group … TODO" comments that no longer match the code; error text `ENV_PROBE_TIMEOUT must be < ENV_PROBE_INITIAL` names a variable that does not exist (it is `ENV_PROBE_INTERVAL`) | read | SPEC-01 §A1 |
| D-4 | `cmd/api/main.go` sets only `ReadHeaderTimeout`; no Read/Write/Idle timeouts (slowloris; backlog #9) | `test_http_server_has_full_timeouts` | SPEC-04 P-05 |
| D-5 | `web/Dockerfile` final stage is `nginx:alpine` running as root (the Go image is correctly `distroless:nonroot`) | `test_dockerfiles_run_as_non_root` | SPEC-04 P-05 |
| D-6 | No CI workflow at all; `bazel run //:verify` is manual | `test_ci_workflow_exists…` | SPEC-04 P-01 |
| D-7 | No production deploy artifact (Helm/Kustomize) — compose only | `test_production_deploy_artifact_exists` | SPEC-04 P-03 |
| D-8 | No `docs/`, no `SECURITY.md`; README is PROJECT.md + ARCHITECTURE.md + runbook concatenated | `test_docs_are_not_stale` | SPEC-04 P-10 |
| D-9 | No `environments` / `audit_events` migrations yet; the append-only audit design (app role + triggers) is not in the schema | `test_audit_events_table_is_append_only`, `…state_has_check_constraint` | SPEC-01 §B |
| D-10 | Migrate-on-start has no cross-replica lock (backlog #4) — unsafe before any rolling deploy | read | SPEC-01 §A2 |
| D-11 | Go module path is `github.com/ephematool/ephematool` but the repo lives at `github.com/tazzledazzle/ephematool` — `go install`/vanity imports will not resolve | read | SPEC-04 P-12 |

Passing checks (good news): migrations are contiguous and have Down sections, D-09 prefix gate holds, OpenAPI lists the Phase 1 operations, the collector has all three pipelines with a memory limiter, no secrets are committed, images are pinned.

## 4. Gap register

Priority: **M** must-have to ship, **S** should, **C** could. "Spec" points to the document that fully specifies it.

| # | Gap | Pri | Spec |
|---|---|---|---|
| G-01 | Finish Phase 2: env/audit schema, role resolver, GitHub App client, template catalog, preview auth, create API, worker state machine, collector slot, kind cluster, UI, audit/preview pages, runner runbook | M | SPEC-01 |
| G-02 | Phase 1 hardening backlog (WR-01…WR-10, IN-xx, issues #3–#14) | M | SPEC-01 §A |
| G-03 | Inventory, GitHub-Actions/K8s-event drill-down, destroy with confirmation, orphan detection, webhook-miss convergence | M | SPEC-02 §P3 |
| G-04 | Real health probe + drift detection (signal reconciliation) | M | SPEC-02 §P4 |
| G-05 | TTL reaper (exactly-once across restarts), extension cap, PR-close teardown, pre-expiry PR comment | M | SPEC-02 §P5 |
| G-06 | Per-env telemetry views, Grafana deep links, time-to-ready trends | S | SPEC-03 §P6 |
| G-07 | Atomic quotas, secrets-by-reference, prod-data refusal | M | SPEC-03 §P7 |
| G-08 | CI/CD pipeline, release/versioning, SBOM + signing, dependency scanning | M | SPEC-04 P-01/P-02 |
| G-09 | Production deployment (Helm chart), HA topology, PDBs, HPA, NetworkPolicies, managed Postgres/Redis | M | SPEC-04 P-03/P-04 |
| G-10 | Runtime hardening: server timeouts, security headers + CSP, Redis auth/persistence, Grafana anon role, non-root web image, rate limiting | M | SPEC-04 P-05 |
| G-11 | GitHub webhook receiver (HMAC) + reconciliation fallback | M | SPEC-04 P-06 |
| G-12 | Health/readiness/liveness endpoints; graceful shutdown; migration job | M | SPEC-04 P-07 |
| G-13 | Backups/DR for Postgres + Redis; retention policy for Tempo/Loki/Prom (backlog #6) | S | SPEC-04 P-08 |
| G-14 | Platform SLOs, alert rules, runbooks, on-call docs | S | SPEC-04 P-09 |
| G-15 | Docs: split README, ADRs, SECURITY.md, contributor guide, fix CLAUDE.md | M | SPEC-04 P-10 |
| G-16 | Remote-cluster support via OIDC (deferred D-02) | C | SPEC-04 P-11 |
| G-17 | Test coverage beyond Phase 1 verify scripts: conformance, fault injection, load | M | SPEC-05 + `ephematest/` |

## 5. Sequencing

```
Wave 0  (days)    D-1..D-3 doc/config fixes · CI skeleton (P-01) · ephematest wired into CI (Phase-1 gate)
Wave 1  (P2)      SPEC-01 §A hardening  →  §B schema/audit  →  §C GitHub App + templates + preview auth
                  →  §D create API + worker  →  §E kind + collector  →  §F UI  →  §G runbook/UAT
Wave 2  (P3-P5)  SPEC-02: inventory/destroy/orphans → health+drift → TTL/extend/PR-close
Wave 3  (P6-P7)  SPEC-03: telemetry views → quotas/secrets
Wave 4  (prod)   SPEC-04: Helm, HA, webhooks, observability of the platform itself, DR, docs
(Continuous)      ephematest: raise `--expect-phase` as each phase lands; a PR that regresses an earlier phase fails CI
```
Hard ordering constraints: migration lock (D-10) and server timeouts (D-4) **before** Phase 2 deploys; the append-only audit role split **before** any code writes audit rows; webhook receiver (G-11) **after** the reconciliation loop of P3 so webhooks stay an optimisation, never the source of truth (pitfall: webhook unreliability).

## 6. Decisions needed from you (defaults chosen so work can proceed)

1. **Production target for the platform itself**: default = Kubernetes (Helm chart) with managed Postgres/Redis. Alternative = single VM with compose. (SPEC-04 assumes K8s.)
2. **Remote clusters**: default = keep kind + self-hosted runner for v1.0; OIDC remote cluster stays P-11 (optional).
3. **Env ID format**: plans fix `pv-<10 chars>`; `ephematest` accepts any DNS label via `EPHEMA_ENV_ID_RE`.
4. **GitHub Go module path** (D-11): rename module to the real repo path (default) or keep.
5. **GSD workflow**: CLAUDE.md requires edits to go through `/gsd-*` commands. These specs are inputs to `/gsd-plan-phase`; nothing here was applied to the repo.

## 7. Companion artifacts (all in this bundle)

| Path | What | Verified how |
|---|---|---|
| `SPEC-01 … SPEC-04` | Implementation specs | — |
| `SPEC-05-ephematest.md` + `ephematest/` | Test tool with full code, mock stack, fault-injection self-test | Baseline 73 pass; 17/17 injected faults detected; repo tests run against the real checkout |
| `code/` | Reference Go cores (state machine, TTL, quota, drift, webhook) with tests; SQL migrations | `go vet` + `go test -race` pass; SQL applied on a real Postgres 16 incl. concurrency experiments |

Not verified (no network/cluster in the sandbox): the Go build of the real repo, docker-compose stack, kind, GitHub Actions, real GitHub App.
