# SPEC-05 — `ephematest`: supporting test tool (full code)

A Python/pytest conformance tool that tests every layer of Ephematool: **black-box API**, **observability (Tempo/Loki/Prometheus)**, **repo/static production-readiness**, **ops/resilience (docker compose, kubectl)**, **concurrency/load**. It is phase-aware so it is useful from today (Phase 1) to v1.0 (Phase 7), and it proves its own tests work through a fault-injecting mock.

## 1. Design principles
1. **Phase gating, not skipping.** `--expect-phase N`: tests for phases ≤ N must pass; later tests run and are non-strict `xfail` (an XPASS tells you the feature landed early — raise N). A regression in an earlier phase fails CI.
2. **Missing capability = failure.** No docker/kubectl/observability/repo ⇒ the test **fails** (`--allow-missing-caps` downgrades to an explicit xfail with the reason). This is backlog #13 applied to the test tool itself.
3. **Black-box first.** API tests only use HTTP and the fake-GitHub OAuth flow (same steps as `scripts/lib/verify-lib.sh`); ops tests shell out to `docker compose`/`kubectl`.
4. **Every test is attributable.** Designated detectors carry `@pytest.mark.fault("<name>")`; `selftest.py` injects each fault into the mock and requires the detector to fail.
5. **Quota tests are isolated** (`--quota-mode`) because they need a low per-user limit while the rest of the suite needs headroom.

## 2. Layout
```
ephematest/
  pyproject.toml  README.md  selftest.py
  ephematest/   config.py  clients.py  plugin.py  cli.py        # settings, HTTP+obs clients, pytest plugin
  tests/        test_p1_auth  test_p1_status  test_p1_observability
                test_p2_environments  test_p2_audit_preview
                test_p3_to_p7  test_concurrency_load
                test_repo_static  test_stack_ops
  mockstack/    server.py                                         # single-process mock + 17 injectable faults
```

## 3. Setup and use
```bash
python3 -m venv .venv && . .venv/bin/activate && pip install -e ./ephematest
python ephematest/selftest.py                     # no infrastructure needed; proves the tool works
bazel run //:up_fake                              # the repo's dev stack with the fake GitHub
ephematest tests --expect-phase 1 --repo-root .   # today
ephematest tests --expect-phase 7 --repo-root .   # the v1.0 target (expect failures until built)
EPHEMA_MAX_PER_USER=3 ephematest tests --quota-mode   # stack started with ENV_MAX_PER_USER=3
```
Environment variables (defaults in `config.py`): `API_URL TEMPO_URL LOKI_URL PROM_URL GRAFANA_URL EPHEMA_ADMIN_LOGIN EPHEMA_VIEWER_LOGIN EPHEMA_OUTSIDER_LOGIN EPHEMA_ALLOWED_REPO EPHEMA_DENIED_REPO EPHEMA_TEMPLATE EPHEMA_REF EPHEMA_COMPOSE_FILE EPHEMA_REPO_ROOT EPHEMA_PROVISION_TIMEOUT EPHEMA_OBS_TIMEOUT EPHEMA_MAX_PER_USER EPHEMA_MAX_TTL EPHEMA_ENV_ID_RE EPHEMA_PREVIEW_GATE_PATH EPHEMA_SECRET_NEEDLES`.

## 4. Contract alignment (read before pointing it at the real API)
Phase 1 tests mirror the **real, existing** behaviour (paths, cookie name `ephematool_session`, 10 status services, `X-Trace-Id`, Loki/Tempo/Prom query shapes copied from `scripts/verify.d/*`). Phase 2+ tests encode the contract in SPEC-01/02/03 because the repo has no implementation yet. Where the real plans differ, adapt here — these are the known points:

| Topic | Tool assumes | Real plan says | Action |
|---|---|---|---|
| Env id | DNS label (`EPHEMA_ENV_ID_RE`) | `pv-<10 chars>` (02-10) | set `EPHEMA_ENV_ID_RE='^pv-[a-z0-9]{10}$'` |
| Preview gate | `GET /preview/auth` with `X-Forwarded-Host` + `X-Preview-Token` | Traefik ForwardAuth endpoint; ticket mint + env-bound cookie JWT (02-08) | set `EPHEMA_PREVIEW_GATE_PATH`; adjust `test_preview_gate_requires_valid_env_bound_token` to mint a ticket via the real op |
| Create body | `{repo, ref, template, ttl_seconds?, values?}` | server-authoritative validation pipeline, schema'd `values` (02-07/02-10) | edit `ApiClient.create_env` |
| Events/audit | `GET /api/environments/{id}/events`, `GET /api/audit` | audit list op (02-16), env detail reads (02-10) | edit paths in `clients.py` (single place) |
| Quota status | 429 + `Retry-After` + `{limit,active}` | minimal quota in P2, full in P7 (SPEC-03) | keep |
| Roles | `admin`, `viewer` | plus `creator` (02-06) | add a `creator` fixture + tests when that lands |

## 5. Test catalog
| File | Phase | Covers |
|---|---|---|
| `test_p1_auth` | 1 | public config, 401s, admin/viewer roles, non-member denied, cookie flags, state check, **open-redirect matrix**, logout invalidation |
| `test_p1_status` | 1 (7) | 10 services in order, vocabulary, **X-Trace-Id on every response**, unique ids, JSON 404, healthz/readyz |
| `test_p1_observability` | 1 | trace in Tempo, api+worker spans, trace↔log correlation, RED metric, worker counter, `auth.denied` log, **secret-in-telemetry scan** |
| `test_p2_environments` | 2 | authn/authz, repo allowlist, 8 invalid payloads → 4xx not 500, malformed JSON, TTL cap, 202+Location, id format, reaches running, failure terminal, **forward-only state machine**, idempotency key, quota (quota-mode), secret echo |
| `test_p2_audit_preview` | 2 | admin-only audit, actor attribution, **append-only (PUT/PATCH/DELETE/POST)**, gapless sequence, **preview gate env binding** |
| `test_p3_to_p7` | 3–7 | orphans, destroy (+idempotent, authz), health/drift signals, extend + cap, TTL expiry, extend-prevents-destroy, links, secrets-by-reference, out-of-scope refusal, quota explanation, security headers |
| `test_concurrency_load` | 1, 7 | parallel creates vs quota, status latency budget, session isolation under parallel logins |
| `test_repo_static` | 1–7 | migrations, D-09 gate, OpenAPI, compose, collector pipelines, secrets in git, `.env.example` parity, config validation, audit trigger/REVOKE, state CHECK, CI, pinned images, non-root, deploy artifact, server timeouts, docs freshness |
| `test_stack_ops` | 1–7 | Redis heartbeat key, Loki outage/recovery, Redis outage, DB role cannot UPDATE/DELETE audit, K8s namespace baseline (quota/limitrange/networkpolicy), no orphan after destroy, reconciler finds no orphans, worker restart convergence |

## 6. Verification performed (honest scope)
| Claim | Evidence |
|---|---|
| Suite is internally consistent | `selftest.py`: **general baseline 73 passed, 24 xfailed (later phases/caps); quota-mode baseline 3 passed**, with `--expect-phase 7` against the mock |
| Tests detect what they claim | `selftest.py` injects **17 faults** (`no_auth_on_create, viewer_can_create, allowlist_off, quota_off, regress_state, audit_mutable, idempotency_broken, open_redirect, no_trace_header, leak_secret, ttl_ignored, status_wrong_order, preview_gate_open, delete_any, echo_secrets, no_ttl_cap, no_security_headers`); every one is caught by its designated test(s) |
| Phase gating works | `--phase 2` baseline: 58 passed, 34 xfailed, 5 xpassed (features present earlier than required) |
| Repo tests are meaningful | Run against the real checkout: Phase-1 set **7 pass**; Phase-7 set **8 fail / 8 pass** — the failures are the real gaps in SPEC-00 §3. The first run also exposed a bug in the tests themselves (collector pipelines are named `traces/platform`, etc.) which was fixed |
| Mock found real test bugs | 4 defects in the tests/mock were found and fixed during bring-up (unread request bodies on keep-alive, backslash open-redirect, quota exhaustion cascade, selftest summary parsing) |
| **Not verified** | Running against the real Go stack, docker compose, kind, Tempo/Loki/Prometheus, real GitHub. `test_p1_observability`, `test_stack_ops` and the ephematest↔real-API contract at Phase 2+ are therefore **unexecuted against real infrastructure**; expect to adjust small details (§4) on first contact |

## 7. Extending
* **New feature test:** add `@pytest.mark.phase(n)`; if it detects a class of bug, add `@pytest.mark.fault("name")` and implement the fault in `mockstack/server.py` (`if "name" in st.faults:`) — `selftest.py` discovers it automatically and fails if the fault is not detected.
* **New capability:** add a probe to `_CAPS` in `plugin.py` and `@pytest.mark.requires("cap")`.
* **CI:** see `code/ci/ci.yaml` job `ephematest` (self-test → phase gate → quota mode, JUnit artifacts).
* **When a phase ships:** bump `EXPECT_PHASE`; any XPASS lines in the report are tests that were already satisfied.

## 8. Full source
Every file below is complete and runnable; the same files ship under `ephematest/` in the bundle.

### 5.1  `ephematest/pyproject.toml`

````toml
[project]
name = "ephematest"
version = "0.1.0"
description = "Black-box + repo-level conformance test tool for Ephematool"
requires-python = ">=3.10"
dependencies = ["pytest>=8", "requests>=2.31", "jsonschema>=4.20", "PyYAML>=6"]

[project.scripts]
ephematest = "ephematest.cli:main"

[tool.setuptools.packages.find]
include = ["ephematest*", "mockstack*"]

[tool.pytest.ini_options]
testpaths = ["tests"]
addopts = "-p ephematest.plugin -ra"
markers = [
  "phase(n): feature belongs to roadmap phase n; gated by --expect-phase",
  "requires(*caps): needs capability (docker, kubectl, obs, repo, db, redis); FAILS (never skips) when --strict-caps",
  "fault(name): this test is the designated detector for a mock fault (self-test)",
]
````

### 5.2  `ephematest/README.md`

````markdown
# ephematest

Conformance test tool for Ephematool (black-box API + observability + repo + ops).

## Install & run
    python -m venv .venv && . .venv/bin/activate && pip install -e .
    # against a running docker-compose stack (bazel run //:up_fake), Phase 1 only:
    ephematest tests --expect-phase 1 --repo-root ../ephematool
    # full productionized target:
    ephematest tests --expect-phase 7 --repo-root ../ephematool
    # quota tests need a stack with a LOW ENV_MAX_PER_USER (= EPHEMA_MAX_PER_USER):
    EPHEMA_MAX_PER_USER=3 ephematest tests --quota-mode
    # prove the tests themselves work (no Docker needed):
    python selftest.py

## Semantics
* `--expect-phase N`: tests marked phase<=N must pass; later ones are non-strict xfail. An XPASS means the
  feature landed early: bump the number.
* Missing docker/kubectl/obs/repo capability **fails** the test (never skips). `--allow-missing-caps` downgrades to xfail.
* Env vars: API_URL TEMPO_URL LOKI_URL PROM_URL EPHEMA_* (see ephematest/config.py).
````

### 5.3  `ephematest/ephematest/__init__.py`

````python
"""ephematest: conformance test tool for Ephematool."""
__version__ = "0.1.0"
````

### 5.4  `ephematest/ephematest/config.py`

````python
"""Environment-driven settings. Every URL mirrors a variable used by scripts/lib/verify-lib.sh."""
from __future__ import annotations
import os
from dataclasses import dataclass, field


def _env(name: str, default: str) -> str:
    return os.environ.get(name, default).rstrip("/")


@dataclass
class Settings:
    api_url: str = field(default_factory=lambda: _env("API_URL", "http://localhost:8080"))
    tempo_url: str = field(default_factory=lambda: _env("TEMPO_URL", "http://localhost:3200"))
    loki_url: str = field(default_factory=lambda: _env("LOKI_URL", "http://localhost:3100"))
    prom_url: str = field(default_factory=lambda: _env("PROM_URL", "http://localhost:9090"))
    grafana_url: str = field(default_factory=lambda: _env("GRAFANA_URL", "http://localhost:3000"))
    collector_health_url: str = field(default_factory=lambda: _env("COLLECTOR_HEALTH_URL", "http://localhost:13133"))
    # Users seeded by cmd/fakegithub (admin / viewer / outsider). Override for a real IdP.
    admin_login: str = field(default_factory=lambda: os.environ.get("EPHEMA_ADMIN_LOGIN", "octo-admin"))
    viewer_login: str = field(default_factory=lambda: os.environ.get("EPHEMA_VIEWER_LOGIN", "octo-viewer"))
    outsider_login: str = field(default_factory=lambda: os.environ.get("EPHEMA_OUTSIDER_LOGIN", "octo-outsider"))
    # Repo allowed by ALLOWED_REPOS and one that is not.
    allowed_repo: str = field(default_factory=lambda: os.environ.get("EPHEMA_ALLOWED_REPO", "tazzledazzle/sampleapp"))
    denied_repo: str = field(default_factory=lambda: os.environ.get("EPHEMA_DENIED_REPO", "evil/notallowed"))
    template: str = field(default_factory=lambda: os.environ.get("EPHEMA_TEMPLATE", "sampleapp"))
    ref: str = field(default_factory=lambda: os.environ.get("EPHEMA_REF", "main"))
    compose_file: str = field(default_factory=lambda: os.environ.get("EPHEMA_COMPOSE_FILE", "deploy/compose.yaml"))
    repo_root: str = field(default_factory=lambda: os.environ.get("EPHEMA_REPO_ROOT", ""))
    # Contract knobs so the suite can be pointed at the real implementation (see SPEC-05 "Contract alignment").
    env_id_pattern: str = field(default_factory=lambda: os.environ.get("EPHEMA_ENV_ID_RE", r"^[a-z0-9][a-z0-9-]{2,62}$"))
    preview_gate_path: str = field(default_factory=lambda: os.environ.get("EPHEMA_PREVIEW_GATE_PATH", "/preview/auth"))
    # Seconds to wait for async state transitions (provisioning takes minutes on real kind).
    provision_timeout: float = field(default_factory=lambda: float(os.environ.get("EPHEMA_PROVISION_TIMEOUT", "30")))
    obs_timeout: float = field(default_factory=lambda: float(os.environ.get("EPHEMA_OBS_TIMEOUT", "45")))
    http_timeout: float = field(default_factory=lambda: float(os.environ.get("EPHEMA_HTTP_TIMEOUT", "10")))
    # Concurrency quota the server is configured with (ENV_MAX_PER_USER); used by quota tests.
    max_per_user: int = field(default_factory=lambda: int(os.environ.get("EPHEMA_MAX_PER_USER", "3")))
    # Optional: expected maximum TTL (seconds) the server enforces.
    max_ttl: int = field(default_factory=lambda: int(os.environ.get("EPHEMA_MAX_TTL", "86400")))
    # Names of secrets that must never appear in telemetry.
    secret_needles: list[str] = field(default_factory=lambda: [
        s for s in os.environ.get("EPHEMA_SECRET_NEEDLES", "e2e-secret").split(",") if s])


SETTINGS = Settings()
````

### 5.5  `ephematest/ephematest/clients.py`

````python
"""HTTP clients: platform API (with the fake-GitHub OAuth dance) and observability backends."""
from __future__ import annotations
import time
import urllib.parse
from dataclasses import dataclass
from typing import Any, Callable

import requests

from .config import Settings

SESSION_COOKIE = "ephematool_session"


class LoginDenied(Exception):
    """Raised when sign-in ends in /denied (non-member)."""


@dataclass
class Resp:
    status: int
    headers: dict[str, str]
    body: Any
    text: str
    elapsed: float

    @property
    def trace_id(self) -> str:
        return self.headers.get("x-trace-id", "")


class ApiClient:
    """One cookie jar == one browser session. Redirects are never followed implicitly."""

    def __init__(self, settings: Settings, login: str | None = None):
        self.s = settings
        self.http = requests.Session()
        self.login_name = login

    # ---- raw -------------------------------------------------------------------------
    def request(self, method: str, path: str, *, json: Any = None, headers: dict | None = None,
                follow: bool = False, params: dict | None = None, data: Any = None) -> Resp:
        url = path if path.startswith("http") else self.s.api_url + path
        t0 = time.time()
        r = self.http.request(method, url, json=json, headers=headers, params=params, data=data,
                              allow_redirects=follow, timeout=self.s.http_timeout)
        try:
            body = r.json()
        except ValueError:
            body = None
        return Resp(r.status_code, {k.lower(): v for k, v in r.headers.items()}, body, r.text, time.time() - t0)

    def get(self, path: str, **kw) -> Resp: return self.request("GET", path, **kw)
    def post(self, path: str, **kw) -> Resp: return self.request("POST", path, **kw)
    def delete(self, path: str, **kw) -> Resp: return self.request("DELETE", path, **kw)

    # ---- login (mirrors scripts/lib/verify-lib.sh ensure_session) ----------------------
    def login(self, login: str | None = None) -> "ApiClient":
        login = login or self.login_name
        r = self.get("/api/auth/github/login")
        loc = r.headers.get("location")
        assert r.status in (302, 303, 307) and loc, f"login start must redirect, got {r.status}"
        r2 = requests.get(f"{loc}&login={login}" if "?" in loc else f"{loc}?login={login}",
                          allow_redirects=False, timeout=self.s.http_timeout)
        cb = r2.headers.get("location", "")
        assert cb, "fake GitHub returned no callback Location"
        cb_path = urllib.parse.urlsplit(cb)
        cb_rel = cb_path.path + ("?" + cb_path.query if cb_path.query else "")
        r3 = self.get(cb_rel)
        dest = r3.headers.get("location", "")
        if dest.startswith("/denied"):
            raise LoginDenied(login)
        assert SESSION_COOKIE in self.http.cookies.get_dict(), "no session cookie after callback"
        self.login_name = login
        return self

    @property
    def session_cookie(self) -> str:
        return self.http.cookies.get_dict().get(SESSION_COOKIE, "")

    # ---- environments (Phase 2+) -----------------------------------------------------
    def create_env(self, *, repo: str | None = None, ref: str | None = None, template: str | None = None,
                   ttl_seconds: int | None = None, values: dict | None = None,
                   idem_key: str | None = None) -> Resp:
        body: dict[str, Any] = {"repo": repo or self.s.allowed_repo, "ref": ref or self.s.ref,
                                "template": template or self.s.template}
        if ttl_seconds is not None: body["ttl_seconds"] = ttl_seconds
        if values is not None: body["values"] = values
        h = {"Idempotency-Key": idem_key} if idem_key else None
        return self.post("/api/environments", json=body, headers=h)

    def wait_state(self, env_id: str, want: Callable[[str], bool] | set[str], timeout: float | None = None) -> dict:
        timeout = timeout or self.s.provision_timeout
        pred = want if callable(want) else (lambda st: st in want)
        deadline, last = time.time() + timeout, None
        while time.time() < deadline:
            r = self.get(f"/api/environments/{env_id}")
            if r.status == 200 and isinstance(r.body, dict):
                last = r.body
                if pred(last.get("state", "")):
                    return last
            time.sleep(0.25)
        raise TimeoutError(f"env {env_id} did not reach wanted state in {timeout}s (last={last})")


class Obs:
    """Tempo / Loki / Prometheus query helpers with the same query shapes as verify-lib.sh."""

    def __init__(self, s: Settings):
        self.s = s

    def _get(self, url: str, **kw):
        return requests.get(url, timeout=self.s.http_timeout, **kw)

    def poll(self, fn: Callable[[], Any], ok: Callable[[Any], bool], timeout: float | None = None, every: float = 1.0):
        deadline, last = time.time() + (timeout or self.s.obs_timeout), None
        while time.time() < deadline:
            try:
                last = fn()
                if ok(last):
                    return last
            except requests.RequestException:
                pass
            time.sleep(every)
        return last

    def tempo_services(self, trace_id: str) -> set[str]:
        r = self._get(f"{self.s.tempo_url}/api/traces/{trace_id}")
        if r.status_code != 200:
            return set()
        out: set[str] = set()
        for b in r.json().get("batches", []):
            for a in b.get("resource", {}).get("attributes", []):
                if a.get("key") == "service.name":
                    out.add(a["value"].get("stringValue", ""))
        return out

    def tempo_raw(self, trace_id: str) -> str:
        r = self._get(f"{self.s.tempo_url}/api/traces/{trace_id}")
        return r.text if r.status_code == 200 else ""

    def loki_lines(self, query: str, seconds: int = 300, limit: int = 1000) -> list[str]:
        now = int(time.time())
        r = self._get(f"{self.s.loki_url}/loki/api/v1/query_range", params={
            "query": query, "start": f"{now - seconds}000000000", "end": f"{now}000000000", "limit": limit})
        if r.status_code != 200:
            return []
        return [v[1] for st in r.json().get("data", {}).get("result", []) for v in st.get("values", [])]

    def prom_value(self, query: str) -> float | None:
        r = self._get(f"{self.s.prom_url}/api/v1/query", params={"query": query})
        if r.status_code != 200:
            return None
        res = r.json().get("data", {}).get("result", [])
        return float(res[0]["value"][1]) if res else None
````

### 5.6  `ephematest/ephematest/plugin.py`

````python
"""pytest plugin: phase gating, capability checks that FAIL instead of skip, shared fixtures."""
from __future__ import annotations
import shutil
import subprocess
import uuid
from pathlib import Path

import pytest
import requests

from .clients import ApiClient, LoginDenied, Obs
from .config import SETTINGS, Settings


def pytest_addoption(parser):
    g = parser.getgroup("ephematest")
    g.addoption("--expect-phase", type=int, default=7,
                help="Highest roadmap phase believed implemented (1-7). Tests for later phases are "
                     "expected to fail (xfail); tests for <= this phase must pass.")
    g.addoption("--strict-caps", action="store_true", default=True,
                help="A test whose capability (docker/kubectl/obs/repo) is missing FAILS (default).")
    g.addoption("--allow-missing-caps", action="store_true", default=False,
                help="Downgrade missing capabilities to an explicit xfail instead of a failure.")
    g.addoption("--quota-mode", action="store_true", default=False,
                help="Run ONLY quota tests (stack must have ENV_MAX_PER_USER == EPHEMA_MAX_PER_USER, low). "
                     "Without it quota tests are deselected, because the other suites need headroom.")
    g.addoption("--repo-root", default=None, help="Path to a checkout of ephematool (enables repo tests).")
    g.addoption("--api-url", default=None)


def pytest_report_header(config):
    return [f"ephematest: expect-phase={config.getoption('--expect-phase')} quota-mode={config.getoption('--quota-mode')} "
            f"(quota tests are {'the only tests' if config.getoption('--quota-mode') else 'deselected; run again with --quota-mode'})"]


def pytest_configure(config):
    config.addinivalue_line("markers", "quota: needs a low per-user quota; run with --quota-mode")
    if config.getoption("--api-url"):
        SETTINGS.api_url = config.getoption("--api-url").rstrip("/")
    root = config.getoption("--repo-root") or SETTINGS.repo_root
    SETTINGS.repo_root = root or ""


# ---- capabilities -------------------------------------------------------------------
def _cap_docker(s: Settings) -> str | None:
    if not shutil.which("docker"): return "docker CLI not found"
    return None


def _cap_kubectl(s: Settings) -> str | None:
    if not shutil.which("kubectl"): return "kubectl not found"
    p = subprocess.run(["kubectl", "cluster-info"], capture_output=True, timeout=20)
    return None if p.returncode == 0 else "kubectl cannot reach a cluster"


def _cap_obs(s: Settings) -> str | None:
    for name, url in (("tempo", s.tempo_url + "/ready"), ("loki", s.loki_url + "/ready"), ("prometheus", s.prom_url + "/-/ready")):
        try:
            if requests.get(url, timeout=3).status_code != 200: return f"{name} not ready"
        except requests.RequestException:
            return f"{name} unreachable"
    return None


def _cap_repo(s: Settings) -> str | None:
    return None if s.repo_root and (Path(s.repo_root) / "go.mod").exists() else "no --repo-root checkout (go.mod missing)"


def _cap_db(s: Settings) -> str | None:
    return _cap_docker(s)


_CAPS = {"docker": _cap_docker, "kubectl": _cap_kubectl, "obs": _cap_obs, "repo": _cap_repo, "db": _cap_db, "redis": _cap_docker}
_cap_cache: dict[str, str | None] = {}


def pytest_collection_modifyitems(config, items):
    expect = config.getoption("--expect-phase")
    qmode = config.getoption("--quota-mode")
    drop = [i for i in items if bool(i.get_closest_marker("quota")) != qmode]
    if drop:                                   # never silent: reported in the run header
        config.hook.pytest_deselected(items=drop)
        items[:] = [i for i in items if i not in drop]
    for item in items:
        m = item.get_closest_marker("phase")
        if m and m.args[0] > expect:
            item.add_marker(pytest.mark.xfail(
                reason=f"phase {m.args[0]} not expected before phase {expect} is complete", strict=False, run=True))


@pytest.hookimpl(tryfirst=True)
def pytest_runtest_setup(item):
    """Missing capabilities are loud: fail (or explicit xfail), never a silent skip."""
    for m in item.iter_markers("requires"):
        for cap in m.args:
            if cap not in _cap_cache:
                _cap_cache[cap] = _CAPS[cap](SETTINGS)
            why = _cap_cache[cap]
            if why:
                if item.config.getoption("--allow-missing-caps"):
                    pytest.xfail(f"capability '{cap}' missing: {why}")
                pytest.fail(f"capability '{cap}' missing: {why} (use --allow-missing-caps to downgrade)", pytrace=False)


# ---- fixtures -----------------------------------------------------------------------
@pytest.fixture(scope="session")
def settings() -> Settings: return SETTINGS


@pytest.fixture(scope="session")
def obs(settings) -> Obs: return Obs(settings)


@pytest.fixture(scope="session")
def anon(settings) -> ApiClient: return ApiClient(settings)


@pytest.fixture(scope="session")
def admin(settings) -> ApiClient: return ApiClient(settings).login(settings.admin_login)


@pytest.fixture(scope="session")
def viewer(settings) -> ApiClient: return ApiClient(settings).login(settings.viewer_login)


@pytest.fixture()
def fresh_admin(settings) -> ApiClient:
    """A new session per test for tests that mutate quotas."""
    return ApiClient(settings).login(settings.admin_login)


@pytest.fixture()
def outsider_login(settings):
    c = ApiClient(settings)
    with pytest.raises(LoginDenied):
        c.login(settings.outsider_login)
    return c


@pytest.fixture()
def uid() -> str: return uuid.uuid4().hex[:8]


@pytest.fixture()
def created_env(admin):
    """Create an environment, hand back its body, best-effort cleanup via DELETE (Phase 4+)."""
    r = admin.create_env()
    assert r.status in (200, 201, 202), f"create failed {r.status} {r.text[:200]}"
    env = r.body
    yield env
    admin.delete(f"/api/environments/{env['id']}")
````

### 5.7  `ephematest/ephematest/cli.py`

````python
"""`ephematest` entry point: thin wrapper around pytest with friendly defaults."""
from __future__ import annotations
import sys
import pytest


def main() -> None:
    args = sys.argv[1:] or ["tests"]
    sys.exit(pytest.main(["-p", "ephematest.plugin", *args]))


if __name__ == "__main__":
    main()
````

### 5.8  `ephematest/tests/test_p1_auth.py`

````python
"""Phase 1: GitHub OAuth login, allowlist, session handling (AUTH-*)."""
import pytest
from ephematest.clients import ApiClient, LoginDenied

pytestmark = pytest.mark.phase(1)


def test_auth_config_is_public(anon):
    r = anon.get("/api/auth/config")
    assert r.status == 200 and isinstance(r.body, dict)


def test_me_requires_session(anon):
    assert anon.get("/api/me").status == 401


def test_admin_login_and_role(admin, settings):
    r = admin.get("/api/me")
    assert r.status == 200
    assert r.body["login"] == settings.admin_login and r.body["role"] == "admin"


def test_viewer_role(viewer):
    assert viewer.get("/api/me").body["role"] == "viewer"


def test_non_member_is_denied_without_session(outsider_login):
    assert outsider_login.session_cookie == ""
    assert outsider_login.get("/api/me").status == 401


def test_session_cookie_flags(settings):
    c = ApiClient(settings)
    r = c.get("/api/auth/github/login")
    loc = r.headers["location"]
    import requests, urllib.parse
    r2 = requests.get(f"{loc}&login={settings.admin_login}", allow_redirects=False, timeout=10)
    cb = urllib.parse.urlsplit(r2.headers["location"])
    r3 = c.get(cb.path + "?" + cb.query)
    sc = r3.headers.get("set-cookie", "").lower()
    assert "httponly" in sc, sc
    assert "samesite" in sc, sc
    assert "path=/" in sc, sc


def test_callback_rejects_unknown_state(anon):
    assert anon.get("/api/auth/github/callback?code=octo-admin&state=forged").status in (400, 401, 403)


@pytest.mark.fault("open_redirect")
@pytest.mark.parametrize("evil", ["https://evil.example/x", "//evil.example/x", "/\\evil.example"])
def test_next_param_is_not_an_open_redirect(settings, evil):
    import requests, urllib.parse
    c = ApiClient(settings)
    r = c.get("/api/auth/github/login", params={"next": evil})
    loc = r.headers["location"]
    r2 = requests.get(f"{loc}&login={settings.admin_login}", allow_redirects=False, timeout=10)
    cb = urllib.parse.urlsplit(r2.headers["location"])
    r3 = c.get(cb.path + "?" + cb.query)
    dest = r3.headers.get("location", "")
    assert dest.startswith("/") and not dest.startswith("//") and "\\" not in dest, f"redirected to {dest!r}"


def test_logout_invalidates_session(settings):
    c = ApiClient(settings).login(settings.admin_login)
    assert c.get("/api/me").status == 200
    assert c.post("/api/auth/logout").status in (200, 204)
    old = c.http.cookies.get_dict().get("ephematool_session")
    c2 = ApiClient(settings)
    if old:  # replaying the old token must fail even if the cookie jar kept it
        c2.http.cookies.set("ephematool_session", old)
        assert c2.get("/api/me").status == 401
````

### 5.9  `ephematest/tests/test_p1_status.py`

````python
"""Phase 1: /api/status contract (10 services, order, trace header) and health endpoints."""
import pytest

pytestmark = pytest.mark.phase(1)
WANT = ["api", "worker", "dashboard", "postgres", "redis", "otel-collector", "tempo", "loki", "prometheus", "grafana"]
ALLOWED = {"healthy", "degraded", "down", "unknown"}


def test_status_requires_session(anon):
    assert anon.get("/api/status").status == 401


@pytest.mark.fault("status_wrong_order")
def test_status_ten_services_in_contract_order(admin):
    r = admin.get("/api/status")
    assert r.status == 200
    ids = [s["id"] for s in r.body["services"]]
    assert ids == WANT


def test_status_values_are_from_the_vocabulary(admin):
    for s in admin.get("/api/status").body["services"]:
        assert s["status"] in ALLOWED and "detail" in s


@pytest.mark.fault("no_trace_header")
def test_every_api_response_carries_x_trace_id(admin, anon):
    for r in (admin.get("/api/status"), admin.get("/api/me"), anon.get("/api/me"), anon.get("/api/auth/config")):
        assert len(r.trace_id) == 32 and int(r.trace_id, 16) >= 0, f"bad trace id {r.trace_id!r}"


def test_trace_ids_are_unique(admin):
    assert len({admin.get("/api/me").trace_id for _ in range(5)}) == 5


@pytest.mark.phase(1)
def test_unknown_route_is_json_404(admin):
    r = admin.get("/api/definitely-not-a-route")
    assert r.status == 404


@pytest.mark.phase(7)
def test_health_and_readiness_endpoints(anon):
    assert anon.get("/healthz").status == 200
    assert anon.get("/readyz").status == 200
````

### 5.10  `ephematest/tests/test_p1_observability.py`

````python
"""Phase 1: OTel-first - one request yields trace, log and metric (OBS-*). Needs Tempo/Loki/Prom."""
import re
import pytest

pytestmark = [pytest.mark.phase(1), pytest.mark.requires("obs")]


def test_trace_contains_api_service(admin, obs):
    tid = admin.get("/api/status").trace_id
    svcs = obs.poll(lambda: obs.tempo_services(tid), lambda s: "ephematool-api" in s)
    assert "ephematool-api" in svcs, svcs


def test_trace_spans_api_and_worker(admin, obs):
    svcs = set()
    for _ in range(3):                      # PING_THROTTLE may skip the enqueue
        tid = admin.get("/api/status").trace_id
        svcs = obs.poll(lambda: obs.tempo_services(tid), lambda s: {"ephematool-api", "ephematool-worker"} <= s, timeout=20)
        if "ephematool-worker" in svcs: break
    assert {"ephematool-api", "ephematool-worker"} <= svcs, svcs


def test_logs_correlate_by_trace_id(admin, obs):
    tid = admin.get("/api/status").trace_id
    lines = obs.poll(lambda: obs.loki_lines(f'{{service_name="ephematool-api"}} | trace_id="{tid}"'), bool)
    assert lines, f"no loki lines for trace {tid}"


def test_http_server_duration_metric_exists(admin, obs):
    admin.get("/api/status")
    v = obs.poll(lambda: obs.prom_value('sum(http_server_request_duration_seconds_count{service_name="ephematool-api",http_route="/api/status"})'),
                 lambda v: v is not None and v > 0)
    assert v and v > 0


def test_worker_task_counter(admin, obs):
    admin.get("/api/status")
    v = obs.poll(lambda: obs.prom_value('sum(ephematool_queue_task_processed_total{service_name="ephematool-worker"})'),
                 lambda v: v is not None and v > 0)
    assert v and v > 0


def test_auth_denied_is_logged(outsider_login, obs, settings):
    lines = obs.poll(lambda: obs.loki_lines(f'{{service_name="ephematool-api"}} |= "auth.denied" | login="{settings.outsider_login}"'), bool)
    assert lines, "no auth.denied line for the outsider"


@pytest.mark.fault("leak_secret")
def test_no_secret_material_in_traces_or_logs(admin, obs, settings):
    """Mirror of scripts/verify.d/redaction.sh: cookie value, auth headers, client secret never stored."""
    tids = [admin.get(p).trace_id for p in ("/api/status", "/api/me")]
    cookie = admin.session_cookie
    assert cookie
    needles = [cookie, "ephematool_session=", "Bearer ", "access_token=", '"access_token"',
               "http.request.header.cookie", "http.response.header.set-cookie", "http.request.header.authorization",
               *settings.secret_needles]
    corpus = ""
    for t in tids:
        raw = obs.poll(lambda t=t: obs.tempo_raw(t), bool)
        assert raw, f"trace {t} never reached Tempo"
        corpus += raw
    corpus += "\n".join(obs.loki_lines('{service_namespace="ephematool"}', 900, 5000))
    hits = [n for n in needles if n and n.lower() in corpus.lower()]
    assert not hits, f"secret material in telemetry: {hits}"
````

### 5.11  `ephematest/tests/test_p2_environments.py`

````python
"""Phase 2: create a secure preview environment (ENV-*): validation, authz, quota, idempotency, state machine."""
import time
import pytest
from ephematest.clients import ApiClient

pytestmark = pytest.mark.phase(2)

# Forward-only graph (D-12/CAS). Terminal: failed, destroyed.
EDGES = {None: {"requested"}, "requested": {"provisioning", "failed"}, "provisioning": {"running", "failed"},
         "running": {"destroying"}, "failed": {"destroying"}, "destroying": {"destroyed"}, "destroyed": set()}


@pytest.mark.fault("no_auth_on_create")
def test_create_requires_session(anon):
    assert anon.create_env().status == 401


@pytest.mark.fault("viewer_can_create")
def test_viewer_cannot_create(viewer):
    assert viewer.create_env().status == 403


@pytest.mark.fault("allowlist_off")
def test_repo_outside_allowlist_is_forbidden(admin, settings):
    assert admin.create_env(repo=settings.denied_repo).status in (403, 422)


@pytest.mark.parametrize("patch", [
    {"template": "does-not-exist"}, {"ttl_seconds": 0}, {"ttl_seconds": -5}, {"ttl_seconds": "soon"},
    {"ttl_seconds": True}, {"values": "notanobject"}, {"repo": ""}, {"ref": None}])
def test_invalid_payloads_are_422_not_500(admin, settings, patch):
    body = {"repo": settings.allowed_repo, "ref": settings.ref, "template": settings.template, **patch}
    r = admin.post("/api/environments", json=body)
    assert r.status in (400, 422), f"{patch} -> {r.status} {r.text[:120]}"


def test_malformed_json_is_400(admin):
    r = admin.post("/api/environments", data="{not json", headers={"Content-Type": "application/json"})
    assert r.status in (400, 422)


@pytest.mark.fault("no_ttl_cap")
def test_ttl_above_maximum_rejected(admin, settings):
    assert admin.create_env(ttl_seconds=settings.max_ttl + 1).status == 422


def test_create_returns_202_with_location_and_requested_state(admin):
    r = admin.create_env()
    assert r.status == 202, r.text
    assert r.body["state"] == "requested" and r.body["owner"] == admin.login_name
    assert r.headers.get("location", "").endswith(r.body["id"])
    assert r.trace_id


def test_environment_id_is_server_generated_dns_label(admin, settings):
    import re
    env = admin.create_env().body
    assert re.match(settings.env_id_pattern, env["id"]), env["id"]
    assert settings.ref not in env["id"], "id must never be branch-derived (D-03)"


def test_environment_reaches_running_with_url(admin, settings):
    env = admin.create_env().body
    done = admin.wait_state(env["id"], {"running", "failed"})
    assert done["state"] == "running", done
    assert done["url"] and done["ttl_expires_at"]


def test_failed_provision_is_terminal_and_visible(admin):
    env = admin.create_env(values={"fail": True}).body
    done = admin.wait_state(env["id"], {"failed", "running"})
    assert done["state"] == "failed"


@pytest.mark.fault("regress_state")
def test_events_follow_forward_only_state_machine(admin):
    env = admin.create_env().body
    admin.wait_state(env["id"], {"running", "failed"})
    time.sleep(0.8)                                       # let a buggy server regress, if it will
    ev = admin.get(f"/api/environments/{env['id']}/events").body["events"]
    prev = None
    for e in ev:
        assert e["to"] in EDGES.get(e["from"], set()) or e["from"] == e["to"], f"illegal transition {e['from']}->{e['to']}"
        assert e["from"] == prev or prev is None or e["from"] is None, "event chain has a gap"
        prev = e["to"]
    assert [e["seq"] for e in ev] == sorted(e["seq"] for e in ev)


@pytest.mark.fault("idempotency_broken")
def test_idempotency_key_returns_same_environment(admin, uid):
    a = admin.create_env(idem_key=f"k-{uid}")
    b = admin.create_env(idem_key=f"k-{uid}")
    assert a.status == 202 and b.status in (200, 202)
    assert a.body["id"] == b.body["id"]


@pytest.mark.quota
@pytest.mark.fault("quota_off")
def test_per_user_quota_enforced_with_retry_after(settings):
    c = ApiClient(settings).login(settings.admin_login)
    # Other tests may already hold slots, so create until the first rejection (bounded).
    codes = []
    for _ in range(settings.max_per_user + 3):
        r = c.create_env(); codes.append(r.status)
        if r.status == 429:
            assert "retry-after" in r.headers
            break
    assert 429 in codes, f"quota never enforced: {codes}"


@pytest.mark.fault("echo_secrets")
def test_secret_values_never_echoed(admin):
    r = admin.create_env(values={"db_password": "hunter2-canary", "color": "blue"})
    assert r.status in (202, 422)
    if r.status == 202:                                    # accepted => must be redacted everywhere
        got = admin.get(f"/api/environments/{r.body['id']}")
        assert "hunter2-canary" not in r.text and "hunter2-canary" not in got.text


def test_get_unknown_environment_is_404(admin):
    assert admin.get("/api/environments/deadbeef").status == 404


def test_environment_endpoints_require_session(anon):
    assert anon.get("/api/environments").status == 401
    assert anon.get("/api/environments/deadbeef").status == 401


def test_viewer_can_read_but_list_is_consistent(admin, viewer):
    env = admin.create_env().body
    assert viewer.get(f"/api/environments/{env['id']}").status == 200
    assert env["id"] in [e["id"] for e in viewer.get("/api/environments").body["environments"]]
````

### 5.12  `ephematest/tests/test_p2_audit_preview.py`

````python
"""Phase 2: audit trail (append-only, admin-only) and the preview gate (ENV-09)."""
import pytest

pytestmark = pytest.mark.phase(2)


def test_audit_admin_only(anon, viewer, admin):
    assert anon.get("/api/audit").status == 401
    assert viewer.get("/api/audit").status == 403
    assert admin.get("/api/audit").status == 200


def test_create_is_audited_with_actor(admin):
    env = admin.create_env().body
    ev = [e for e in admin.get("/api/audit").body["events"] if e["env_id"] == env["id"]]
    assert ev and ev[0]["actor"] == admin.login_name and ev[0]["action"] == "env.create"


@pytest.mark.fault("audit_mutable")
@pytest.mark.parametrize("method", ["PUT", "PATCH", "DELETE", "POST"])
def test_audit_log_is_append_only(admin, method):
    admin.create_env()
    before = len(admin.get("/api/audit").body["events"])
    r = admin.request(method, "/api/audit/1", json={})
    assert r.status in (404, 405, 403), r.status
    r = admin.request(method, "/api/audit", json={})
    assert r.status in (404, 405, 403), r.status
    assert len(admin.get("/api/audit").body["events"]) >= before


def test_audit_sequence_is_gapless_and_monotonic(admin):
    seqs = [e["seq"] for e in admin.get("/api/audit").body["events"]]
    assert seqs == list(range(seqs[0], seqs[0] + len(seqs)))


def _running(admin):
    env = admin.create_env().body
    return admin.wait_state(env["id"], {"running"})


@pytest.mark.fault("preview_gate_open")
def test_preview_gate_requires_valid_env_bound_token(admin, anon, settings):
    a, b = _running(admin), _running(admin)
    tok_a = admin.post(f"/api/environments/{a['id']}/preview-link").body["token"]
    from urllib.parse import urlsplit
    host_a, host_b = urlsplit(a["url"]).hostname, urlsplit(b["url"]).hostname     # the URL the server issued
    gate = lambda host, tok=None: anon.get(settings.preview_gate_path, headers={"X-Forwarded-Host": host, **({"X-Preview-Token": tok} if tok else {})}).status
    assert gate(host_a) == 401                 # no token
    assert gate(host_a, "garbage") in (401, 403)
    assert gate(host_a, tok_a) == 200          # right token, right env
    assert gate(host_b, tok_a) in (401, 403)   # token is bound to one environment
    assert gate("ffffffff.preview.localhost", tok_a) in (401, 403, 404)


def test_preview_link_only_for_running_env(admin):
    env = admin.create_env().body
    r = admin.post(f"/api/environments/{env['id']}/preview-link")
    assert r.status in (200, 409)
````

### 5.13  `ephematest/tests/test_p3_to_p7.py`

````python
"""Phases 3-7 (numbering = .planning/ROADMAP.md): 3 inventory/destroy/orphans, 4 health+drift, 5 TTL/extend,
6 per-env telemetry links, 7 quota + secrets guardrails + hardening."""
import time
import pytest
from ephematest.clients import ApiClient


# ---- Phase 4: live health + drift --------------------------------------------------
@pytest.mark.phase(4)
def test_health_reports_probe_and_workflow_signals(admin):
    env = admin.create_env().body
    admin.wait_state(env["id"], {"running"})
    h = admin.get(f"/api/environments/{env['id']}/health")
    assert h.status == 200 and h.body["healthy"] is True and {"workflow", "probe"} <= set(h.body["signals"])


@pytest.mark.phase(4)
def test_failed_env_is_never_reported_healthy(admin):
    env = admin.create_env(values={"fail": True}).body
    admin.wait_state(env["id"], {"failed"})
    assert admin.get(f"/api/environments/{env['id']}/health").body["healthy"] is False


# ---- Phase 3: inventory, destroy, orphans -------------------------------------------------------
@pytest.mark.phase(3)
def test_list_filters_and_pagination(admin):
    for _ in range(2): admin.create_env(values={"fail": True})
    time.sleep(1.0)
    r = admin.get("/api/environments", params={"state": "failed", "limit": 1})
    assert r.status == 200 and len(r.body["environments"]) == 1 and r.body["next_cursor"]
    nxt = admin.get("/api/environments", params={"state": "failed", "limit": 1, "cursor": r.body["next_cursor"]})
    assert nxt.body["environments"][0]["id"] != r.body["environments"][0]["id"]
    assert all(e["state"] == "failed" for e in r.body["environments"] + nxt.body["environments"])


@pytest.mark.phase(3)
def test_orphans_endpoint_is_admin_only_and_well_formed(admin, viewer, anon):
    assert anon.get("/api/orphans").status == 401
    assert viewer.get("/api/orphans").status == 403
    r = admin.get("/api/orphans")
    assert r.status == 200 and isinstance(r.body["orphans"], list)


@pytest.mark.phase(3)
def test_destroy_reaches_destroyed_and_is_audited(admin):
    env = admin.create_env().body
    admin.wait_state(env["id"], {"running"})
    assert admin.delete(f"/api/environments/{env['id']}").status == 202
    admin.wait_state(env["id"], {"destroyed"})
    acts = [e["action"] for e in admin.get(f"/api/environments/{env['id']}/events").body["events"]]
    assert "destroy.request" in acts and "destroy.ok" in acts


@pytest.mark.phase(3)
def test_destroy_is_idempotent(admin):
    env = admin.create_env().body
    admin.wait_state(env["id"], {"running"})
    assert admin.delete(f"/api/environments/{env['id']}").status == 202
    assert admin.delete(f"/api/environments/{env['id']}").status in (200, 202, 404, 409)


@pytest.mark.phase(3)
@pytest.mark.fault("delete_any")
def test_viewer_cannot_destroy_someone_elses_env(admin, viewer):
    env = admin.create_env().body
    assert viewer.delete(f"/api/environments/{env['id']}").status in (403, 404)


# ---- Phase 5: TTL, extension, auto-teardown ------------------------------------------------------
@pytest.mark.phase(5)
def test_extend_ttl_and_cap(admin, settings):
    env = admin.create_env(ttl_seconds=600).body
    r = admin.post(f"/api/environments/{env['id']}/extend", json={"ttl_seconds": 300})
    assert r.status == 200 and r.body["ttl_seconds"] == 900
    assert admin.post(f"/api/environments/{env['id']}/extend", json={"ttl_seconds": settings.max_ttl}).status == 422
    assert admin.post(f"/api/environments/{env['id']}/extend", json={"ttl_seconds": -1}).status == 422


@pytest.mark.phase(5)
@pytest.mark.fault("ttl_ignored")
def test_ttl_expiry_destroys_environment(admin):
    env = admin.create_env(ttl_seconds=2).body
    done = admin.wait_state(env["id"], {"destroyed"}, timeout=20)
    acts = [e["action"] for e in admin.get(f"/api/environments/{env['id']}/events").body["events"]]
    assert "ttl.expired" in acts and done["state"] == "destroyed"


@pytest.mark.phase(5)
def test_extend_before_expiry_prevents_destroy(admin):
    env = admin.create_env(ttl_seconds=2).body
    admin.wait_state(env["id"], {"running"})
    assert admin.post(f"/api/environments/{env['id']}/extend", json={"ttl_seconds": 600}).status == 200
    time.sleep(3)
    assert admin.get(f"/api/environments/{env['id']}").body["state"] == "running"


# ---- Phase 6: observability deep links ------------------------------------------------------
@pytest.mark.phase(6)
def test_environment_links_to_grafana_and_traces(admin):
    env = admin.create_env().body
    r = admin.get(f"/api/environments/{env['id']}/links")
    assert r.status == 200 and env["id"] in r.body["grafana"] and "traces" in r.body


# ---- Phase 7: hardening ---------------------------------------------------------------------
@pytest.mark.phase(7)
@pytest.mark.fault("no_security_headers")
def test_security_headers_present(admin):
    h = admin.get("/api/me").headers
    assert h.get("x-content-type-options") == "nosniff"
    assert h.get("x-frame-options") in ("DENY", "SAMEORIGIN")
    assert "no-store" in h.get("cache-control", "")


@pytest.mark.phase(7)
def test_secret_by_reference_is_accepted_and_value_never_returned(admin):
    r = admin.create_env(values={"db": {"secretRef": "sampleapp-db"}})
    assert r.status == 202, r.text
    assert "secretRef" in r.text and "password" not in r.text.lower()


@pytest.mark.phase(7)
def test_out_of_scope_secret_reference_refused(admin):
    assert admin.create_env(values={"db": {"secretRef": "prod-database-root"}}).status in (403, 422)


@pytest.mark.quota
@pytest.mark.phase(7)
def test_quota_rejection_explains_remaining_quota(settings):
    """GRD-03 success criterion 2: the rejection body says why (limit, active, soonest expiry)."""
    c = ApiClient(settings).login(settings.admin_login)
    r = None
    for _ in range(settings.max_per_user + 2):
        r = c.create_env()
        if r.status == 429: break
    assert r.status == 429 and {"limit", "active"} <= set(r.body), r.text
````

### 5.14  `ephematest/tests/test_concurrency_load.py`

````python
"""Concurrency + light load: races on quota and TTL, and request-latency budget."""
import concurrent.futures as cf
import statistics
import pytest
from ephematest.clients import ApiClient


@pytest.mark.quota
@pytest.mark.phase(7)
@pytest.mark.fault("quota_off")
def test_parallel_creates_cannot_exceed_quota(settings):
    """Quota must be atomic (Phase 7 hardening): N parallel creates never yield more than max_per_user."""
    c = ApiClient(settings).login(settings.admin_login)
    base = sum(1 for e in c.get("/api/environments").body["environments"]
               if e["owner"] == c.login_name and e["state"] not in ("failed", "destroyed"))
    n = settings.max_per_user + 5
    with cf.ThreadPoolExecutor(n) as ex:
        res = list(ex.map(lambda _: c.create_env().status, range(n)))
    accepted = res.count(202)
    assert accepted <= max(settings.max_per_user - base, 0) + 0, f"{accepted} accepted with {base} already active: {res}"


@pytest.mark.phase(1)
def test_status_endpoint_latency_budget(admin):
    lat = sorted(admin.get("/api/status").elapsed for _ in range(30))
    assert statistics.median(lat) < 1.0 and lat[int(len(lat) * 0.95)] < 2.5, f"p50={lat[15]:.3f}s p95={lat[28]:.3f}s"


@pytest.mark.phase(1)
def test_session_isolation_under_parallel_logins(settings):
    def who(login):
        c = ApiClient(settings).login(login)
        return c.get("/api/me").body["login"]
    logins = [settings.admin_login, settings.viewer_login] * 8
    with cf.ThreadPoolExecutor(8) as ex:
        assert list(ex.map(who, logins)) == logins
````

### 5.15  `ephematest/tests/test_repo_static.py`

````python
"""Repo-level conformance (no running stack): hygiene, drift, supply chain, production readiness.
Run with --repo-root /path/to/ephematool."""
import json, re, subprocess
from pathlib import Path
import pytest
import yaml

pytestmark = pytest.mark.requires("repo")


@pytest.fixture(scope="module")
def root(settings) -> Path: return Path(settings.repo_root)


def files(root, *globs):
    out = []
    for g in globs:
        out += [p for p in root.glob(g) if p.is_file() and ".git/" not in str(p) and "node_modules" not in str(p)]
    return out


# ------------------------------------------------------------- Phase 1 invariants
@pytest.mark.phase(1)
def test_migrations_are_contiguous_and_paired(root):
    mig = sorted((root / "internal/store/migrations").glob("*.sql"))
    assert mig, "no migrations"
    nums = [int(re.match(r"(\d+)_", m.name).group(1)) for m in mig]
    assert nums == list(range(1, len(nums) + 1)), f"migration numbering gap: {nums}"
    for m in mig:
        t = m.read_text()
        assert "-- +goose Up" in t, f"{m.name} lacks goose Up"
        assert "-- +goose Down" in t, f"{m.name} lacks goose Down (rollback story)"


@pytest.mark.phase(1)
def test_d09_prefixes_only_in_generated_files(root):
    """Port of scripts/verify.d/conventions.sh."""
    bad = []
    for p in files(root, "cmd/**/*.go", "internal/**/*.go", "web/src/**/*.ts", "web/src/**/*.tsx", "deploy/**/*.yaml", "deploy/**/*.json"):
        n = str(p)
        if ".gen." in n or n.endswith("_test.go") or n.endswith("conventions/telemetry.json"): continue
        t = p.read_text(errors="ignore")
        if "ephematool.io/" in t or "ephematool.env." in t: bad.append(str(p.relative_to(root)))
    assert not bad, f"hand-written D-09 prefixes: {bad}"


@pytest.mark.phase(1)
def test_openapi_is_valid_and_paths_documented(root):
    spec = json.loads((root / "api/openapi.json").read_text())
    assert spec["openapi"].startswith("3.")
    for path in ("/api/status", "/api/me", "/api/auth/config", "/api/auth/logout"):
        assert path in spec["paths"], f"{path} missing from api/openapi.json"


@pytest.mark.phase(1)
def test_compose_declares_all_ten_status_services(root):
    c = yaml.safe_load((root / "deploy/compose.yaml").read_text())
    for svc in ("api", "worker", "postgres", "redis", "otel-collector", "tempo", "loki", "prometheus", "grafana"):
        assert svc in c["services"], f"compose lacks {svc}"


@pytest.mark.phase(1)
def test_collector_config_has_three_signal_pipelines(root):
    c = yaml.safe_load((root / "deploy/otel/collector.yaml").read_text())
    pipes = c["service"]["pipelines"]
    kinds = {name.split("/")[0] for name in pipes}      # pipelines may be named e.g. traces/platform
    assert {"traces", "metrics", "logs"} <= kinds, f"pipelines: {sorted(pipes)}"
    assert "memory_limiter" in json.dumps(pipes), "collector pipelines need a memory_limiter processor"


@pytest.mark.phase(1)
def test_no_secrets_committed(root):
    tracked = subprocess.run(["git", "-C", str(root), "ls-files"], capture_output=True, text=True).stdout.split()
    assert ".env" not in tracked, ".env is tracked"
    pat = re.compile(r"(ghp_[A-Za-z0-9]{36}|github_pat_[A-Za-z0-9_]{50,}|-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY-----|AKIA[0-9A-Z]{16})")
    hits = [f for f in tracked if (root / f).is_file() and (root / f).stat().st_size < 1_000_000
            and pat.search((root / f).read_text(errors="ignore"))]
    assert not hits, f"secret-looking material in: {hits}"


@pytest.mark.phase(1)
def test_env_example_covers_every_config_variable(root):
    cfg = (root / "internal/config/config.go").read_text()
    names = set(re.findall(r'env:"([A-Z0-9_]+)', cfg)) or set(re.findall(r'"([A-Z][A-Z0-9_]{3,})"', cfg))
    example = (root / ".env.example").read_text()
    missing = sorted(n for n in names if n not in example)
    assert not missing, f".env.example lacks: {missing}"


# ------------------------------------------------------------- Phase 2 invariants
@pytest.mark.phase(2)
def test_config_validate_checks_every_probe_setting(root):
    """Regression for the defect found in review: PROBE_TIMEOUT missing from validate.go `checks`."""
    v = (root / "internal/config/validate.go").read_text()
    m = re.search(r"checks\s*:?=\s*\[\][^{]*\{(.*?)\n\t\}", v, re.S)
    assert m, "checks slice not found in validate.go"
    assert re.search(r"\bc\.ProbeTimeout\b", m.group(1)), "PROBE_TIMEOUT is not in the positive-duration checks slice"


@pytest.mark.phase(2)
def test_audit_events_table_is_append_only(root):
    sql = "\n".join(p.read_text() for p in (root / "internal/store/migrations").glob("*.sql"))
    assert "audit_events" in sql
    assert re.search(r"(BEFORE\s+(UPDATE|DELETE).*audit_events|REVOKE\s+(UPDATE|DELETE).*audit_events)", sql, re.S | re.I), \
        "no trigger/REVOKE protecting audit_events from UPDATE/DELETE"


@pytest.mark.phase(2)
def test_environments_state_has_check_constraint(root):
    sql = "\n".join(p.read_text() for p in (root / "internal/store/migrations").glob("*.sql"))
    assert "environments" in sql and re.search(r"CHECK\s*\(\s*state\s+IN", sql, re.I), "environments.state lacks a CHECK"


# ------------------------------------------------------------- Phase 7 / productionization
@pytest.mark.phase(7)
def test_ci_workflow_exists_and_runs_verification(root):
    wf = list((root / ".github/workflows").glob("*.y*ml"))
    assert wf, "no GitHub Actions workflow (SPEC-04 P-01)"
    body = "\n".join(p.read_text() for p in wf)
    for needle in ("go test", "bazel", "npm"):
        assert needle in body, f"CI does not run '{needle}'"


@pytest.mark.phase(7)
def test_images_are_pinned_not_latest(root):
    bad = []
    for p in files(root, "deploy/**/*.yaml", "deploy/**/*.yml", "Dockerfile", "web/Dockerfile"):
        for line in p.read_text().splitlines():
            m = re.match(r"\s*(image:|FROM)\s+(\S+)", line)
            if m and (m.group(2).endswith(":latest") or (":" not in m.group(2) and "$" not in m.group(2) and m.group(2) != "scratch")):
                bad.append(f"{p.relative_to(root)}: {line.strip()}")
    assert not bad, bad


@pytest.mark.phase(7)
def test_dockerfiles_run_as_non_root(root):
    bad = [str(p.relative_to(root)) for p in files(root, "Dockerfile", "web/Dockerfile", "**/Dockerfile")
           if not re.search(r"^USER\s+(?!root)", p.read_text(), re.M)]
    assert not bad, f"no non-root USER in: {bad}"


@pytest.mark.phase(7)
def test_production_deploy_artifact_exists(root):
    assert (root / "deploy/helm/ephematool/Chart.yaml").exists() or (root / "deploy/k8s").exists(), "no production deploy manifests (SPEC-04 P-03)"


@pytest.mark.phase(7)
def test_http_server_has_full_timeouts(root):
    src = (root / "cmd/api/main.go").read_text()
    for t in ("ReadTimeout", "WriteTimeout", "IdleTimeout"):
        assert t in src, f"http.Server missing {t} (slowloris)"


@pytest.mark.phase(7)
def test_docs_are_not_stale(root):
    claude = (root / "CLAUDE.md").read_text()
    assert not re.search(r"Fastify|Drizzle|pg-boss", claude), "CLAUDE.md describes a stack the repo does not use (Go)"
    assert (root / "docs").is_dir() and (root / "SECURITY.md").exists(), "docs/ and SECURITY.md missing"
````

### 5.16  `ephematest/tests/test_stack_ops.py`

````python
"""Operational/resilience tests against the docker-compose stack and (Phase 2+) the kind cluster.
These need real infrastructure; they FAIL (not skip) when docker/kubectl are absent."""
import json, subprocess, time
import pytest

COMPOSE = lambda s: ["docker", "compose", "-f", f"{s.repo_root}/{s.compose_file}"]


def sh(cmd, timeout=60) -> str:
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    assert p.returncode == 0, f"{' '.join(cmd)} -> {p.stderr[:300]}"
    return p.stdout


@pytest.mark.phase(1)
@pytest.mark.requires("docker", "repo")
def test_worker_heartbeat_key_in_redis(settings):
    out = sh(COMPOSE(settings) + ["exec", "-T", "redis", "redis-cli", "EXISTS", "worker:heartbeat"])
    assert out.strip() == "1"


@pytest.mark.phase(1)
@pytest.mark.requires("docker", "repo")
def test_loki_outage_is_reflected_then_recovers(settings, admin):
    """Port of status.sh: stop loki -> Down within 25s; start -> healthy within 60s. Always restores loki."""
    def loki_status():
        return next(s["status"] for s in admin.get("/api/status").body["services"] if s["id"] == "loki")
    try:
        sh(COMPOSE(settings) + ["stop", "loki"])
        t0 = time.time()
        while loki_status() != "down" and time.time() - t0 < 25: time.sleep(1)
        assert loki_status() == "down"
    finally:
        sh(COMPOSE(settings) + ["start", "loki"])
    t0 = time.time()
    while loki_status() != "healthy" and time.time() - t0 < 60: time.sleep(2)
    assert loki_status() == "healthy"


@pytest.mark.phase(1)
@pytest.mark.requires("docker", "repo")
def test_redis_outage_degrades_not_crashes_api(settings, admin):
    try:
        sh(COMPOSE(settings) + ["stop", "redis"])
        time.sleep(3)
        assert admin.get("/api/auth/config").status == 200           # process alive, public route works
    finally:
        sh(COMPOSE(settings) + ["start", "redis"])
    time.sleep(5)
    assert admin.get("/api/status").status in (200, 401)


@pytest.mark.phase(2)
@pytest.mark.requires("docker", "repo")
def test_audit_events_db_role_cannot_update_or_delete(settings):
    base = COMPOSE(settings) + ["exec", "-T", "postgres", "psql", "-U", "ephematool_app", "-d", "ephematool", "-tAc"]
    for stmt in ("UPDATE audit_events SET actor='x'", "DELETE FROM audit_events"):
        p = subprocess.run(base + [stmt], capture_output=True, text=True, timeout=30)
        assert p.returncode != 0 or "permission denied" in p.stderr.lower() or "append-only" in (p.stderr + p.stdout).lower(), \
            f"{stmt!r} succeeded for the app role"


@pytest.mark.phase(2)
@pytest.mark.requires("kubectl")
def test_preview_namespaces_have_quota_limitrange_networkpolicy(admin):
    env = admin.create_env().body
    done = admin.wait_state(env["id"], {"running", "failed"}, timeout=600)
    assert done["state"] == "running"
    ns = json.loads(sh(["kubectl", "get", "ns", "-l", f"ephematool.io/env-id={env['id']}", "-o", "json"]))["items"]
    assert len(ns) == 1, "exactly one namespace per environment"
    name = ns[0]["metadata"]["name"]
    for kind in ("resourcequota", "limitrange", "networkpolicy"):
        items = json.loads(sh(["kubectl", "-n", name, "get", kind, "-o", "json"]))["items"]
        assert items, f"namespace {name} has no {kind}"
    labels = ns[0]["metadata"]["labels"]
    assert labels.get("ephematool.io/owner") and labels.get("ephematool.io/expires-at")


@pytest.mark.phase(4)
@pytest.mark.requires("kubectl")
def test_destroy_leaves_no_orphan_namespace(admin):
    env = admin.create_env().body
    admin.wait_state(env["id"], {"running"}, timeout=600)
    admin.delete(f"/api/environments/{env['id']}")
    admin.wait_state(env["id"], {"destroyed"}, timeout=300)
    out = sh(["kubectl", "get", "ns", "-l", f"ephematool.io/env-id={env['id']}", "-o", "name"])
    assert out.strip() == "", f"orphan namespace remains: {out}"


@pytest.mark.phase(5)
@pytest.mark.requires("kubectl")
def test_reconciler_finds_no_cluster_orphans(admin):
    """Every labelled namespace must map to a non-terminal environment (drift/orphan check, pitfall #1)."""
    ns = sh(["kubectl", "get", "ns", "-l", "ephematool.io/env-id", "-o", "jsonpath={range .items[*]}{.metadata.labels.ephematool\\.io/env-id}{\"\\n\"}{end}"]).split()
    for env_id in ns:
        r = admin.get(f"/api/environments/{env_id}")
        assert r.status == 200 and r.body["state"] not in ("destroyed",), f"orphan namespace for env {env_id}"


@pytest.mark.phase(7)
@pytest.mark.requires("docker", "repo")
def test_restart_during_provisioning_still_converges(settings, admin):
    env = admin.create_env().body
    sh(COMPOSE(settings) + ["restart", "worker"])
    done = admin.wait_state(env["id"], {"running", "failed"}, timeout=600)
    assert done["state"] in ("running", "failed"), "environment stuck after worker restart (reaper/CAS recovery broken)"
````

### 5.17  `ephematest/mockstack/__init__.py`

````python

````

### 5.18  `ephematest/mockstack/server.py`

````python
"""Single-process mock of the Ephematool platform (API + fake GitHub + Tempo/Loki/Prometheus).

Purpose: let ephematest be developed and self-tested without Docker/kind/Go. It implements the
contract in SPEC-05 and can inject named faults (MOCK_FAULTS=a,b) so we can prove each test
actually detects the bug it is meant to detect. It is NOT a reference implementation.

Run:  python -m mockstack.server --port 18080 --phase 7 --faults regress_state,quota_off
"""
from __future__ import annotations
import argparse, json, re, secrets, threading, time, uuid
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

USERS = {"octo-admin": "admin", "octo-viewer": "viewer"}          # octo-outsider is not a member
ALLOWED_REPOS = {"tazzledazzle/sampleapp"}
TEMPLATES = {"sampleapp"}
MAX_PER_USER, MAX_TTL, MIN_TTL, DEFAULT_TTL = 3, 86400, 1, 3600
SERVICE_IDS = ["api", "worker", "dashboard", "postgres", "redis", "otel-collector", "tempo", "loki", "prometheus", "grafana"]
SECRET_KEY_RE = re.compile(r"(secret|password|token|apikey|api_key|private)", re.I)
SEC_HEADERS = {"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY",
               "Referrer-Policy": "same-origin", "Cache-Control": "no-store"}


class State:
    def __init__(self, phase: int, faults: set[str], max_per_user: int = MAX_PER_USER):
        self.phase, self.faults, self.max_per_user = phase, faults, max_per_user
        self.lock = threading.RLock()
        self.sessions: dict[str, str] = {}          # token -> login
        self.oauth_states: dict[str, str] = {}
        self.envs: dict[str, dict] = {}
        self.events: list[dict] = []
        self.idem: dict[tuple[str, str], str] = {}
        self.traces: dict[str, dict] = {}
        self.logs: list[tuple[float, str]] = []
        self.status_hits = 0
        self.tasks = 0
        threading.Thread(target=self._tick, daemon=True).start()

    # ---- audit / state machine -------------------------------------------------------
    def emit(self, env: dict, to: str, actor: str, action: str):
        with self.lock:
            frm = env["state"]; env["state"] = to
            if to == "destroying": env["_destroy_at"] = time.time()
            self.events.append({"seq": len(self.events) + 1, "at": time.time(), "actor": actor, "action": action,
                                "env_id": env["id"], "from": frm, "to": to})

    def _tick(self):
        while True:
            time.sleep(0.1)
            now = time.time()
            with self.lock:
                for e in list(self.envs.values()):
                    age = now - e["_created"]
                    st = e["state"]
                    if st == "requested" and age > 0.2:
                        self.emit(e, "provisioning", "system", "provision.start")
                    elif st == "provisioning" and age > 0.6:
                        if e["_fail"]:
                            self.emit(e, "failed", "system", "provision.fail")
                        else:
                            self.emit(e, "running", "system", "provision.ok")
                            e["url"] = f"http://env-{e['id']}.preview.localhost"
                            if "regress_state" in self.faults:     # BUG: goes backwards
                                self.emit(e, "provisioning", "system", "provision.retry")
                                self.emit(e, "running", "system", "provision.ok")
                    elif st == "running" and self.phase >= 5 and "ttl_ignored" not in self.faults and now >= e["_expires"]:
                        self.emit(e, "destroying", "system", "ttl.expired")
                    elif st == "destroying" and now - e["_destroy_at"] > 0.3:
                        self.emit(e, "destroyed", "system", "destroy.ok")

    # ---- observability stores --------------------------------------------------------
    def register_trace(self, tid: str, services: set[str], leak: str = ""):
        with self.lock:
            self.traces[tid] = {"services": services, "leak": leak}

    def log(self, tid: str, msg: str, svc="ephematool-api", **kv):
        line = json.dumps({"msg": msg, "trace_id": tid, "service_name": svc, **kv})
        with self.lock:
            self.logs.append((time.time(), line))


def public(e: dict, hide_secrets=True) -> dict:
    out = {k: v for k, v in e.items() if not k.startswith("_")}
    if hide_secrets:
        out["values"] = {k: ("[redacted]" if SECRET_KEY_RE.search(k) else v) for k, v in e["values"].items()}
    return out


def make_handler(st: State):
    class H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        def log_message(self, *a): pass

        # ---- plumbing ----------------------------------------------------------------
        def _send(self, code: int, body=None, headers: dict | None = None, raw: str | None = None):
            data = (raw if raw is not None else (json.dumps(body) if body is not None else "")).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            if "no_trace_header" not in st.faults and self.path.startswith("/api"):
                self.send_header("X-Trace-Id", self.tid)
            if "no_security_headers" not in st.faults:
                for k, v in SEC_HEADERS.items(): self.send_header(k, v)
            for k, v in (headers or {}).items():
                if isinstance(v, list):
                    for i in v: self.send_header(k, i)
                else: self.send_header(k, v)
            self.end_headers()
            self.wfile.write(data)

        def _json(self):
            if not self._body: return {}
            try: return json.loads(self._body)
            except ValueError: return None

        def _login(self):
            c = SimpleCookie(self.headers.get("Cookie", ""))
            tok = c.get("ephematool_session")
            return (st.sessions.get(tok.value), tok.value) if tok and tok.value in st.sessions else (None, "")

        def _err(self, code, msg): self._send(code, {"error": msg, "status": code})

        def handle_any(self, method: str):
            u = urlsplit(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
            self.tid = uuid.uuid4().hex
            # Always drain the body up front: leaving it unread corrupts the next keep-alive request.
            self._body = self.rfile.read(int(self.headers.get("Content-Length") or 0))
            p = u.path
            who, tok = self._login()
            try:
                if p.startswith(("/tempo", "/loki", "/prom")): return self.obs(p, q)
                if p.startswith("/fakegh/authorize"): return self.fakegh(q)
                if p == "/preview/auth": return self.preview_gate()
                st.register_trace(self.tid, {"ephematool-api"} | ({"ephematool-worker"} if p == "/api/status" else set()),
                                  leak=(f"cookie: ephematool_session={tok}" if "leak_secret" in st.faults and tok else ""))
                st.log(self.tid, f"{method} {p}")
                return self.route(method, p, q, who, tok)
            except BrokenPipeError:
                pass
            except Exception as ex:   # mock bug => 500 so tests show it
                self._err(500, repr(ex))

        do_GET = lambda s: s.handle_any("GET")
        do_POST = lambda s: s.handle_any("POST")
        do_DELETE = lambda s: s.handle_any("DELETE")
        do_PUT = lambda s: s.handle_any("PUT")
        do_PATCH = lambda s: s.handle_any("PATCH")

        # ---- fake GitHub ---------------------------------------------------------------
        def fakegh(self, q):
            self._send(302, headers={"Location": f"/api/auth/github/callback?code={q.get('login','')}&state={q.get('state','')}"})

        # ---- routes --------------------------------------------------------------------
        def route(self, m, p, q, who, tok):
            if p in ("/healthz", "/readyz") and m == "GET": return self._send(200, {"status": "ok"})
            if p == "/api/auth/config": return self._send(200, {"provider": "github", "login_url": "/api/auth/github/login"})
            if p == "/api/auth/github/login":
                state = secrets.token_hex(8)
                st.oauth_states[state] = q.get("next", "/")
                return self._send(302, headers={"Location": f"http://{self.headers['Host']}/fakegh/authorize?state={state}"})
            if p == "/api/auth/github/callback":
                nxt = st.oauth_states.pop(q.get("state", ""), None)
                if nxt is None: return self._err(400, "bad state")
                login = q.get("code", "")
                if login not in USERS:
                    st.log(self.tid, "auth.denied", login=login)
                    return self._send(302, headers={"Location": "/denied?reason=not_member"})
                t = secrets.token_hex(16); st.sessions[t] = login
                safe = nxt if (nxt.startswith("/") and not nxt.startswith("//") and "\\" not in nxt) or "open_redirect" in st.faults else "/"
                return self._send(302, headers={"Location": safe, "Set-Cookie": f"ephematool_session={t}; Path=/; HttpOnly; SameSite=Lax"})
            if p == "/api/auth/logout" and m == "POST":
                st.sessions.pop(tok, None)
                return self._send(204, headers={"Set-Cookie": "ephematool_session=; Path=/; Max-Age=0"})
            if p == "/api/me":
                if not who: return self._err(401, "unauthenticated")
                return self._send(200, {"login": who, "role": USERS[who]})
            if p == "/api/status":
                if not who: return self._err(401, "unauthenticated")
                st.status_hits += 1; st.tasks += 1
                ids = list(SERVICE_IDS)
                if "status_wrong_order" in st.faults: ids[0], ids[1] = ids[1], ids[0]
                st.log(self.tid, "worker ping", svc="ephematool-worker")
                return self._send(200, {"services": [{"id": i, "status": "healthy", "detail": ""} for i in ids]})
            if p == "/api/orphans" and st.phase >= 3:
                if not who: return self._err(401, "unauthenticated")
                return self._send(200, {"orphans": []}) if USERS[who] == "admin" else self._err(403, "admin only")
            if p.startswith("/api/environments") or p.startswith("/api/audit"):
                if st.phase < 2: return self._err(404, "not implemented")
                return self.envs(m, p, q, who)
            return self._err(404, "not found")

        # ---- environments --------------------------------------------------------------
        def envs(self, m, p, q, who):
            if p.startswith("/api/audit"): return self.audit(m, p, q, who)
            create_open = "no_auth_on_create" in st.faults
            if not who and not (m == "POST" and p == "/api/environments" and create_open):
                return self._err(401, "unauthenticated")
            who = who or "octo-admin"
            role = USERS[who]
            parts = p.strip("/").split("/")          # api environments [id [sub]]
            if p == "/api/environments" and m == "POST": return self.create(who, role)
            if p == "/api/environments" and m == "GET": return self.list_envs(q)
            if len(parts) >= 3:
                env = st.envs.get(parts[2])
                if not env: return self._err(404, "no such environment")
                sub = parts[3] if len(parts) > 3 else ""
                if sub == "" and m == "GET": return self._send(200, public(env, "echo_secrets" not in st.faults))
                if sub == "events" and m == "GET":
                    return self._send(200, {"events": [e for e in st.events if e["env_id"] == env["id"]]})
                if sub == "health" and m == "GET" and st.phase >= 4:
                    return self._send(200, {"state": env["state"], "healthy": env["state"] == "running",
                                            "signals": {"workflow": env["state"] != "failed", "probe": env["state"] == "running"}})
                if sub == "links" and m == "GET" and st.phase >= 6:
                    return self._send(200, {"grafana": f"http://grafana/d/env?var-env={env['id']}", "traces": f"http://grafana/explore?env={env['id']}"})
                if sub == "preview-link" and m == "POST":
                    if env["state"] != "running": return self._err(409, "environment not running")
                    return self._send(200, {"url": env["url"], "token": env["_ptoken"]})
                if sub == "" and m == "DELETE" and st.phase >= 3:
                    if role != "admin" and env["owner"] != who and "delete_any" not in st.faults:
                        return self._err(403, "not owner")
                    if env["state"] in ("destroying", "destroyed"): return self._send(202, public(env))
                    st.emit(env, "destroying", who, "destroy.request"); env["_destroy_at"] = time.time()
                    return self._send(202, public(env))
                if sub == "extend" and m == "POST" and st.phase >= 5:
                    body = self._json() or {}
                    add = body.get("ttl_seconds", 0)
                    if not isinstance(add, int) or add <= 0 or env["ttl_seconds"] + add > MAX_TTL: return self._err(422, "bad ttl")
                    env["ttl_seconds"] += add; env["_expires"] += add
                    env["ttl_expires_at"] = env["_expires"]
                    st.events.append({"seq": len(st.events) + 1, "at": time.time(), "actor": who, "action": "ttl.extend",
                                      "env_id": env["id"], "from": env["state"], "to": env["state"]})
                    return self._send(200, public(env))
            return self._err(404, "not found")

        def create(self, who, role):
            if role == "viewer" and "viewer_can_create" not in st.faults: return self._err(403, "viewer role is read-only")
            b = self._json()
            if not isinstance(b, dict): return self._err(400, "invalid json")
            repo, tmpl, ref = b.get("repo"), b.get("template"), b.get("ref")
            if not all(isinstance(x, str) and x for x in (repo, tmpl, ref)): return self._err(422, "repo, ref, template required")
            if repo not in ALLOWED_REPOS and "allowlist_off" not in st.faults: return self._err(403, "repo not allowed")
            if tmpl not in TEMPLATES: return self._err(422, "unknown template")
            ttl = b.get("ttl_seconds", DEFAULT_TTL)
            if not isinstance(ttl, int) or isinstance(ttl, bool) or ttl < MIN_TTL: return self._err(422, "ttl too small")
            if ttl > MAX_TTL and "no_ttl_cap" not in st.faults: return self._err(422, "ttl too large")
            values = b.get("values", {})
            if not isinstance(values, dict): return self._err(422, "values must be an object")
            for v in values.values():
                if isinstance(v, dict) and "secretRef" in v and v["secretRef"] not in {"sampleapp-db"}:
                    return self._err(403, "secret not in scope")
            if any(SECRET_KEY_RE.search(k) for k in values) and "echo_secrets" not in st.faults and "plain_secrets" not in st.faults:
                return self._err(422, "secret-looking keys are not allowed in values")
            idem = self.headers.get("Idempotency-Key")
            with st.lock:
                if idem and (who, idem) in st.idem and "idempotency_broken" not in st.faults:
                    return self._send(200, public(st.envs[st.idem[(who, idem)]]))
                active = [e for e in st.envs.values() if e["owner"] == who and e["state"] not in ("failed", "destroyed")]
                if len(active) >= st.max_per_user and "quota_off" not in st.faults:
                    return self._send(429, {"error": "quota exceeded", "status": 429, "limit": st.max_per_user, "active": len(active)}, headers={"Retry-After": "5"})
                eid = secrets.token_hex(4); now = time.time()
                env = {"id": eid, "state": "requested", "owner": who, "repo": repo, "ref": ref, "template": tmpl,
                       "ttl_seconds": ttl, "ttl_expires_at": now + ttl, "url": None, "values": values, "created_at": now,
                       "_created": now, "_expires": now + ttl, "_fail": bool(values.get("fail")), "_ptoken": secrets.token_hex(12)}
                st.envs[eid] = env
                st.events.append({"seq": len(st.events) + 1, "at": now, "actor": who, "action": "env.create",
                                  "env_id": eid, "from": None, "to": "requested"})
                if idem: st.idem[(who, idem)] = eid
            return self._send(202, public(env, "echo_secrets" not in st.faults), headers={"Location": f"/api/environments/{eid}"})

        def list_envs(self, q):
            items = [public(e) for e in sorted(st.envs.values(), key=lambda e: e["created_at"])]
            if st.phase >= 3:
                if "state" in q: items = [i for i in items if i["state"] == q["state"]]
                if "owner" in q: items = [i for i in items if i["owner"] == q["owner"]]
                lim = int(q.get("limit", 50)); off = int(q.get("cursor", 0))
                page = items[off:off + lim]
                nxt = str(off + lim) if off + lim < len(items) else None
                return self._send(200, {"environments": page, "next_cursor": nxt})
            return self._send(200, {"environments": items})

        def audit(self, m, p, q, who):
            if not who: return self._err(401, "unauthenticated")
            if USERS[who] != "admin": return self._err(403, "admin only")
            if m == "GET" and p == "/api/audit": return self._send(200, {"events": list(st.events)})
            if m in ("PUT", "PATCH", "DELETE", "POST"):
                if "audit_mutable" in st.faults:
                    if m == "DELETE" and st.events: st.events.pop(); return self._send(204)
                return self._err(405, "audit log is append-only")
            return self._err(404, "not found")

        def preview_gate(self):
            host = self.headers.get("X-Forwarded-Host", ""); tokh = self.headers.get("X-Preview-Token", "")
            mt = re.match(r"env-([0-9a-f]+)\.", host)
            if "preview_gate_open" in st.faults: return self._send(200, {"ok": True})
            if not mt or mt.group(1) not in st.envs: return self._send(404, {"error": "unknown env"})
            if not tokh: return self._send(401, {"error": "token required"})
            return self._send(200, {"ok": True}) if tokh == st.envs[mt.group(1)]["_ptoken"] else self._send(403, {"error": "wrong env token"})

        # ---- fake Tempo / Loki / Prometheus --------------------------------------------
        def obs(self, p, q):
            if p.endswith(("/ready", "/-/ready")): return self._send(200, raw="ready")
            if p.startswith("/tempo/api/traces/"):
                t = st.traces.get(p.rsplit("/", 1)[1])
                if not t: return self._send(404, {"error": "not found"})
                attrs = [{"key": "service.name", "value": {"stringValue": s}} for s in t["services"]]
                span_attrs = [{"key": "http.route", "value": {"stringValue": "/api/status"}}]
                if t["leak"]: span_attrs.append({"key": "http.request.header.cookie", "value": {"stringValue": t["leak"]}})
                return self._send(200, {"batches": [{"resource": {"attributes": attrs}, "scopeSpans": [{"spans": [{"name": "x", "attributes": span_attrs}]}]}]})
            if p.startswith("/loki/loki/api/v1/query_range"):
                query = q.get("query", "")
                tid = re.search(r'trace_id="([0-9a-f]+)"', query)
                svc = re.search(r'service_name="([^"]+)"', query)
                out = []
                for ts, line in st.logs:
                    d = json.loads(line)
                    if tid and d["trace_id"] != tid.group(1): continue
                    if svc and d["service_name"] != svc.group(1): continue
                    if "auth.denied" in query and d["msg"] != "auth.denied": continue
                    out.append([str(int(ts * 1e9)), line])
                return self._send(200, {"data": {"result": [{"values": out}] if out else []}})
            if p.startswith("/prom/api/v1/query"):
                qq = q.get("query", "")
                val = st.status_hits if "http_server_request_duration_seconds_count" in qq else st.tasks if "queue_task_processed_total" in qq else None
                return self._send(200, {"data": {"result": [{"value": [time.time(), str(val)]}] if val else []}})
            return self._err(404, "not found")
    return H


class QuietServer(ThreadingHTTPServer):
    daemon_threads = True
    def handle_error(self, request, client_address): pass     # client aborts are not mock bugs


def serve(port: int, phase: int, faults: set[str], max_per_user: int = 1000) -> ThreadingHTTPServer:
    srv = QuietServer(("127.0.0.1", port), make_handler(State(phase, faults, max_per_user)))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=18080); ap.add_argument("--phase", type=int, default=7)
    ap.add_argument("--faults", default=""); ap.add_argument("--max-per-user", type=int, default=1000)
    a = ap.parse_args()
    serve(a.port, a.phase, {f for f in a.faults.split(",") if f}, a.max_per_user)
    print(f"mock listening on :{a.port} phase={a.phase} faults={a.faults or '-'}", flush=True)
    while True: time.sleep(3600)
````

### 5.19  `ephematest/selftest.py`

````python
"""Prove the tests detect what they claim to: run the suite against the mock with no faults (must pass),
then once per injected fault (the designated detector tests must fail).
Usage: python selftest.py [--phase N]"""
from __future__ import annotations
import ast, subprocess, sys, os, re, time, argparse
from pathlib import Path
import threading
from mockstack.server import serve

HERE = Path(__file__).parent
FAULT_RE = re.compile(r'pytest\.mark\.fault\("([a-z_]+)"\)')


def all_faults() -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for f in (HERE / "tests").glob("test_*.py"):
        for m in FAULT_RE.finditer(f.read_text()):
            out.setdefault(m.group(1), []).append(f.name)
    return out


def run(port: int, phase: int, extra: list[str], quota: bool = False) -> tuple[int, str]:
    env = {**os.environ, "API_URL": f"http://127.0.0.1:{port}", "TEMPO_URL": f"http://127.0.0.1:{port}/tempo",
           "LOKI_URL": f"http://127.0.0.1:{port}/loki", "PROM_URL": f"http://127.0.0.1:{port}/prom",
           "EPHEMA_MAX_PER_USER": "3", "EPHEMA_PROVISION_TIMEOUT": "15", "EPHEMA_OBS_TIMEOUT": "5"}
    p = subprocess.run([sys.executable, "-m", "pytest", "tests", "-q", "--expect-phase", str(phase),
                        "--allow-missing-caps", *(["--quota-mode"] if quota else []), "-p", "no:cacheprovider", *extra], capture_output=True, text=True, cwd=HERE, env=env)
    return p.returncode, p.stdout + p.stderr


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--phase", type=int, default=7)
    a = ap.parse_args()
    ok = True
    for label, port, quota in (("general", 18100, False), ("quota-mode", 18099, True)):
        srv = serve(port, a.phase, set(), 3 if quota else 1000)
        rc, out = run(port, a.phase, [], quota)
        print(f"BASELINE {label} (no faults):", next(l for l in reversed(out.splitlines()) if " passed" in l or " failed" in l)); srv.shutdown()
        if rc != 0: print(out[-3000:]); ok = False
    for i, (fault, _) in enumerate(sorted(all_faults().items())):
        port = 18101 + i
        quota = fault == "quota_off"
        srv = serve(port, a.phase, {fault}, 3 if quota else 1000)
        rc, out = run(port, a.phase, ["-m", "fault"], quota)
        failed = [l for l in out.splitlines() if l.startswith("FAILED")]
        detected = rc != 0 and bool(failed)
        print(f"fault {fault:22s} -> {'DETECTED' if detected else 'MISSED  <<<<'} ({len(failed)} failing)")
        ok &= detected; srv.shutdown()
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
````
