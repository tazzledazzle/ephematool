# SPEC-04 — Productionization (cross-cutting; not covered by any roadmap phase)

Each item: **why → change → acceptance**. Files referenced live in `code/` (YAML/Go syntax-checked; Go tested). IDs map to SPEC-00 gaps.

## P-01 CI pipeline (G-08, finding D-6)
Add `.github/workflows/ci.yaml` = `code/ci/ci.yaml`. Jobs: `lint-test` (gofmt, vet, `go test -race`, govulncheck, generated-file drift for openapi/conventions), `web` (lint/typecheck/test/build, `npm audit`), `verify-stack` (existing `bazel run //:up_fake` + `//:verify`), `ephematest` (self-test, then Phase gate with `EXPECT_PHASE`, then `--quota-mode`), `images` (main only: build, SBOM + provenance, Trivy, attestations).
Branch protection on `main`: require all four PR jobs, 1 review, signed commits optional, linear history. Dependabot for `gomod`, `npm`, `docker`, `github-actions`; pin Actions to commit SHAs (the YAML shows tags for readability).
**Acceptance:** a PR that reverts a Phase-1 behaviour fails `ephematest`; `test_ci_workflow_exists_and_runs_verification` passes.

## P-02 Release & supply chain
Semantic versioning from tags `vX.Y.Z`; `release.yaml` builds multi-arch images (`linux/amd64,arm64`), pushes `:vX.Y.Z` and `@sha256` digest, cosign keyless sign + attest SBOM, creates a GitHub Release with the Helm chart packaged (`helm package`, push to OCI `ghcr.io/…/charts`). Deploys reference **digests**. Add `buildinfo` version to `/api/status` footer and a `version` field in `/readyz`.
**Acceptance:** `cosign verify` succeeds in the deploy job before `helm upgrade`.

## P-03 Production deployment — Helm chart (G-09, D-7)
Use `code/deploy/helm/ephematool/` (Chart, values, API Deployment+PDB+HPA, migration Job hook, default-deny NetworkPolicy). To complete: `worker.yaml` (same pod hardening; no HPA at first; `replicas: 2`), `web.yaml` (switch image to `nginxinc/nginx-unprivileged`, port 8080, read-only FS with `emptyDir` for `/tmp`, `/var/cache/nginx`), `ingress.yaml` (TLS, `proxy-body-size 1m`, `ssl-redirect`), `serviceaccount/rbac.yaml` (API/worker get **no** cluster rights by default; the provisioner ServiceAccount from plan 02-13 is separate and namespaced), `configmap.yaml` (non-secret env from `values.config`).
Rules: all secrets come from pre-existing `Secret`s (External Secrets Operator or sealed-secrets) — **the chart never templates a secret value**; `image.tag` is `required`; pods run non-root, read-only root FS, drop ALL caps, seccomp RuntimeDefault, no SA token automount for api/web.
Validation to add to CI: `helm lint`, `helm template … | kubeconform -strict`, `conftest` policies (no `:latest`, no privileged, resources set). *Not run in this sandbox (no helm/kubeconform) — first CI run will find syntax mistakes in the templates; fix them there.*
`/app drain` in the sample `preStop` is a to-be-implemented subcommand (or use the in-process SIGTERM handler: on SIGTERM call `probes.Set.Drain()`, sleep 5 s for endpoint removal, then `srv.Shutdown`). Distroless has no shell, so do not use `sleep` via `exec`.
**Acceptance:** `helm install` into a kind cluster passes `kubectl rollout status`; `ephematest` Phase gate passes against the ingress URL; `test_production_deploy_artifact_exists`.

## P-04 Topology & data stores (G-09)
* **Postgres:** managed (RDS/Cloud SQL) or CloudNativePG with 2 replicas, PITR. Two roles: `ephematool_owner` (migrations only) and `ephematool_app` (runtime; no DDL, audit INSERT/SELECT only — migration 00003). `sslmode=verify-full`. Pool: `MaxConns = 10 per pod` (document the arithmetic against `max_connections`).
* **Redis:** managed or Sentinel/replicated with `requirepass`/ACL (IN-06), AOF `everysec` (backlog #12), `maxmemory-policy noeviction` (queue/session data must not be evicted). Session store and asynq share an instance in v1 but use separate logical DBs and key prefixes.
* **Single points to remove:** API ×2 (HPA 2–6), worker ×2, web ×2; PDBs; topology spread. Worker scale-out is safe because every task is idempotent (SPEC-02 rule 1/4) — add a test that runs two workers against one queue and asserts each env transitions exactly once.
* **Observability backends** (Tempo/Loki/Prometheus/Grafana): in production use the org's existing stack or the Grafana helm charts with object storage and retention (Loki compactor retention, backlog #6; Tempo 7 d; Prometheus 15 d + remote write). The compose stack stays dev-only.

## P-05 Runtime hardening (G-10, findings D-4/D-5)
| Control | Change | Check |
|---|---|---|
| HTTP timeouts + body limits | SPEC-01 A3 | `test_http_server_has_full_timeouts` |
| Security headers/CSP (IN-04) | nginx: `add_header X-Content-Type-Options nosniff always; X-Frame-Options DENY always; Referrer-Policy same-origin always; Permissions-Policy "geolocation=(),camera=(),microphone=()" always; Strict-Transport-Security "max-age=31536000; includeSubDomains" always (TLS only); Content-Security-Policy "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self' https://github.com"`. API adds `Cache-Control: no-store` on authenticated JSON | `test_security_headers_present` (+ add a CSP assertion for the web origin) |
| Non-root web image | `nginxinc/nginx-unprivileged`, `USER 101`, listen 8080 | `test_dockerfiles_run_as_non_root` |
| Rate limiting | nginx `limit_req_zone` per IP on `/api/auth/*` (10 r/m, burst 20) and a per-session token bucket in the API for `POST /api/environments` (reuses Redis) → 429 + `Retry-After` | proposed test (not yet in ephematest): 30 rapid logins → some 429 |
| Grafana anon role (WR-05) | `GF_AUTH_ANONYMOUS_ENABLED=false` in production; Viewer via GitHub OAuth/OIDC | helm values test |
| Browser telemetry trust (WR-04) | separate collector receiver for the browser path with its own memory limiter and attribute allow-list (plan 02-09 does this for environments; mirror it for the dashboard) | redaction gate |
| Session hardening | `SameSite=Lax` (Strict breaks the OAuth return), `Secure`, `HttpOnly`, idle + absolute timeouts, re-validate team membership every `ROLE_REVALIDATE_INTERVAL` (WR-01) | existing + role-change test |
| CSRF | state-changing API calls require `Content-Type: application/json` and a custom header (`X-Requested-With: ephematool`) or double-submit token; reject `text/plain` form posts | proposed test (not yet in ephematest): cross-site-style form POST → 403/415 |

## P-06 GitHub webhook receiver (G-11)
Route `POST /webhooks/github` served by the **API process on a separate listener/path excluded from session auth** (public marker, WR-02) and exposed through the ingress with an IP allow-list from `https://api.github.com/meta` (optional). Use `code/webhook`: HMAC-SHA256 verify (constant time), 1 MiB cap, event allow-list (`pull_request`, `workflow_run`, `ping`), `X-GitHub-Delivery` dedupe (Redis `SET NX EX 86400` in production), 202 on accept/duplicate/ignored, 401 on bad signature, 503 only if the enqueue fails. Handlers only enqueue `env:reconcile` / `env:destroy` (SPEC-02 rule 3). Secret rotation: accept two secrets during rotation (`GITHUB_WEBHOOK_SECRET`, `GITHUB_WEBHOOK_SECRET_PREVIOUS`).
**Acceptance:** `go test ./webhook` (7 assertions: signature matrix, replay, unknown event, oversize, wrong method); end-to-end with fake GitHub: deliver `pull_request.closed` → env destroyed; drop the delivery → reconciler destroys within one sweep (SPEC-02 P5.4).

## P-07 Lifecycle plumbing (G-12)
* `code/probes`: `/healthz` (no deps), `/readyz` (parallel checks with timeout; Postgres+Redis critical, collector/Tempo not; driver errors are never echoed). Wire into `cmd/api` and a worker-side tiny HTTP server (`:9091`) so Kubernetes can probe the worker.
* Graceful shutdown: SIGTERM → `Drain()` → wait 5 s → `srv.Shutdown(25 s)` → asynq `srv.Shutdown()` (finishes in-flight tasks; unfinished are retried — safe because idempotent) → flush OTel providers (2 s budget).
* Migrations: `api migrate` is the Helm pre-upgrade Job; `MIGRATE_ON_START=false` in production; the advisory-lock Provider (SPEC-01 A2) protects the dev/compose path.
**Acceptance:** `test_health_and_readiness_endpoints`; kill -TERM during an in-flight request leaves zero 5xx in a 60 s load run (to be added to `test_concurrency_load.py`; not yet written).

## P-08 Backup, retention, DR (G-13)
Targets: RPO 15 min, RTO 1 h for the platform DB. PITR on Postgres; nightly logical dump of `audit_events` to write-once object storage (audit must outlive the DB). Redis is rebuildable *except* queued/scheduled tasks — the reconciler (SPEC-02 P3.2) re-derives work from the DB, which is the property that makes Redis loss survivable; **test it**: flush Redis during a run and assert all envs still converge (`ephematest` ops test `test_restart_during_provisioning_still_converges` exists; a Redis-flush variant is still to be written). Quarterly restore drill documented in the runbook. Audit retention: ≥ 1 year, partition `audit_events` by month once > 10 M rows (non-breaking because of `seq` + `at` index).

## P-09 SLOs, alerts, runbooks (G-14)
SLIs/SLOs (28-day): API availability 99.5 % (non-5xx), API p95 < 1.5 s, **time-to-ready p90 < 10 min**, **zero leaked namespaces older than 30 min**, TTL accuracy (environments destroyed within 2 × sweep interval after expiry) 99 %. Alert rules: `code/deploy/prometheus/ephematool-rules.yaml` (error ratio, latency, worker stalled, queue backlog, drift, stuck destroying, orphans, slow provisioning) — **PromQL not validated here (no promtool); run `promtool check rules` and unit-test with `promtool test rules` in CI**. Each alert's `runbook` annotation must resolve to a file in `docs/runbooks/` (add a CI check). Runbooks to write: api-errors, api-latency, worker-stalled, queue-backlog, drift, destroy-stuck (finalizers), orphans, provision-slow, redis-loss, db-restore, rotate-secrets (OAuth secret, App key, webhook secret, session/preview signing keys with `kid`).
Self-observability dashboard: Grafana JSON `platform.json` (RED for API, queue depth/latency, envs by state, verdict gauge, time-to-ready heatmap).

## P-10 Documentation (G-15, findings D-1/D-8)
1. Fix **CLAUDE.md** stack block (Go/huma/asynq/pgx/React/Bazel) via the GSD flow it mandates; delete the Fastify/Drizzle/pg-boss text. `test_docs_are_not_stale` gates it.
2. Split README: `README.md` (what/why, 5-minute quickstart), `docs/architecture.md`, `docs/operations.md` (the existing runbook), `docs/security.md`, `docs/runbooks/*`, `docs/decisions/NNNN-*.md` (ADRs for D-01…D-26 that are hard to reverse: kind+self-hosted runner, Traefik ForwardAuth gate, DB-enforced append-only audit, CAS state machine).
3. `SECURITY.md` (private reporting via GitHub Security Advisories, supported versions), `CONTRIBUTING.md` (how to run `ephematest`, GSD workflow), `LICENSE`.
4. OpenAPI published as an artifact in releases; `api/openapi.json` drift already checked in CI.

## P-11 Remote clusters via OIDC (G-16, optional)
Deferred decision D-02. Design when needed: the provisioner workflow assumes a cloud role via GitHub OIDC (`id-token: write`), trust policy pinned to `repo:<org>/<environments-repo>:environment:<name>` and the ref; the role can only manage namespaces with the `pv-` prefix (IAM/RBAC condition); no long-lived cluster credentials anywhere. Add `ephematest` kubectl tests against the remote context via `KUBECONFIG`.

## P-12 Repo hygiene (D-11)
Rename the Go module to `github.com/tazzledazzle/ephematool` (or keep and document); one mechanical PR (`go mod edit -module`, rewrite imports, regenerate sqlc/openapi, update ldflags `-X` paths in `Dockerfile` and `BUILD.bazel`). Add CODEOWNERS, issue/PR templates (use the existing backlog labels), `.editorconfig`.

## Production readiness checklist (gate for "v1.0")
- [ ] All roadmap phases complete; `ephematest --expect-phase 7` and `--quota-mode` green in CI for 10 consecutive runs
- [ ] Phase 1 UAT (#1, #2) done with the real GitHub OAuth App; Phase 2 manual UAT list done
- [ ] P-01…P-10 merged; `test_repo_static.py` fully green (no xfail)
- [ ] Load test: 50 concurrent creates against a 3-node kind/real cluster; no orphan namespaces after teardown; p95 API latency within SLO
- [ ] Restore drill performed; secret-rotation drill performed
- [ ] Threat-model review of: preview gate (ENV-09), provisioner fencing, webhook endpoint, secret refs
