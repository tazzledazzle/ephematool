# SPEC-01 — Finish Phase 2 (Create a Secure Preview Environment) + Phase 1 hardening

Source of truth for scope: `.planning/phases/02-*/02-01…02-17-PLAN.md` (17 plans, 8 waves). This spec does **not** replace them; it (a) fixes defects found in review, (b) adds the pieces the plans leave implicit, (c) gives code for the highest-risk parts, and (d) defines acceptance as `ephematest --expect-phase 2`.

## A. Do first (Wave 0, ≤ 2 days) — unblock everything else

### A1. Config validation correctness (backlog #3, finding D-2/D-3)
File `internal/config/validate.go`.
1. Add `{"PROBE_TIMEOUT", c.ProbeTimeout}` to the `checks` slice (today it is only compared, never checked `> 0`).
2. Fix the message at the relational check: `ENV_PROBE_TIMEOUT must be < ENV_PROBE_INTERVAL` (the variable behind `c.EnvProbeInitial` is `ENV_PROBE_INTERVAL`).
3. Delete the stale `// TODO` markers (the rules exist below them).
4. Table-driven test: for each name in `checks`, set that field to 0 and assert the error names the variable.
5. **Acceptance:** `ephematest tests/test_repo_static.py::test_config_validate_checks_every_probe_setting` passes.

### A2. Serialise migrate-on-start (backlog #4, D-10) — required before any rolling deploy
`store.Migrate` uses goose globals with no lock; two replicas can race. Plan 02-04 already moves to goose's Provider with a session locker. Acceptance additions:
```go
// internal/store/migrate.go (sketch - compile against the repo's pinned goose version)
p, err := goose.NewProvider(goose.DialectPostgres, db, migrations,
    goose.WithSessionLocker(lock.NewPostgresSessionLocker()))   // pg_advisory_lock under the hood
if err != nil { return err }
_, err = p.Up(ctx)
```
Test: start 3 goroutines calling `Migrate` against one empty DB; all return nil and `goose_db_version` has exactly one row per migration. In production, set `MIGRATE_ON_START=false` on the API and run the same code as a Helm pre-upgrade Job (SPEC-04 P-07).

### A3. Server timeouts (backlog #9, D-4)
```go
srv := &http.Server{
    Addr: cfg.HTTPAddr, Handler: handler,
    ReadHeaderTimeout: 10 * time.Second,
    ReadTimeout:       30 * time.Second,
    WriteTimeout:      60 * time.Second,   // longest non-streaming handler; SSE/streams must use http.ResponseController.SetWriteDeadline
    IdleTimeout:       120 * time.Second,
    MaxHeaderBytes:    1 << 16,
}
```
Plus `srv.Shutdown(ctx)` with a 25 s budget on SIGTERM (verify it already exists) and `http.MaxBytesReader` (1 MiB) in the create handler.

### A4. Remaining Phase 1 hardening that gates Phase 2 mutations
| Item | Change | Acceptance |
|---|---|---|
| WR-02 secure-by-default routes | Plan 02-06 inverts auth; add a **test that enumerates every huma operation** and fails if one is neither `Public` nor guarded | unit test over `api.OpenAPI().Paths` |
| WR-10 session reset on login | `sessions.RenewToken` + clear values before storing the identity | `ephematest test_logout_invalidates_session` + unit test |
| WR-03 cookie secure flag vs scheme | already enforced in `validate.go` rule group 4; keep the test | existing |
| WR-01 re-validate membership | Plan 02-06 `RoleResolver` (request-time team check, D-06) | integration test with fake GitHub membership change |
| IN-04 headers/CSP, WR-05 Grafana anon role, IN-06 Redis auth | Plan 02-15 covers IN-04; add the other two in SPEC-04 P-05 | `test_security_headers_present` |
| #5 Host header with port, #10 nginx upstream re-resolution, #12 Redis persistence, #6 Loki retention, #11 collector tidy, #14 histogram buckets | schedule as one "hardening pass" plan between 02-02 and 02-04 (the ROADMAP suggests this) | each issue's own acceptance |
| #7, #13 test hygiene | `verify.sh` uses an isolated compose project name; integration tests **fail** without Docker (the new `ephematest` plugin already behaves this way) | CI job |

## B. Schema (plan 02-04) — ready-to-apply migrations
Use `code/migrations/00002_environments.sql` and `00003_audit_events.sql` (in this bundle; applied and exercised on Postgres 16):

* `environments.id` CHECK `^pv-[a-z0-9]{10}$`, `state` CHECK over the 6 states, `running ⇒ url NOT NULL`, resolved 40-hex `sha`, `expires_at > created_at`, partial indexes for quota/expiry/PR lookups.
* `audit_events` is append-only **in the database**: `ephematool_app` has only `SELECT, INSERT`; `BEFORE UPDATE OR DELETE` and `BEFORE TRUNCATE` triggers reject everyone including the owner.
* Verified results: id/state/url constraints reject bad rows; app role gets `permission denied` for UPDATE/DELETE/TRUNCATE on audit and DELETE on environments; owner UPDATE is blocked by the trigger.
* sqlc queries to add (`internal/store/queries/environments.sql`): `InsertEnvironment`, `GetEnvironment`, `ListEnvironments` (keyset by `(created_at,id)`), `CASState` (below), `CountActiveByOwner|Repo`, `ListExpiredForClaim`.

```sql
-- name: CASState :execrows
UPDATE environments
   SET state = $3, state_version = state_version + 1, updated_at = now(),
       failure_reason = COALESCE($4, failure_reason)
 WHERE id = $1 AND state = $2;
```
Go side: `code/envstate` (forward-only graph, `Advance`, tests including a 64-way race with exactly one winner). Wrap `CASState` + audit insert in one transaction (`pgx.BeginFunc`), and map `rows == 0` → `ErrLostRace`.

## C. Dependencies you must not skip
1. **Plan 02-01 human gate** (package legitimacy audit) — blocking; nothing in 02-05/07/08/13 may start before it.
2. **Plan 02-03 fake GitHub extension** — every later test depends on it. Add the control endpoints used by `ephematest` fixtures: `POST /__fake/runs/{id}/conclude?result=success|failure`, `POST /__fake/membership?login=&team=` , `POST /__fake/reset`.
3. Create the **GitHub App** (least privilege: Actions RW, Contents R, Pull requests RW, Metadata R, no org permissions beyond Members R) and the **environments repo** with the thin workflow (D-14) — documented in plan 02-17; do it early because UAT needs it.

## D. Create API + worker (plans 02-10, 02-11) — behaviours to nail
Contract the black-box suite enforces (adjust paths via `EPHEMA_*` if the real API differs — see SPEC-05 §Contract alignment):

| Operation | Success | Failures |
|---|---|---|
| `POST /api/environments` `{repo,ref,template,values?,ttl_seconds?}` + optional `Idempotency-Key` | **202**, body with server-generated `id`, `state=requested`, `Location` header, `X-Trace-Id` | 401 no session · 403 viewer role / repo not in `ALLOWED_REPOS` / creator-team check fails · 422 schema/field errors (never 500) · 429 quota with `Retry-After` |
| `GET /api/environments`, `GET /api/environments/{id}`, `GET …/{id}/events` | 200 | 401, 404 |
| `GET /api/audit` | 200 admin only | 401/403; PUT/PATCH/DELETE/POST → 405 |
| ForwardAuth decision endpoint (plan 02-08) | 200 with valid env-bound ticket/cookie | 401 none · 403 wrong env · 404 unknown env |

Worker invariants (all via `envstate.Advance`):
1. `env:dispatch` is serialised with spacing; on 5xx/secondary-rate-limit it re-enqueues with backoff and **never** dispatches twice for one env (use the env id as asynq `TaskID`, and store `run_id` before acknowledging).
2. `env:poll` uses ETags (D-16); a workflow `success` moves to `provisioning→running` **only after** the first successful probe (workflow-green ≠ healthy).
3. Provision deadline (`ENV_PROVISION_DEADLINE`) → `failed` with `failure_reason`.
4. Every transition emits one audit row and one synthetic span linked to the create request's trace.
5. A worker crash between dispatch and storing `run_id` is recovered by the run-name correlation fallback (D-15).

## E. Cluster side (plan 02-13/02-15)
Acceptance on a real kind cluster (`ephematest tests/test_stack_ops.py -k namespaces`): exactly one namespace per env labelled `ephematool.io/env-id|owner|expires-at`, each with ResourceQuota, LimitRange and default-deny NetworkPolicy; preview hosts only reachable through the ForwardAuth gate; the per-run deployer token cannot touch other namespaces (add a negative `kubectl auth can-i` test to the kind verify).

## F. UI (plans 02-12/02-14/02-16)
No new design here; add **Playwright accessibility check** (`@axe-core/playwright`) on the launch, detail, audit and denied pages, and a `data-testid` contract (`env-state`, `env-url`, `env-expiry`) that the Phase 3 inventory reuses.

## G. Definition of done for Phase 2
1. `ephematest tests --expect-phase 2 --repo-root .` → 0 failures against the compose+fake stack (incl. `test_audit_events_db_role…`), plus `--quota-mode` run green on a stack with `ENV_MAX_PER_USER=3`.
2. `kind_verify` green; manual UAT list from plan 02-17 signed off (real GitHub App, real Actions on the self-hosted runner, real GHCR).
3. STATE.md/ROADMAP.md updated through `/gsd-*` commands (CLAUDE.md rule), Phase 2 marked complete.
