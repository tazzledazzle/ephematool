# SPEC-03 — Phases 6 and 7

Requirements: OBS-04, OBS-05 (P6) · GRD-02, GRD-03, GRD-05 (P7). Reference code: `code/quota` (tested), `code/migrations`.

---
## Phase 6 — Per-environment telemetry views

### P6.1 Cardinality contract (do this first)
Environment id is a **resource attribute on telemetry emitted by the environment's workload** (stamped by the collector `*/environments` pipeline, plan 02-09) and **never a metric label on platform metrics** (pitfall: OTel cardinality). Per-env metrics live in a separate Prometheus tenant/retention (short, e.g. 48 h) so a leak cannot affect platform SLOs.
* Recording rules (per env, 1 m): `env:http_error_ratio`, `env:http_latency_p95`, `env:request_rate` from `http_server_request_duration_seconds_*{ephematool_env_id=…}`.
* Hard guard: collector `filter` drops any series with an id label not matching `^pv-[a-z0-9]{10}$` (spoofing, plan 02-09) and a `metricstransform`/limits cap of 200 active env ids.

### P6.2 API (SC1)
`GET /api/environments/{id}/telemetry?range=1h` → `{ error_rate: [[ts,val]…], p95_ms: […], request_rate: […], traces: [{trace_id, root, duration_ms, status, started_at}] (≤ 20), generated_at }`. Server-side proxy to Prometheus/Tempo using **fixed query templates** with the env id passed as a validated parameter (regex above) — the browser never sends PromQL/TraceQL. 10 s response cache per `(id,range)`; timeout 5 s → `degraded: true` with the reason rather than a 500.

### P6.3 Grafana deep link (SC2)
`GET /api/environments/{id}/links` → `{ grafana, traces, logs }` built from `GRAFANA_PUBLIC_URL` (WR-08: validate the scheme `http|https` server-side and client-side before rendering). Provision one Grafana dashboard JSON (`deploy/grafana/dashboards/environment.json`) with a `$env` variable and panels matching P6.2; link = `…/d/ephematool-env?var-env=<id>&from=now-1h&to=now`. Contract test: every link contains the env id and an allowed scheme (`test_environment_links_to_grafana_and_traces`).

### P6.4 Time-to-ready trends (SC3)
Emit histogram `ephematool_env_time_to_ready_seconds` (buckets 15,30,60,120,180,300,600,900) and `ephematool_env_provision_duration_seconds` from the worker at the `provisioning→running` transition (values computed from `audit_events` timestamps so a worker restart cannot lose them). API `GET /api/trends/provisioning?from=&to=&step=` → p50/p90/p99 series via PromQL `histogram_quantile` over `rate(..._bucket[$step])`; UI chart with a range picker (1 h/24 h/7 d). Backfill option: compute from `audit_events` when Prometheus retention is shorter than the range.

### P6 exit
`ephematest --expect-phase 6` (links test) + Playwright: detail page shows the three charts for a freshly created env within 90 s; Grafana link opens the dashboard with the env variable set; empty-state when the env has no traffic.

---
## Phase 7 — Quota & secrets guardrails

### P7.1 Atomic quotas (SC1) — per user, per repo, per team
Use `code/quota`: `Decide()` is pure; atomicity is a **transaction-scoped advisory lock per scope key** taken in sorted order (`quota.LockKeys`), then count, decide, insert, commit. Config: `ENV_MAX_PER_USER`, `ENV_MAX_PER_REPO`, `ENV_MAX_PER_TEAM` (0 = unlimited for that scope).
```sql
BEGIN;
SELECT pg_advisory_xact_lock(hashtextextended($1, 0));   -- once per key from quota.LockKeys
SELECT count(*) FROM environments WHERE owner_login=$2 AND state NOT IN ('failed','destroyed');
-- Decide() in Go; INSERT environment + audit row on allow; audit 'env.denied' (reason=quota) on reject
COMMIT;
```
**Verified on Postgres 16 with 12 concurrent creators and a limit of 3:** 3 rows with the lock; **11** rows without it — i.e. the lock is the thing that makes the guarantee (GRD-02 "even when two requests race"). Counted states exclude `failed`/`destroyed` so a failed env frees its slot (document this; make it configurable if failed envs must keep consuming quota until cleaned up).

### P7.2 Rejection explains itself (SC2)
HTTP 429, `Retry-After: <seconds to soonest expiry>`, RFC 7807-style body: `{scope, key, limit, active, existing:[{id, expires_in_seconds}], retry_after_seconds}` (exactly `quota.Rejection`). UI renders "3 of 3 environments in use; pv-… frees in 41 min" with links. Tested by `test_quota_rejection_explains_remaining_quota` (quota-mode run).

### P7.3 Secrets by reference (SC3)
* Catalog of **named, scoped secrets** in the platform DB/KMS (`secret_refs(name, scope_repo, scope_team, k8s_secret_name, created_by)`), values live only in the cluster's secret store (or an external-secrets backend) — the platform stores *names*, never values.
* Templates accept `{ "secretRef": "<name>" }` only; `values.schema.json` forbids literal keys matching `/(secret|password|token|api[_-]?key|private)/i` (server enforces the same regex — 422).
* On create: resolve the name; refuse (403, audit `env.denied reason=secret_out_of_scope`) if the secret's scope excludes the repo/team (SC4 "out-of-scope secret"). The provisioner receives only the **k8s secret name** to mount/copy (`kubectl get secret -n platform-secrets <name> -o yaml | sed namespace | kubectl apply`), executed by the fenced provisioner, never by the API process.
* Never in responses: API serialisers use a `Redacted` type for any field sourced from secret material; `GET /api/environments/{id}` returns `{"db":{"secretRef":"sampleapp-db"}}` only.

### P7.4 No secret value in telemetry/logs/UI (SC3)
1. Central redactor `internal/redact`: key-based (the regex above) + value-based (registered secret values loaded at start, minimum length 8, matched as substrings) used by the slog handler, span attribute processor and the K8s event/diagnostics path (SPEC-02 P3.3).
2. Collector `attributes/redact` processor deletes `http.request.header.authorization|cookie` etc. (already tested by `scripts/verify.d/redaction.sh`).
3. Extend `redaction.sh` and `test_no_secret_material_in_traces_or_logs` with a **canary secret** (`CANARY_SECRET_VALUE`) created as a real secretRef and exercised through create → provision → destroy; the scan must find zero occurrences in Tempo, Loki, Prometheus labels, API responses and the audit table.

### P7.5 Production-data / out-of-scope refusal (SC4)
Template policy in `values.schema.json` + server rule engine (`internal/policy`): deny list for hostnames/ARNs/DSNs matching configured production patterns (`PROD_DENY_PATTERNS`, e.g. `\.prod\.`, `prod-db`), deny `hostNetwork`, `privileged`, `hostPath` in any template; the Helm template tests (`helm template | conftest`) run in CI (SPEC-04 P-01). Refusals are 422 with a stable `code` (`policy.prod_data`, `policy.privileged`) and an audit row.

### P7 exit
`ephematest --expect-phase 7 --repo-root .` **and** `--quota-mode` both green; `test_secret_by_reference_…`, `test_out_of_scope_secret_reference_refused`, `test_parallel_creates_cannot_exceed_quota`; canary scan clean.
