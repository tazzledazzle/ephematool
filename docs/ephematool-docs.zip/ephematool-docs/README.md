# Ephematool completion docs

- `.internal/specs/` design spec (ends with Stress Test Results)
- `.internal/plans/` Plan 1 of 5 (test-first tasks)
- `docs/decisions/` ADR-0001..0005 + INDEX.md
- `reference/` verified Go cores (`code/`) and the `ephematest` suite; copied into the repo by Plan 1 tasks

Verification scope: stdlib Go packages and ephematest were run in a sandbox. Repo-integrated Go edits were not compiled.
