# Ephematool Completion and Productionization — Design

Date: 2026-10-20
Status: Draft for review (stress-tested; see the final section and ADR-0001 to ADR-0005)
Repo reviewed: `github.com/tazzledazzle/ephematool` at the checkout of 2026-10-20 (`.planning/STATE.md` dated 2026-10-12)

## 1. Goals and non-goals

**Goal.** Finish Ephematool as a production system: SREs create, observe and destroy ephemeral preview environments (Kubernetes namespaces provisioned by GitHub Actions) from one dashboard, every environment is observable from the moment it exists, and no environment lingers or leaks.

**Required capabilities** (roadmap phases and requirement ids)
- P2 Create a secure preview environment: ENV-01/02/09, OBS-03, GRD-01, AUTH-02/03
- P3 Inventory, lifecycle and destroy; orphan detection: STAT-01/02/05/06, ENV-03
- P4 Live health and drift detection: STAT-03/04
- P5 TTL, extension, PR-close teardown, pre-expiry comment: ENV-04…08
- P6 Per-environment telemetry views and time-to-ready trends: OBS-04/05
- P7 Atomic quotas, secrets by reference, production-data refusal: GRD-02/03/05
- Production readiness not covered by any phase: CI/CD and supply chain, Helm deployment and HA, runtime hardening, webhook receiver, health/readiness, backup and DR, platform SLOs and runbooks, documentation

**Non-goals**
- No Kubernetes operator/CRD in v1 (revisit after v1; the control plane is Postgres plus reconcilers).
- No remote-cluster OIDC provisioning in v1 (decision D-02 stays deferred; kind plus a self-hosted runner is the v1 target; the design leaves a seam, section 5.7).
- No automatic drift repair; drift is reported with the conflicting signals.
- No custom telemetry store or tracing UI; Grafana, Tempo, Loki and Prometheus remain the backends.

**Scale target (assumption, confirm in review).** ≤ 50 concurrent environments, ≤ 200 creates/day, ≤ 20 SRE users, one preview cluster. Designed with 2x headroom. Nothing in the design needs a different shape at 10x, but the GitHub API budget in section 6 is the first limit to hit.

## 2. Decisions taken

Inherited from the repo's planning (D-xx, binding) and new in this design (N-xx).

| Decision | Choice |
|---|---|
| Runtime | Kubernetes namespaces, one per environment, id `pv-<10 chars>` (D-03) |
| Provisioning | GitHub Actions `workflow_dispatch` on a thin environments repo, self-hosted runner on kind (D-01, D-02, D-14) |
| Language and stack | Go: huma API, asynq/Redis worker, Postgres with goose/sqlc/pgx, scs sessions; React 19/Vite SPA; Bazel bzlmod |
| Preview access | Traefik v3 ForwardAuth gate with env-bound ticket and cookie (ENV-09, D-04/D-22) |
| Audit | Append-only `audit_events` in Postgres, two DB roles (D-19/D-24) |
| N-01 State changes | Compare-and-set only through `envstate.Advance` (ADR-0001) |
| N-02 Audit and privileges | Trigger-enforced; idempotent grants; startup/readiness privilege check (ADR-0002) |
| N-03 Quotas | Advisory locks in the create transaction (ADR-0003) |
| N-04 External events | Webhooks enqueue only; reconciler converges (ADR-0004) |
| N-05 Quality gate | `ephematest` phase-gated conformance suite in CI (ADR-0005) |
| N-06 Drift | Verdict from five independent signals, reported not repaired (section 5.4) |
| N-07 Platform deployment | Helm chart on Kubernetes; managed Postgres and Redis; compose stays dev-only |
| N-08 Work order | Hardening and schema first; then P2; then P3–P5; then P6–P7; productionization in parallel from Wave 1 |

## 3. Architecture

```mermaid
flowchart LR
  subgraph Clients
    SRE[SRE browser]
    GH[GitHub: OAuth, App, Actions, webhooks]
  end
  subgraph Platform["Platform (Kubernetes, Helm)"]
    NGX[web/nginx unprivileged]
    API[api x2]
    WRK[worker x2]
    COL[OTel Collector: platform + environments pipelines]
  end
  subgraph Data
    PG[(Postgres: environments, audit_events append-only)]
    RD[(Redis: sessions, asynq)]
  end
  subgraph Preview["Preview cluster (kind / remote)"]
    TRF[Traefik ForwardAuth gate]
    NS[pv-xxxxxxxxxx namespaces: quota, limitrange, netpol]
  end
  subgraph Obs[Observability]
    TMP[Tempo]
    LOK[Loki]
    PRM[Prometheus]
    GRF[Grafana]
  end
  SRE --> NGX --> API
  SRE -->|preview URL| TRF -->|ForwardAuth| API
  GH -->|webhook HMAC| API
  API --> PG
  API --> RD
  WRK --> RD
  WRK --> PG
  WRK -->|dispatch, poll ETag| GH
  WRK -->|probe, namespaces| NS
  GH -->|self-hosted runner| NS
  API --> COL
  WRK --> COL
  NS --> COL
  COL --> TMP
  COL --> LOK
  COL --> PRM
  GRF --> TMP
  GRF --> LOK
  GRF --> PRM
  TRF --> NS
```

Components (existing in **bold**, new in plain text):
- **api** (`cmd/api`): huma operations, OAuth login, sessions, status prober. New: environments operations, audit list, webhook endpoint, `/healthz` and `/readyz`, privilege self-check.
- **worker** (`cmd/worker`): today only ping and heartbeat tasks. New: `env:dispatch`, `env:poll`, `env:probe`, `env:reconcile`, `env:sweep`, `env:destroy`, each idempotent.
- **Postgres**: `users` today. New: `environments`, `audit_events`, `environment_signals`, `orphan_findings`, `secret_refs`.
- **Redis**: sessions and asynq. Treated as rebuildable: all work is re-derivable from Postgres.
- **OTel Collector**: platform pipeline exists; the reserved `environments` slot is filled by plan 02-09 (separate receiver, filter, stamping).
- **fakegithub** (`cmd/fakegithub`): OAuth fixtures today; plan 02-03 adds App, Actions and GHCR surfaces plus control endpoints.

**Prerequisites on the operators**
- A GitHub App (Actions RW, Contents R, Pull requests RW, Metadata R) and an environments repo with the thin workflow.
- A self-hosted runner with a fenced provisioner and per-run deployer token (D-21).
- Postgres with two roles (`ephematool_owner`, `ephematool_app`) created before first deploy.

## 4. Data model and state machine

```mermaid
stateDiagram-v2
  [*] --> requested: POST /api/environments (quota lock, audit)
  requested --> provisioning: dispatch run id stored
  requested --> failed: dispatch rejected
  requested --> destroying: user cancels
  provisioning --> running: workflow ok AND probe ok AND url set
  provisioning --> failed: run failed or deadline
  provisioning --> destroying: user destroys
  running --> destroying: DELETE, TTL expiry, PR closed
  failed --> destroying: DELETE or TTL expiry
  destroying --> destroyed: namespace NotFound and no PVs
  destroyed --> [*]
```

**Postgres** (migrations `00002_environments.sql`, `00003_audit_events.sql`, verified on Postgres 16)
- `environments`: `id` (`^pv-[a-z0-9]{10}$`), `owner_login`, `repo`, `ref`, resolved 40-hex `sha`, `pr_number`, `template`, `template_values` (jsonb, secrets only as `{"secretRef": name}`), `state` (CHECK over six values), `state_version`, `failure_reason`, `run_id`, `url`, `created_at`, `updated_at`, `expires_at` (NOT NULL, CHECK > created_at), `ttl_extensions`, `expiry_warned_at`. CHECK `state <> 'running' OR url IS NOT NULL`.
- `audit_events`: `seq` identity, `at`, `actor` (login or `system`), `action`, `env_id` (no FK), `from_state`, `to_state`, `reason`, `trace_id`, `detail` jsonb. Triggers block UPDATE/DELETE/TRUNCATE for every role.
- Partial indexes: active-per-owner and per-repo (`state <> 'destroyed'`), stalled-state scan (`requested|provisioning|destroying` by `updated_at`), expiry (`running|failed`), open PR lookup.
- `environment_signals(env_id, signal, value, observed_at)`, `orphan_findings`, `secret_refs` arrive with their phases.

**Transition rule.** `envstate.Advance(ctx, store, id, from, to, actor, reason, Patch)`: validates the edge, executes one `UPDATE … WHERE id=$1 AND state=$2`, writes the audit row in the same transaction, returns `ErrLostRace` on zero rows. `Patch{URL, FailureReason, RunID}` carries columns that a CHECK ties to the target state. Entering `failed` also sets `expires_at = LEAST(expires_at, now() + FAILED_RETENTION)` and snapshots diagnostics.

## 5. Subsystems

### 5.1 Create path (P2)

```mermaid
sequenceDiagram
  autonumber
  participant U as SRE
  participant A as API
  participant G as GitHub
  participant P as Postgres
  participant Q as Redis asynq
  participant W as Worker
  participant K as Cluster
  U->>A: POST /api/environments
  A->>G: resolve sha, fork check, team membership, GHCR manifest
  A->>P: BEGIN, advisory locks sorted, count, INSERT env and audit, COMMIT
  A->>Q: enqueue env:dispatch with TaskID = env id
  A-->>U: 202 id, state requested
  W->>G: workflow_dispatch serial and spaced
  W->>P: CAS requested to provisioning, store run_id
  loop ETag polling
    W->>G: GET run conditional
  end
  G->>K: self-hosted runner applies chart
  W->>K: probe through gateway
  W->>P: CAS provisioning to running, set url
  U->>A: GET /api/environments/id
  A-->>U: state running, verdict, expiry
```

- Validation pipeline is server-authoritative and runs entirely before the database transaction: session and role (creator team re-checked at request time, D-06), repo in `ALLOWED_REPOS`, ref → sha, fork refs refused, template and `values` against `values.schema.json`, GHCR manifest exists, secret refs in scope. Failures return 4xx with field errors and write an `env.denied` audit row; nothing returns 500 for bad input.
- The transaction holds only the quota locks, the count, and two INSERTs (ADR-0003).
- Idempotency: optional `Idempotency-Key` (unique per owner, 24 h) returns the original environment.
- Env id generation retries on primary-key conflict.
- Response: 202, `Location`, body with `state=requested`, and `X-Trace-Id`.

### 5.2 Reconciler and webhooks (P3, P5; ADR-0004)
`env:reconcile{id}` runs from webhooks, from the sweep, and for every non-terminal environment at startup (with jitter). Decisions:
- `provisioning`, run completed `success` → start the probe loop; mark `running` only after the first successful probe.
- `provisioning`, run completed not-success, or provisioning deadline exceeded → `failed` with reason.
- Rows stalled beyond a threshold (`requested` > 60 s, `destroying` > 2 min) → re-enqueue the follow-up task (the repair for the database/Redis dual write).
- Environments with a `pr_number`: PR state polled every 5 minutes (60 s when webhooks are unhealthy); PR closed → `env:destroy`.
Webhook endpoint: HMAC-SHA256 verified in constant time, 1 MiB cap, allow-list of events, delivery-id de-duplication, 202 on accepted/duplicate/ignored, 401 on a bad signature, 503 only if the enqueue fails.

### 5.3 Destroy, TTL and extension (P3, P5)
- Destroy: owner or admin, `DELETE` → 202 and `destroying`. The worker tears down, then confirms namespace `NotFound` and no PVs labelled with the env id before `destroyed`. A namespace stuck `Terminating` past `DESTROY_DEADLINE` raises an alert and shows finalizers; finalizers are never removed automatically. The UI confirmation requires typing the environment id.
- TTL: `expires_at` is mandatory and authoritative; the reaper claims due rows with `FOR UPDATE SKIP LOCKED` and moves them to `destroying` in one statement, with audit and a `TaskID`-deduplicated enqueue. Verified on Postgres: 20 due rows, 8 concurrent claimers, 20 claimed, 20 unique.
- Extension: capped on total lifetime from `created_at` (`reaper.Policy.Extend`), optimistic SQL (`WHERE state='running' AND expires_at > now() AND expires_at = $old`) that loses cleanly to the reaper; clears `expiry_warned_at`.
- Pre-expiry comment: posted by the single winner of `UPDATE … SET expiry_warned_at = now() WHERE expiry_warned_at IS NULL`.

### 5.4 Health and drift (P4)
Five independent signals per environment, stored with timestamps: record state, last workflow conclusion, namespace Active, workloads available, probe through the gateway (platform probe credential, `healthPath` 2xx within `ENV_PROBE_TIMEOUT`). `health.Classify` returns `live`, `not_live`, `drifted` (with named conflicting signals) or `unchecked` (never `live` on missing data); `health.Debounce` requires 3 consecutive identical non-live verdicts before the label changes, and recovery is immediate. Metrics expose verdict counts without environment ids.

### 5.5 Per-environment telemetry (P6)
Environment id is a resource attribute on workload telemetry, stamped and validated (`^pv-[a-z0-9]{10}$`) in the `environments` collector pipeline, capped at 200 active ids, and never a label on platform metrics. The API serves fixed query templates (error ratio, p95, request rate, ≤ 20 recent traces) with 10 s caching and a degraded response instead of a 500. Grafana deep links use a provisioned `environment.json` dashboard with an `$env` variable; scheme is validated server- and client-side (WR-08). Time-to-ready histograms are emitted from audit timestamps at the `provisioning → running` transition.

### 5.6 Guardrails (P2 minimal, P7 full)
- Quotas per user, repo and team with the explanation payload (`quota.Decide`), 429 and `Retry-After`.
- Secrets by reference: `{"secretRef": name}` only; the platform stores names and scopes, never values; the fenced provisioner copies the named Secret into the namespace; API serialisers use a redacted type; a central redactor (key- and value-based) protects logs, spans and event/diagnostic output.
- Production-data refusal: deny patterns for hosts/DSNs, and template policy denying `privileged`, `hostNetwork` and `hostPath`, with stable error codes.

### 5.7 Remote-cluster seam (deferred)
The provisioner is invoked through one interface (`Provisioner.Apply/Destroy/Observe`); the kind implementation shells out to the fenced script. A remote implementation would assume a cloud role through GitHub OIDC pinned to the environments repo and ref, limited to `pv-` namespaces. No design work beyond the interface is committed here.

## 6. Non-functional requirements, capacity and trade-offs

| NFR | Target | How it is met / measured |
|---|---|---|
| Create acknowledgement | p95 < 1.5 s (excludes provisioning) | validation before the transaction; `ephematest` latency budget |
| Time-to-ready | p90 < 10 min | histograms; alert `EphematoolProvisionSlow` |
| Convergence after missed webhook | ≤ 2 sweep intervals | reconciler; P3 acceptance test with webhook delivery paused |
| TTL accuracy | destroyed within 2 sweep intervals after expiry, 99% | reaper; audit timestamps |
| Leaks | zero namespaces unknown to inventory for > 30 min | orphan sweep and alert |
| API availability | 99.5% non-5xx over 28 days | 2 replicas, PDB, readiness |
| Audit integrity | no UPDATE/DELETE possible by app role or owner | triggers, privilege check, DB test |
| Secret exposure | zero canary occurrences in traces, logs, labels, responses, audit | canary scan in redaction gate |

**Capacity.** Postgres load is trivial (about 8 audit rows per environment; 200 creates/day is under 2k rows/day). The binding limit is the GitHub API budget. A GitHub App installation has a baseline of 5,000 requests/hour (documented baseline; confirm in spike S4). Only `provisioning` environments poll GitHub: 10 in flight at one conditional poll per 10 s is 3,600/hour worst case, mostly 304s. PR-state polling for 50 running environments every 5 minutes is 600/hour. Probes hit the cluster, not GitHub. Webhooks reduce both.

**Trade-offs**

| Decision | Chosen | Alternative | Why |
|---|---|---|---|
| Control plane | Postgres + reconcilers | CRD + operator | one language, simpler v1; operator revisited after v1 |
| Queue | asynq on Redis (existing) | pg-based queue (CLAUDE.md predates Go) | already built and traced; Redis is rebuildable |
| DB/queue consistency | reconciler repair | transactional outbox | less moving parts; delay bounded by sweep interval (ADR-0001) |
| Quota atomicity | advisory locks | serializable isolation / unique-slot rows | lock scope matches contention; no retries on serialization failure |
| Webhooks | hints only | primary signal | survives lost deliveries (ADR-0004) |
| Drift | report | auto-heal | avoids fighting operators and masking causes |
| Failed envs and quota | count until destroyed, auto-expire in 2 h | free the slot immediately | a failed namespace still consumes the cluster |
| Test harness | Python/pytest black-box | Go integration only | exercises the deployed artifact, including observability and ops (ADR-0005) |

**Failure modes**

| Failure | Behaviour |
|---|---|
| Redis lost | sessions invalid; queued tasks lost; reconciler re-derives all work from Postgres within a sweep |
| Postgres failover | `/readyz` fails (critical); `/healthz` stays up so pods are not restarted; in-flight creates fail cleanly |
| GitHub outage or rate limit | creates return 503 with `Retry-After`; polling backs off with jitter; reconciler resumes |
| Worker crash mid-dispatch | `run_id` is stored before ack; the run-name correlation fallback finds the run (D-15) |
| Namespace deleted out of band | verdict `drifted`, alert after 15 min |
| Namespace stuck Terminating | stays `destroying`, alert, finalizers shown, never forced |
| Collector or Tempo down | platform keeps serving (non-critical readiness checks); telemetry drops and is counted |
| Database role mis-granted | startup and `/readyz` fail on `CheckPrivileges` |

**SLOs and alerts.** Rules in `reference/deploy/prometheus/ephematool-rules.yaml` (error ratio, latency, worker stalled, queue backlog, drift, stuck destroying, orphans, slow provisioning). Alert PromQL has not been run through `promtool`.

## 7. Error handling, security, testing

**Error handling**
- Input errors are 400/422 with field errors; never 500. Quota is 429; transient dependency failure is 503 with `Retry-After`.
- Every denial writes an `env.denied` audit row with a stable reason code.
- Handlers on the webhook path never process inline; they enqueue and acknowledge.
- Reconciler and sweep isolate failures per environment and count them.

**Security**
- Sessions: `HttpOnly`, `Secure`, `SameSite=Lax`, renewed on login (WR-10), membership re-validated at request time.
- Secure-by-default routes: a unit test enumerates every huma operation and fails if one is neither marked public nor guarded (WR-02).
- CSRF: JSON content type plus a custom header on state-changing calls; Go 1.25 `CrossOriginProtection` is already in front.
- Fork PRs never produce environments; fenced provisioner; per-run deployer token; least-privilege GitHub App; no `cluster-admin`.
- Headers and CSP on the web origin; Redis authenticated; Grafana anonymous access off in production; non-root images; supply chain: pinned digests, SBOM, provenance, scanning, cosign verification before deploy.
- Telemetry: the redaction gate (existing) plus a canary secret exercised end to end.

**Testing**
- Unit: `envstate` (graph, no-leak reachability, 64-way race), `reaper` (cap on total lifetime, warning once), `quota`, `health`, `webhook`, `probes`; config validation table; route-guard enumeration.
- Database: migrations apply and roll back; constraints; privilege check; concurrency experiments (quota lock, SKIP LOCKED claim), run against Postgres in CI.
- Integration: compose stack with fakegithub driving create → running → destroy, including a dropped webhook and a worker restart mid-provisioning.
- Conformance: `ephematest` at `--expect-phase N`, plus `--quota-mode`, plus the self-test that injects 17 faults (ADR-0005).
- Cluster: kind verify for namespace baseline, gate behaviour, deployer-token fencing (negative `kubectl auth can-i`), and no orphan after destroy.
- Load: 50 concurrent creates; success is no orphan namespaces, quota never exceeded, p95 within SLO.

## 8. Spikes to complete before or during planning

1. **S1 Dispatch run-id behaviour.** Confirm `workflow_dispatch` behaviour across the pinned `X-GitHub-Api-Version` values (CLAUDE.md notes 2026-03-10 returns a run id, 2022-11-28 returns 204 unless `return_run_details`). Decision rule: if the pinned version returns the id, correlation by run-name is a fallback only; otherwise it is the primary path and needs the echoed `env_id` input.
2. **S2 Fake GitHub fidelity.** Compare plan 02-03's fake against recorded real responses for dispatch, run polling, ETag, membership and GHCR manifest. Decision rule: any divergence that changes control flow becomes a fixture-backed test.
3. **S3 Traefik ForwardAuth timing.** Measure the decision endpoint at p99 under 50 concurrent preview requests. Decision rule: above 50 ms, cache decisions per ticket for 5 s.
4. **S4 GitHub rate-limit accounting.** Verify that conditional requests answered 304 do not consume the installation budget, and read the actual limit for this installation. Decision rule: if not free, raise poll intervals and lean on webhooks.
5. **S5 Namespace teardown latency.** Measure `Terminating` time with a representative chart on kind. Decision rule: sets `DESTROY_DEADLINE` (default 5 × the p95).
6. **S6 Capacity of the real cluster.** Measure how many `M`-sized environments one node set holds. Decision rule: sets the per-team default quota.

## Stress Test Results: Ephematool completion and productionization

### Resolved Decisions
- **State/CHECK conflict (reproduced).** A bare CAS to `running` is rejected by the `running ⇒ url` CHECK. Resolved with `Patch` carried in the same UPDATE; `Advance` refuses `running` without a URL.
- **Silent privilege skip (reproduced).** Granting inside the migration `IF EXISTS role` skipped the grant for a role created later. Resolved: no grants in migrations, idempotent `grants.sql`, `CheckPrivileges` at startup and in `/readyz` (ADR-0002).
- **Failed environments and quota.** Excluding `failed` from the count let a user create unlimited failing environments, each leaving a namespace. Resolved: count everything except `destroyed`; give failed environments a short auto-expiry after diagnostics are snapshotted (ADR-0003).
- **Lock held across network calls.** Putting GitHub validation inside the quota transaction would serialise creates behind slow API calls. Resolved: validate first, lock only around count and insert, with `lock_timeout`.
- **Database/Redis dual write.** A commit followed by a lost enqueue strands an environment. Resolved: reconciler re-enqueues stalled rows, task ids de-duplicate, no outbox (ADR-0001).
- **Webhook as the only teardown trigger.** Contradicts "no environment lingers". Resolved: reconciler polls PR state (ADR-0004).
- **Contract drift between the test suite and the API.** `ephematest` encodes Phase 2+ paths before they exist. Resolved: OpenAPI contract-sync test per phase; the suite flags 5 missing path groups against today's `api/openapi.json`.
- **GitHub API budget.** 50 environments polled naively would exceed the baseline budget. Resolved: only `provisioning` environments poll run state; PR state every 5 minutes; conditional requests; spike S4.
- **Test credibility.** A suite never seen failing proves nothing. Resolved: fault-injection self-test as a CI step (ADR-0005); bring-up already exposed four defects in the tests or mock.

### Changes Made
- Migration `00002` indexes changed to `state <> 'destroyed'` and a stalled-state index added; `00003` no longer contains grants; `grants.sql` added; `envstate` gained `Patch`; `ephematest` gained the contract-sync tests. Migrations were re-applied and rolled back on Postgres 16 after the changes.
- Sections 4, 5.1, 5.2, 5.6 and 6 reflect the resolutions above.

### Deferred / Parking Lot
- Transactional outbox: deferred until measured stranded-task delay exceeds the sweep-interval budget.
- Auto-repair of drift: deferred past v1.
- Remote-cluster OIDC provisioning (D-02): deferred; the provisioner interface is the seam.
- Monthly partitioning of `audit_events`: deferred until volume warrants (> 10 M rows).
- `lock_timeout` behaviour is designed but not yet exercised against Postgres.

### Confidence Assessment
- Overall: Medium
- Areas of concern: the Go repo could not be built in this environment, so nothing here was compiled against the real module graph; GitHub API semantics (S1, S4) and Traefik/kind behaviour (S3, S5) are assumptions until spiked; the Phase 2+ black-box contract in `ephematest` is written ahead of an implementation; Helm templates and alert PromQL have not been validated with `helm`, `kubeconform` or `promtool`.
