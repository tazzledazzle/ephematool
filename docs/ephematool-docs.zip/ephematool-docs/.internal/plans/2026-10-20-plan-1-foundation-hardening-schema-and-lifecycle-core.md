# Foundation: Hardening, Schema, Lifecycle Core and Conformance Gate (Plan 1 of 5) Implementation Plan

> **For agentic workers:** this repo's `CLAUDE.md` requires file edits to start through a GSD command: run each Task with `/gsd-quick` (small tasks) or `/gsd-execute-phase` after registering this plan as a hardening phase between Phase 2 planning and execution. Steps use checkbox (`- [ ]`) syntax. Test first: write the failing test, run it, implement, run again.

**Goal:** Fix the verified defects in the current checkout, land the database schema and lifecycle core that every later phase builds on, add liveness/readiness, and put the phase-gated conformance suite and CI around it, so Phase 2 execution starts on a safe base.

**Architecture:** Config validation and server timeouts are corrected in place. Two Postgres migrations add `environments` and a trigger-protected `audit_events`; grants are an idempotent script and a privilege self-check fails readiness when the role is wrong. `internal/envstate` is the single compare-and-set choke point for state; `internal/probes` provides `/healthz` and `/readyz`. `tools/ephematest` plus a GitHub Actions workflow make every later phase a ratchet.

**Tech Stack:** Go (module `github.com/ephematool/ephematool`), huma/humago, pgx v5, sqlc, goose v3, asynq/Redis, Bazel bzlmod with gazelle; Postgres 16; Python 3.12 with pytest for `tools/ephematest`; GitHub Actions.

Source spec: `.internal/specs/2026-10-20-ephematool-completion-and-productionization-design.md` (stress-tested; ADR-0001…0005 in `docs/decisions/`).

## Plan split and tracked deviations (review these first)

The spec spans five independently shippable bodies of work.

| Plan | Scope | Spec sections |
|---|---|---|
| **1 (this)** | Hardening, schema, lifecycle core, probes, conformance gate, CI | 4, 5.2 (webhook verify code only), 6 (probes, SLO plumbing), 7 (testing), 8 (S1, S4 spikes) |
| 2 | Finish Phase 2: ghapp client, template catalog, role resolver, preview auth, create API, worker handlers, collector slot, kind cluster, UI, audit/preview pages, runbook (existing plans 02-01…02-17, amended) | 5.1, 5.6 (P2 part), 3 |
| 3 | Phases 3–5: inventory, diagnostics, destroy, orphans, reconciler, health/drift, TTL, extension, PR-close, webhook endpoint | 5.2, 5.3, 5.4 |
| 4 | Phases 6–7: telemetry views, trends, atomic quotas, secrets by reference, policy | 5.5, 5.6 |
| 5 | Production deployment: Helm chart, HA, release/supply chain, backup/DR, alerts and runbooks, docs and repo hygiene | 3, 6, 7 |

Deviations and interpretations the reviewer must accept or reject:

- **D1 Plan 02-04 overlap.** Existing plan 02-04 already covers the environments/audit schema and a goose Provider with a session locker. This plan implements the schema, the locker and the harness first, so 02-04 should be re-scoped to sqlc queries for its own read paths plus `internal/audit` (record and cursor list). **Decision needed: re-scope 02-04 or mark it superseded.**
- **D2 Migration grants.** 02-04 grants privileges in the migration. This plan removes grants from migrations (ADR-0002) and replaces them with `deploy/postgres/grants.sql`. Compose gets the second role through a small init step.
- **D3 Reference code was written outside the repo.** `internal/envstate`, `internal/probes`, `quota`, `reaper`, `health` and `webhook` are tested in a scratch module; their package paths are rewritten to the repo module path on copy. Only `envstate` and `probes` land in this plan; the rest are consumed by Plans 3–4.
- **D4 Privilege check in dev.** The dev compose stack connects as the owner, which would fail the check by design. `DB_PRIVILEGE_CHECK` is `warn` in compose and `enforce` in the Helm chart. **Decision needed: add the `ephematool_app` role to compose now (recommended) or leave dev on `warn`.**
- **D5 No Go build in the authoring environment.** The authoring sandbox could not fetch the Go 1.26 toolchain or modules. Code that depends only on the standard library (`envstate`, `probes`) was compiled and tested there; repo-integrated code (config, `cmd/api`, `store`, `httpapi`) is written against files that were read but has **not been compiled**. Each such step says so; the first `bazel test //...` run is the real check.

## Global Constraints

Copied from the spec; every task includes these.

- State changes only through `envstate.Advance`; columns tied to a state by a CHECK constraint travel in the same UPDATE (`Patch`).
- `audit_events` is append-only for every role; runtime role has no UPDATE/DELETE/TRUNCATE on it and no DELETE on `environments`.
- Migrations contain no grants; grants are idempotent and re-run after every migration; privileges are verified at startup and in `/readyz`.
- `/healthz` never depends on Postgres or Redis; `/readyz` runs checks in parallel with a per-check timeout and never echoes driver errors.
- New config variables get a default, validation, an entry in `.env.example` and a `config_test.go` case (`test_env_example_covers_every_config_variable` enforces the middle one).
- Generated artifacts stay in sync: `api/openapi.json` (`write_source_files` drift check), sqlc output, `conventions` files.
- No hand-written D-09 prefixes (`ephematool.io/`, `ephematool.env.`) outside generated files.
- Missing Docker or infrastructure fails tests; it never skips them (backlog #13).
- Edits to the repo start through a GSD command (`CLAUDE.md`).

## File Structure

```
tools/ephematest/                        copied from this plan's bundle (Task 1)
  pyproject.toml  README.md  selftest.py
  ephematest/{config,clients,plugin,cli}.py
  tests/test_*.py   mockstack/server.py
.github/workflows/ci.yaml                 (Task 8)
internal/config/validate.go               edit (Task 2)       internal/config/config_test.go  edit
internal/config/config.go                 edit: shutdown + privilege-check fields (Tasks 3, 6)
cmd/api/main.go                           edit: newServer, drain, probes (Tasks 3, 7)
cmd/api/server.go  server_test.go         new (Task 3)
internal/store/migrations/00002_environments.sql   new (Task 4)
internal/store/migrations/00003_audit_events.sql   new (Task 4)
deploy/postgres/grants.sql  deploy/postgres/init-roles.sql   new (Task 4)
scripts/verify.d/schema.sh                new (Task 4)
internal/envstate/{machine.go,machine_test.go,BUILD.bazel}   new (Task 5)
internal/store/queries/environments.sql   new (Task 5)       internal/store/pgstore.go  new
internal/store/migrate.go  privileges.go  privileges_test.go  new/edit (Task 6)
internal/probes/{probes.go,probes_test.go,BUILD.bazel}       new (Task 7)
internal/httpapi/api.go                   edit: Deps.Probes (Task 7)
CLAUDE.md  README.md  docs/                edit via GSD (Task 9)
```

---

### Task 1: Bring the conformance suite into the repo and record the baseline

**Files:**
- Create: `tools/ephematest/**` (copy of the bundle's `reference/ephematest/`)
- Modify: `.gitignore` (add `tools/ephematest/.venv`, `__pycache__`)

**Interfaces:**
- Produces: `ephematest` CLI; `python tools/ephematest/selftest.py`; baseline report with a recorded `--expect-phase 1` result.

**Acceptance Criteria:**
- `python tools/ephematest/selftest.py` exits 0 (baseline passes, all 17 faults detected)
- `ephematest tests --expect-phase 1 --repo-root .` exits 0 against the compose + fake GitHub stack
- Today's repo-level failures at `--expect-phase 7` are listed in the PR description as the starting gap list

- [ ] **Step 1: Copy the tool and install it**

```bash
cp -R <bundle>/reference/ephematest tools/ephematest
python3 -m venv tools/ephematest/.venv && . tools/ephematest/.venv/bin/activate
pip install -e tools/ephematest
printf 'tools/ephematest/.venv\n__pycache__/\n.pytest_cache/\n' >> .gitignore
```

- [ ] **Step 2: Run the self-test (proves the tests detect their faults; no stack needed)**

```bash
python tools/ephematest/selftest.py
```

Expected (as run when authoring): `BASELINE general … 73 passed, 3 deselected, 24 xfailed`, `BASELINE quota-mode … 3 passed`, and 17 lines `-> DETECTED`; exit code 0.

- [ ] **Step 3: Run the Phase 1 gate against the real stack**

```bash
bazel run //:up_fake
ephematest tests --expect-phase 1 --repo-root .
```

Expected: repo-level tests pass (7 passed, later phases xfail). The observability and ops tests (`test_p1_observability.py`, `test_stack_ops.py`) were **not run against a real stack when authoring**; if one fails, decide whether the test or the stack is wrong using `scripts/verify.d/*.sh` as the reference and fix the test in the same PR.

- [ ] **Step 4: Record the gap list**

```bash
ephematest tests/test_repo_static.py --expect-phase 7 --repo-root . -q 2>&1 | grep FAILED > docs/spikes/baseline-gaps-2026-10-20.txt
```

Expected when authoring: 8 failures before Plan 1 (CI workflow, deploy artifact, non-root web image, server timeouts, stale docs, probe validation, audit trigger, state CHECK) plus 5 contract-sync failures at `--expect-phase 2+`.

- [ ] **Step 5: Commit** — `git add tools/ephematest .gitignore docs/spikes && git commit -m "test: add phase-gated ephematest conformance suite (ADR-0005)"`

---

### Task 2: Config validation correctness (finding D-2/D-3, backlog #3)

**Files:**
- Modify: `internal/config/validate.go`, `internal/config/config_test.go`

**Interfaces:**
- Produces: `validate(Config) error` where every duration in `checks` is verified positive **before** any relational rule, so the error always names the offending variable.

**Acceptance Criteria:**
- Setting any listed duration to 0 returns an error containing that variable's name
- `PROBE_TIMEOUT` is in `checks`
- The relational error for the env probe names `ENV_PROBE_INTERVAL`
- No stale `// TODO` rule-group markers remain
- `go test ./internal/config` and `ephematest … -k config_validate` pass

Not compiled when authoring (D5).

- [ ] **Step 1: Write the failing test** — append to `internal/config/config_test.go`:

```go
// Every duration the loader accepts must be rejected when zero, and the message must name the variable.
func TestEveryDurationMustBePositive(t *testing.T) {
	cases := map[string]func(*Config){
		"SESSION_IDLE_TIMEOUT":   func(c *Config) { c.SessionIdleTimeout = 0 },
		"SESSION_LIFETIME":       func(c *Config) { c.SessionLifetime = 0 }, // fails today: the relational rule fires first and names another variable
		"HEARTBEAT_INTERVAL":     func(c *Config) { c.HeartbeatInterval = 0 },
		"PROBE_INTERVAL":         func(c *Config) { c.ProbeInterval = 0 },
		"PROBE_TIMEOUT":          func(c *Config) { c.ProbeTimeout = 0 }, // fails today: not in the checks slice
		"PREVIEW_TICKET_TTL":     func(c *Config) { c.PreviewTicketTTL = 0 },
		"PREVIEW_COOKIE_TTL":     func(c *Config) { c.PreviewCookieTTL = 0 },
		"ENV_DEFAULT_TTL":        func(c *Config) { c.EnvDefaultTTL = 0 },
		"ENV_PROVISION_DEADLINE": func(c *Config) { c.EnvProvisionDeadline = 0 },
		"ENV_POLL_INITIAL":       func(c *Config) { c.EnvPollInitial = 0 },
		"ENV_POLL_MAX":           func(c *Config) { c.EnvPollMax = 0 },
		"ENV_PROBE_INTERVAL":     func(c *Config) { c.EnvProbeInitial = 0 },
		"ENV_PROBE_WINDOW":       func(c *Config) { c.EnvProbeWindow = 0 },
		"ENV_PROBE_TIMEOUT":      func(c *Config) { c.EnvProbeTimeout = 0 },
		"ENV_SWEEP_INTERVAL":     func(c *Config) { c.EnvSweepInterval = 0 },
		"ENV_DISPATCH_SPACING":   func(c *Config) { c.EnvDispatchSpacing = 0 },
	}
	for name, mutate := range cases {
		t.Run(name, func(t *testing.T) {
			c, err := Load() // defaults are valid
			if err != nil {
				t.Fatal(err)
			}
			mutate(&c)
			err = validate(c)
			if err == nil || !strings.Contains(err.Error(), name) {
				t.Fatalf("validate error = %v, want it to name %s", err, name)
			}
		})
	}
}

func TestEnvProbeTimeoutMessageNamesRealVariable(t *testing.T) {
	c, _ := Load()
	c.EnvProbeTimeout = c.EnvProbeInitial // equal: violates "timeout < interval"
	err := validate(c)
	if err == nil || !strings.Contains(err.Error(), "ENV_PROBE_INTERVAL") || strings.Contains(err.Error(), "ENV_PROBE_INITIAL") {
		t.Fatalf("error = %v", err)
	}
}
```

- [ ] **Step 2: Run to see it fail**

```bash
bazel test //internal/config:config_test --test_output=errors
```

Expected: `SESSION_LIFETIME`, `PROBE_TIMEOUT` and the message test fail.

- [ ] **Step 3: Implement** — in `internal/config/validate.go`:
  1. Add `{"PROBE_TIMEOUT", c.ProbeTimeout},` to the `checks` slice (after `PROBE_INTERVAL`).
  2. Move the `for _, ch := range checks { … }` loop to immediately after the `checks` declaration and delete it from the bottom.
  3. Change the message `ENV_PROBE_TIMEOUT must be < ENV_PROBE_INITIAL` to `ENV_PROBE_TIMEOUT must be < ENV_PROBE_INTERVAL`.
  4. Delete the four `// Rule group N … TODO` comments, keeping the descriptive group titles as plain comments.

- [ ] **Step 4: Run to see it pass** — `bazel test //internal/config:config_test` (expected PASS), then `ephematest tests/test_repo_static.py -k probe --repo-root . --expect-phase 2`.

- [ ] **Step 5: Commit** — `fix(config): validate PROBE_TIMEOUT, check positivity before relations, name real variable`

---

### Task 3: HTTP server timeouts and ordered shutdown (finding D-4, backlog #9)

**Files:**
- Create: `cmd/api/server.go`, `cmd/api/server_test.go`
- Modify: `cmd/api/main.go`, `cmd/api/BUILD.bazel`, `internal/config/config.go`, `internal/config/validate.go`, `.env.example`, `deploy/compose.yaml` (no change needed if defaults are used)

**Interfaces:**
- Produces: `newServer(addr string, h http.Handler) *http.Server`; config `SHUTDOWN_DRAIN_DELAY` (default 5s) and `SHUTDOWN_TIMEOUT` (default 25s).
- Consumes: `internal/probes` (Task 7) for the drain hook; until then the drain step is a sleep.

**Acceptance Criteria:**
- Server sets ReadHeaderTimeout, ReadTimeout, WriteTimeout, IdleTimeout and MaxHeaderBytes
- On SIGTERM the process waits `SHUTDOWN_DRAIN_DELAY`, then shuts down within `SHUTDOWN_TIMEOUT`
- `test_http_server_has_full_timeouts` passes

Not compiled when authoring (D5).

- [ ] **Step 1: Write the failing test** — `cmd/api/server_test.go`:

```go
package main

import (
	"net/http"
	"testing"
	"time"
)

func TestNewServerSetsEveryTimeout(t *testing.T) {
	s := newServer(":0", http.NotFoundHandler())
	for name, got := range map[string]time.Duration{
		"ReadHeaderTimeout": s.ReadHeaderTimeout, "ReadTimeout": s.ReadTimeout,
		"WriteTimeout": s.WriteTimeout, "IdleTimeout": s.IdleTimeout,
	} {
		if got <= 0 {
			t.Errorf("%s is not set (slowloris exposure)", name)
		}
	}
	if s.MaxHeaderBytes == 0 || s.MaxHeaderBytes > 1<<17 {
		t.Errorf("MaxHeaderBytes = %d, want 1..128KiB", s.MaxHeaderBytes)
	}
}
```

- [ ] **Step 2: Run to see it fail** — `bazel test //cmd/api:api_test` → `undefined: newServer`.

- [ ] **Step 3: Implement** — `cmd/api/server.go`:

```go
package main

import (
	"net/http"
	"time"
)

// newServer returns an http.Server with every timeout set. WriteTimeout is the longest non-streaming handler;
// streaming handlers must extend their own deadline with http.ResponseController.SetWriteDeadline.
func newServer(addr string, h http.Handler) *http.Server {
	return &http.Server{
		Addr:              addr,
		Handler:           h,
		ReadHeaderTimeout: 10 * time.Second, // header phase: slowloris guard
		ReadTimeout:       30 * time.Second, // whole request incl. body
		WriteTimeout:      60 * time.Second,
		IdleTimeout:       120 * time.Second, // keep-alive connections
		MaxHeaderBytes:    1 << 16,
	}
}
```

In `cmd/api/main.go` replace the `srv := &http.Server{…}` line with `srv := newServer(cfg.HTTPAddr, handler)` and replace the shutdown branch with:

```go
	case <-ctx.Done():
		slog.InfoContext(ctx, "api.draining", "delay", cfg.ShutdownDrainDelay)
		// Task 7 adds probeSet.Drain() here so /readyz flips to 503 before connections are refused.
		time.Sleep(cfg.ShutdownDrainDelay) // lets the load balancer observe not-ready and stop sending traffic
		sctx, cancel := context.WithTimeout(context.Background(), cfg.ShutdownTimeout)
		defer cancel()
		slog.InfoContext(sctx, "api.shutting_down")
		return srv.Shutdown(sctx)
```

`internal/config/config.go`: add

```go
	ShutdownDrainDelay time.Duration `env:"SHUTDOWN_DRAIN_DELAY" envDefault:"5s"`
	ShutdownTimeout    time.Duration `env:"SHUTDOWN_TIMEOUT" envDefault:"25s"`
```

`validate.go`: add both to `checks`. `.env.example`: add `SHUTDOWN_DRAIN_DELAY=5s` and `SHUTDOWN_TIMEOUT=25s`. In `config_test.go` add both names to the zero-value table from Task 2.

Add to `cmd/api/BUILD.bazel`:

```python
load("//tools/bzl:go.bzl", "go_test")
go_test(name = "api_test", srcs = ["server_test.go"], embed = [":api_lib"])
```

- [ ] **Step 4: Run to see it pass** — `bazel test //cmd/api:api_test //internal/config:config_test`; then `ephematest tests/test_repo_static.py -k "timeouts or env_example" --repo-root . --expect-phase 7`.

- [ ] **Step 5: Commit** — `fix(api): set all HTTP server timeouts; drain before shutdown`

---

### Task 4: Environments and audit schema, idempotent grants, database verification

**Files:**
- Create: `internal/store/migrations/00002_environments.sql`, `internal/store/migrations/00003_audit_events.sql`, `deploy/postgres/grants.sql`, `deploy/postgres/init-roles.sql`, `scripts/verify.d/schema.sh`
- Modify: `deploy/compose.yaml` (mount `init-roles.sql`, add a one-shot `grants` step), `tools/verify.sh` (call `schema.sh`)

**Interfaces:**
- Produces: tables `environments`, `audit_events`; roles `ephematool_app` (runtime) and the existing owner; `grants.sql` accepting `-v app_role=…`.

**Acceptance Criteria:**
- Both migrations apply and roll back cleanly (goose Up and Down)
- Constraint violations: bad id, `running` without url, unknown state are rejected
- App role: INSERT/SELECT on `audit_events` allowed; UPDATE/DELETE/TRUNCATE denied; DELETE on `environments` denied
- Owner UPDATE on `audit_events` blocked by trigger
- `grants.sql` runs twice without error; privilege query returns all-true after grants
- `scripts/verify.d/schema.sh` passes and `test_audit_events_table_is_append_only`, `test_environments_state_has_check_constraint` pass

Verified when authoring against Postgres 16 with the SQL below (up, down, constraints, roles, idempotent grants).

- [ ] **Step 1: Write the failing check first** — `scripts/verify.d/schema.sh`:

```bash
#!/usr/bin/env bash
# Schema invariants: constraints, append-only audit for every role, idempotent grants. Needs the compose postgres.
set -euo pipefail
. "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/lib/verify-lib.sh"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
PSQL=(docker compose -f "$ROOT/deploy/compose.yaml" exec -T postgres psql -v ON_ERROR_STOP=0 -U ephematool -d ephematool -tA)
APP=(docker compose -f "$ROOT/deploy/compose.yaml" exec -T -e PGPASSWORD=ephematool_app postgres psql -v ON_ERROR_STOP=0 -U ephematool_app -d ephematool -tA)

expect_error() { # expect_error "<label>" <psql-array-name> "<sql>" "<substring of error>"
  local out; local -n cmd=$2
  out="$("${cmd[@]}" -c "$3" 2>&1 || true)"
  echo "$out" | grep -qi "$4" || fail "$1: expected error containing '$4', got: $out"
  pass "$1"
}

SHA=$(printf 'a%.0s' $(seq 40))
"${PSQL[@]}" -c "INSERT INTO environments(id,owner_login,repo,ref,sha,template,expires_at,url,state) VALUES ('pv-schematest','x','o/r','main','$SHA','t',now()+interval '1h','http://x','running')" >/dev/null \
  || fail "valid environment row rejected"
pass "valid environment row accepted"
expect_error "bad id rejected" PSQL "INSERT INTO environments(id,owner_login,repo,ref,sha,template,expires_at) VALUES ('bad id','x','o/r','m','$SHA','t',now()+interval '1h')" "environments_id_check"
expect_error "running without url rejected" PSQL "INSERT INTO environments(id,owner_login,repo,ref,sha,template,expires_at,state) VALUES ('pv-aaaaaaaaaa','x','o/r','m','$SHA','t',now()+interval '1h','running')" "violates check"
expect_error "unknown state rejected" PSQL "INSERT INTO environments(id,owner_login,repo,ref,sha,template,expires_at,state) VALUES ('pv-bbbbbbbbbb','x','o/r','m','$SHA','t',now()+interval '1h','weird')" "environments_state_check"

"${APP[@]}" -c "INSERT INTO audit_events(actor,action) VALUES ('schema.sh','probe')" >/dev/null || fail "app role cannot INSERT audit_events"
pass "app role can INSERT audit_events"
expect_error "app UPDATE audit denied" APP "UPDATE audit_events SET actor='evil'" "permission denied"
expect_error "app DELETE audit denied" APP "DELETE FROM audit_events" "permission denied"
expect_error "app TRUNCATE audit denied" APP "TRUNCATE audit_events" "permission denied"
expect_error "app DELETE environments denied" APP "DELETE FROM environments" "permission denied"
expect_error "owner UPDATE audit blocked by trigger" PSQL "UPDATE audit_events SET actor='evil'" "append-only"

# Privilege self-check query used by store.CheckPrivileges (must be all true for the app role).
ok="$("${APP[@]}" -c "SELECT has_table_privilege(current_user,'audit_events','SELECT') AND has_table_privilege(current_user,'audit_events','INSERT') AND NOT has_table_privilege(current_user,'audit_events','UPDATE') AND NOT has_table_privilege(current_user,'audit_events','DELETE') AND NOT has_table_privilege(current_user,'audit_events','TRUNCATE') AND has_table_privilege(current_user,'environments','UPDATE') AND NOT has_table_privilege(current_user,'environments','DELETE')" | tr -d '\r ')"
[ "$ok" = "t" ] || fail "privilege self-check query returned '$ok' for the app role"
pass "privilege self-check is true for the app role"

# Grants are idempotent.
for i in 1 2; do
  docker compose -f "$ROOT/deploy/compose.yaml" exec -T postgres psql -q -U ephematool -d ephematool -v app_role=ephematool_app -f /docker-entrypoint-initdb.d/grants.sql >/dev/null \
    || fail "grants.sql failed on run $i"
done
pass "grants.sql is idempotent"
"${PSQL[@]}" -c "DELETE FROM environments WHERE id='pv-schematest'" >/dev/null 2>&1 || true   # owner cleanup; audit rows stay by design
```

Run it before the schema exists:

```bash
bazel run //:up_fake && bash scripts/verify.d/schema.sh
```

Expected: FAIL at the first step (`relation "environments" does not exist`).

- [ ] **Step 2: Write `00002_environments.sql`**

```sql
-- +goose Up
-- One row per preview environment. `state` is changed ONLY through compare-and-set (internal/envstate, ADR-0001).
create table environments (
    id               text primary key check (id ~ '^pv-[a-z0-9]{10}$'),
    owner_login      text        not null,
    repo             text        not null check (repo ~ '^[A-Za-z0-9-]+/[A-Za-z0-9_.-]+$'),
    ref              text        not null,
    sha              text        not null check (sha ~ '^[0-9a-f]{40}$'),
    pr_number        integer,
    template         text        not null,
    template_values  jsonb       not null default '{}'::jsonb,
    state            text        not null default 'requested'
                     check (state in ('requested','provisioning','running','failed','destroying','destroyed')),
    state_version    bigint      not null default 0,
    failure_reason   text,
    run_id           bigint,
    url              text,
    created_at       timestamptz not null default now(),
    updated_at       timestamptz not null default now(),
    expires_at       timestamptz not null,
    ttl_extensions   integer     not null default 0,
    expiry_warned_at timestamptz,
    check (expires_at > created_at),
    check (state <> 'running' or url is not null)
);
create index environments_owner_active on environments (owner_login) where state <> 'destroyed';
create index environments_repo_active  on environments (repo)        where state <> 'destroyed';
create index environments_stalled      on environments (state, updated_at) where state in ('requested','provisioning','destroying');
create index environments_expiry       on environments (expires_at)   where state in ('running','failed');
create index environments_pr           on environments (repo, pr_number) where pr_number is not null and state not in ('destroying','destroyed');

-- +goose Down
drop table environments;
```

- [ ] **Step 3: Write `00003_audit_events.sql`**

```sql
-- +goose Up
-- Append-only audit log enforced by the DATABASE for every role (ADR-0002). No grants here: see deploy/postgres/grants.sql.
create table audit_events (
    seq         bigint generated always as identity primary key,
    at          timestamptz not null default now(),
    actor       text        not null,
    action      text        not null,
    env_id      text,
    from_state  text,
    to_state    text,
    reason      text,
    trace_id    text,
    detail      jsonb       not null default '{}'::jsonb
);
create index audit_events_env on audit_events (env_id, seq);

-- +goose StatementBegin
create function audit_events_immutable() returns trigger language plpgsql as $$
begin
    raise exception 'audit_events is append-only (% blocked)', tg_op using errcode = 'insufficient_privilege';
end $$;
-- +goose StatementEnd
create trigger audit_events_no_update before update or delete on audit_events
    for each row execute function audit_events_immutable();
create trigger audit_events_no_truncate before truncate on audit_events
    for each statement execute function audit_events_immutable();

-- +goose Down
drop trigger audit_events_no_truncate on audit_events;
drop trigger audit_events_no_update on audit_events;
drop function audit_events_immutable();
drop table audit_events;
```

- [ ] **Step 4: Write grants and role init**

`deploy/postgres/grants.sql`:

```sql
-- Idempotent runtime grants. Run as the OWNER after every migration. psql -v app_role=ephematool_app -f grants.sql
\if :{?app_role}
\else
\set app_role ephematool_app
\endif
grant usage on schema public to :"app_role";
grant select, insert, update on environments to :"app_role";   -- no DELETE: environments are tombstoned
grant select, insert on audit_events to :"app_role";           -- no UPDATE/DELETE/TRUNCATE
grant usage on sequence audit_events_seq_seq to :"app_role";
```

`deploy/postgres/init-roles.sql` (compose only; production creates the role through your secret manager):

```sql
do $$ begin
  if not exists (select 1 from pg_roles where rolname = 'ephematool_app') then
    create role ephematool_app login password 'ephematool_app';   -- dev-only password
  end if;
end $$;
```

In `deploy/compose.yaml`, mount both files into the postgres service's `/docker-entrypoint-initdb.d/` (role init runs on first start) and add a `db-grants` one-shot service (`depends_on` api migration, command `psql … -f /docker-entrypoint-initdb.d/grants.sql`) that api and worker `depends_on` with `condition: service_completed_successfully`. Set the api/worker `DATABASE_URL` to the `ephematool_app` role and keep `MIGRATE_DATABASE_URL` on the owner (config already supports both).

- [ ] **Step 5: Run to see it pass**

```bash
bazel run //:up_fake && bash scripts/verify.d/schema.sh
```

Expected: every line `PASS`, ending with `grants.sql is idempotent`. Add `bash "$ROOT/scripts/verify.d/schema.sh"` to `tools/verify.sh`. Then:

```bash
ephematest tests/test_repo_static.py -k "audit or check_constraint or migrations" --repo-root . --expect-phase 2
```

Expected: PASS (these were the failing Phase 2 repo tests).

- [ ] **Step 6: Commit** — `feat(store): environments and append-only audit schema, idempotent grants (ADR-0002)`

---

### Task 5: Lifecycle core — `envstate` and the Postgres store

**Files:**
- Create: `internal/envstate/machine.go`, `internal/envstate/machine_test.go`, `internal/envstate/BUILD.bazel`, `internal/store/queries/environments.sql`, `internal/store/pgstore.go`
- Modify: `internal/store/BUILD.bazel` (add `pgstore.go`), regenerate sqlc

**Interfaces:**
- Produces:
  - `envstate.State` (six constants), `CanTransition`, `IsTerminal`, `Valid`
  - `envstate.Patch{URL, FailureReason string; RunID int64}`
  - `envstate.Store` interface with `CAS(ctx, id, from, to, actor, reason, Patch) (won bool, err error)`
  - `envstate.Advance(ctx, Store, id, from, to, actor, reason, Patch) error`; `ErrIllegalTransition`, `ErrLostRace`
  - `store.PgStore` implementing `envstate.Store` (one transaction: UPDATE + audit INSERT)

**Acceptance Criteria:**
- Legal and illegal edges asserted; every state can reach `destroyed`
- 64 concurrent `Advance` calls on the same row: exactly one winner
- `Advance` refuses `running` without a URL
- Integration: `PgStore.CAS` writes the audit row with the state change, loses the race cleanly, and rolls back both on error

`envstate` compiled and tested when authoring: `go test -race ./envstate` passes. `PgStore` is not compiled (D5).

- [ ] **Step 1: Write the failing test** — `internal/envstate/machine_test.go`. Use the complete file from the bundle (`reference/code/envstate/machine_test.go`), which covers: legal/illegal edges, reachability of `destroyed` from every state, illegal and unknown-state rejection, the 64-goroutine race, and the URL requirement:

```go
func TestConcurrentAdvanceHasExactlyOneWinner(t *testing.T) {
	m := &memStore{state: Running}
	var wins, losses int32
	var wg sync.WaitGroup
	for i := 0; i < 64; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			switch err := Advance(context.Background(), m, "x", Running, Destroying, "t", "", Patch{}); {
			case err == nil:
				atomic.AddInt32(&wins, 1)
			case errors.Is(err, ErrLostRace):
				atomic.AddInt32(&losses, 1)
			default:
				t.Error(err)
			}
		}()
	}
	wg.Wait()
	if wins != 1 || losses != 63 || len(m.events) != 1 {
		t.Fatalf("wins=%d losses=%d events=%v", wins, losses, m.events)
	}
}

func TestRunningRequiresURLBecauseOfTheDBCheck(t *testing.T) {
	m := &memStore{state: Provisioning}
	if err := Advance(context.Background(), m, "x", Provisioning, Running, "system", "probe ok", Patch{}); !errors.Is(err, ErrIllegalTransition) {
		t.Fatalf("got %v", err)
	}
	if err := Advance(context.Background(), m, "x", Provisioning, Running, "system", "probe ok", Patch{URL: "http://pv-x.preview.localhost"}); err != nil {
		t.Fatal(err)
	}
}
```

- [ ] **Step 2: Run to see it fail** — `bazel test //internal/envstate:envstate_test` → build error (package missing).

- [ ] **Step 3: Implement** — copy `reference/code/envstate/machine.go` to `internal/envstate/machine.go` (stdlib only; no import changes needed) and add `BUILD.bazel`:

```python
load("@io_bazel_rules_go//go:def.bzl", "go_library")
load("//tools/bzl:go.bzl", "go_test")

go_library(
    name = "envstate",
    srcs = ["machine.go"],
    importpath = "github.com/ephematool/ephematool/internal/envstate",
    visibility = ["//:__subpackages__"],
)

go_test(
    name = "envstate_test",
    srcs = ["machine_test.go"],
    embed = [":envstate"],
)
```

(`bazel run //:gazelle` will regenerate the same; keep the checked-in file consistent with it.) Core of `machine.go`, for review:

```go
var edges = map[State][]State{
	Requested:    {Provisioning, Failed, Destroying},
	Provisioning: {Running, Failed, Destroying},
	Running:      {Destroying},
	Failed:       {Destroying},
	Destroying:   {Destroyed},
	Destroyed:    {},
}

func Advance(ctx context.Context, s Store, id string, from, to State, actor, reason string, p Patch) error {
	if !Valid(from) || !Valid(to) || !CanTransition(from, to) {
		return fmt.Errorf("%w: %s -> %s", ErrIllegalTransition, from, to)
	}
	if to == Running && p.URL == "" { // the DB CHECK requires url; fail early with a clear error
		return fmt.Errorf("%w: running requires a URL", ErrIllegalTransition)
	}
	won, err := s.CAS(ctx, id, from, to, actor, reason, p)
	if err != nil {
		return err
	}
	if !won {
		return ErrLostRace
	}
	return nil
}
```

- [ ] **Step 4: Run to see it pass** — `bazel test //internal/envstate:envstate_test`. Expected when authoring (`go test -race`): PASS.

- [ ] **Step 5: Write the sqlc queries** — `internal/store/queries/environments.sql` (named args keep generated field names deterministic):

```sql
-- name: CASState :execrows
update environments
   set state = sqlc.arg(to_state)::text,
       state_version = state_version + 1,
       updated_at = now(),
       url = coalesce(sqlc.narg(url)::text, url),
       failure_reason = coalesce(sqlc.narg(failure_reason)::text, failure_reason),
       run_id = coalesce(sqlc.narg(run_id)::bigint, run_id),
       -- failed environments free their quota slot automatically after FAILED_RETENTION (ADR-0003)
       expires_at = case when sqlc.arg(to_state)::text = 'failed'
                         then least(expires_at, now() + sqlc.arg(failed_retention)::interval) else expires_at end
 where id = sqlc.arg(id)::text and state = sqlc.arg(from_state)::text;

-- name: InsertAuditEvent :exec
insert into audit_events (actor, action, env_id, from_state, to_state, reason, trace_id)
values (sqlc.arg(actor), sqlc.arg(action), sqlc.arg(env_id), sqlc.narg(from_state), sqlc.narg(to_state),
        sqlc.narg(reason), sqlc.narg(trace_id));
```

Run `go generate ./internal/store` (or the repo's sqlc target) and commit the output.

- [ ] **Step 6: Write the integration test first** — `internal/store/pgstore_integration_test.go` (needs `TEST_DATABASE_URL` to an app-role connection against a freshly migrated database; the test **fails**, not skips, when it is unset):

```go
func TestPgStoreCASWritesAuditAndLosesRaceCleanly(t *testing.T) {
	url := os.Getenv("TEST_DATABASE_URL")
	if url == "" {
		t.Fatal("TEST_DATABASE_URL is required (migrated database, runtime role); run via bazel run //:verify")
	}
	ctx := context.Background()
	pool, err := Open(ctx, url)
	if err != nil {
		t.Fatal(err)
	}
	defer pool.Close()
	insertEnv(t, ctx, pool, "pv-casteststs", "requested") // helper: INSERT with valid sha/expiry via the app role

	s := PgStore{Pool: pool, FailedRetention: 2 * time.Hour}
	if err := envstate.Advance(ctx, s, "pv-casteststs", envstate.Requested, envstate.Provisioning, "worker", "dispatched", envstate.Patch{RunID: 42}); err != nil {
		t.Fatal(err)
	}
	// The same transition again has lost the race: state is no longer "requested".
	if err := envstate.Advance(ctx, s, "pv-casteststs", envstate.Requested, envstate.Provisioning, "worker", "dup", envstate.Patch{}); !errors.Is(err, envstate.ErrLostRace) {
		t.Fatalf("want ErrLostRace, got %v", err)
	}
	var n int
	if err := pool.QueryRow(ctx, `select count(*) from audit_events where env_id=$1`, "pv-casteststs").Scan(&n); err != nil || n != 1 {
		t.Fatalf("audit rows = %d, err = %v; want exactly 1 (the lost race writes none)", n, err)
	}
}
```

- [ ] **Step 7: Implement `PgStore`** — `internal/store/pgstore.go`:

```go
package store

import (
	"context"
	"time"

	"github.com/jackc/pgx/v5/pgtype"
	"github.com/jackc/pgx/v5/pgxpool"

	"github.com/ephematool/ephematool/internal/envstate"
)

// PgStore implements envstate.Store: the state change and its audit row commit together or not at all.
type PgStore struct {
	Pool            *pgxpool.Pool
	FailedRetention time.Duration // cap on how long a failed environment keeps its quota slot
}

func (s PgStore) CAS(ctx context.Context, id string, from, to envstate.State, actor, reason string, p envstate.Patch) (bool, error) {
	tx, err := s.Pool.Begin(ctx)
	if err != nil {
		return false, err
	}
	defer tx.Rollback(ctx) // no-op after Commit

	q := New(tx)
	n, err := q.CASState(ctx, CASStateParams{
		ID: id, FromState: string(from), ToState: string(to),
		URL:           text(p.URL),
		FailureReason: text(firstNonEmpty(p.FailureReason, failReason(to, reason))),
		RunID:         int8(p.RunID),
		FailedRetention: pgtype.Interval{Microseconds: s.FailedRetention.Microseconds(), Valid: true},
	})
	if err != nil {
		return false, err
	}
	if n == 0 {
		return false, nil // someone else moved it: no audit row, caller sees ErrLostRace
	}
	if err := q.InsertAuditEvent(ctx, InsertAuditEventParams{
		Actor: actor, Action: actionFor(from, to), EnvID: pgtype.Text{String: id, Valid: true},
		FromState: text(string(from)), ToState: text(string(to)), Reason: text(reason), TraceID: traceIDFrom(ctx),
	}); err != nil {
		return false, err
	}
	return true, tx.Commit(ctx)
}
```

Helper functions (`text`, `int8`, `firstNonEmpty`, `failReason`, `actionFor`, `traceIDFrom`) live in the same file: `text("")` returns an invalid `pgtype.Text` (NULL, so `coalesce` keeps the column), `int8(0)` likewise, `actionFor(Requested, Provisioning)` returns `provision.start`, and so on per the audit vocabulary in spec section 5; `traceIDFrom` reads the span context from `ctx`. The generated parameter type names above follow sqlc's rules for the named arguments and may differ slightly in your sqlc version; adjust to the generated struct. Not compiled when authoring.

- [ ] **Step 8: Run to see it pass** — `TEST_DATABASE_URL=… bazel test //internal/store:store_integration_test` (wire the env var in the test target's `env`/`tags = ["requires-network"]` as the repo does for other DB tests).

- [ ] **Step 9: Commit** — `feat(envstate): forward-only CAS state machine and Postgres store (ADR-0001)`

---

### Task 6: Serialised migrations and the privilege self-check

**Files:**
- Create: `internal/store/migrate.go` (replaces `Migrate` in `store.go`), `internal/store/privileges.go`, `internal/store/privileges_test.go`, `internal/store/migrate_integration_test.go`
- Modify: `internal/store/store.go` (remove the old `Migrate`), `internal/config/config.go` (`DB_PRIVILEGE_CHECK`), `.env.example`, `cmd/api/main.go`, `cmd/worker/main.go`

**Interfaces:**
- Produces: `store.Migrate(ctx, pool)` safe under concurrency; `store.CheckPrivileges(ctx, pool) error` returning `ErrPrivileges`; config `DB_PRIVILEGE_CHECK` = `enforce|warn|off` (default `warn`).

**Acceptance Criteria:**
- Three concurrent `Migrate` calls on an empty database all return nil; `goose_db_version` has exactly one row per migration
- The owner role fails `CheckPrivileges`; the app role passes after `grants.sql`
- API start fails in `enforce` mode when the role is wrong; logs and continues in `warn` mode

Not compiled when authoring (D5); the SQL inside `CheckPrivileges` was executed on Postgres 16.

- [ ] **Step 1: Write the failing tests**

`internal/store/migrate_integration_test.go`:

```go
func TestMigrateIsSafeUnderConcurrency(t *testing.T) {
	url := os.Getenv("TEST_OWNER_DATABASE_URL") // an EMPTY database, owner role
	if url == "" {
		t.Fatal("TEST_OWNER_DATABASE_URL is required (empty database)")
	}
	ctx := context.Background()
	pool, err := Open(ctx, url)
	if err != nil {
		t.Fatal(err)
	}
	defer pool.Close()
	var wg sync.WaitGroup
	errs := make(chan error, 3)
	for i := 0; i < 3; i++ { // three replicas starting at once
		wg.Add(1)
		go func() { defer wg.Done(); errs <- Migrate(ctx, pool) }()
	}
	wg.Wait()
	close(errs)
	for err := range errs {
		if err != nil {
			t.Fatalf("Migrate: %v", err)
		}
	}
	var applied, distinct int
	if err := pool.QueryRow(ctx, `select count(*), count(distinct version_id) from goose_db_version where version_id > 0 and is_applied`).Scan(&applied, &distinct); err != nil {
		t.Fatal(err)
	}
	if applied != distinct {
		t.Fatalf("a migration was applied more than once: %d rows, %d distinct versions", applied, distinct)
	}
}
```

`internal/store/privileges_test.go` (against the compose database, after grants):

```go
func TestCheckPrivilegesRejectsOwnerAcceptsAppRole(t *testing.T) {
	app, owner := os.Getenv("TEST_DATABASE_URL"), os.Getenv("TEST_OWNER_DATABASE_URL")
	if app == "" || owner == "" {
		t.Fatal("TEST_DATABASE_URL and TEST_OWNER_DATABASE_URL are required")
	}
	ctx := context.Background()
	ap, err := Open(ctx, app)
	if err != nil {
		t.Fatal(err)
	}
	defer ap.Close()
	if err := CheckPrivileges(ctx, ap); err != nil {
		t.Fatalf("app role should pass: %v", err)
	}
	ow, err := Open(ctx, owner)
	if err != nil {
		t.Fatal(err)
	}
	defer ow.Close()
	if err := CheckPrivileges(ctx, ow); !errors.Is(err, ErrPrivileges) {
		t.Fatalf("owner must fail (it can UPDATE/DELETE audit rows): %v", err)
	}
}
```

- [ ] **Step 2: Run to see them fail** — `undefined: CheckPrivileges`; `Migrate` test flaky or failing with goose global state under concurrency.

- [ ] **Step 3: Implement** — `internal/store/migrate.go`:

```go
package store

import (
	"context"
	"io/fs"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/jackc/pgx/v5/stdlib"
	"github.com/pressly/goose/v3"
	"github.com/pressly/goose/v3/lock"
)

// Migrate applies the embedded migrations under a Postgres session advisory lock, so concurrent API replicas
// (or a Helm pre-upgrade Job racing a starting pod) serialise instead of colliding (backlog #4).
func Migrate(ctx context.Context, pool *pgxpool.Pool) error {
	db := stdlib.OpenDBFromPool(pool)
	defer db.Close()

	locker, err := lock.NewPostgresSessionLocker() // pg_advisory_lock held on one connection for the whole run
	if err != nil {
		return err
	}
	sub, err := fs.Sub(migrations, "migrations")
	if err != nil {
		return err
	}
	p, err := goose.NewProvider(goose.DialectPostgres, db, sub, goose.WithSessionLocker(locker))
	if err != nil {
		return err
	}
	_, err = p.Up(ctx)
	return err
}
```

`internal/store/privileges.go`:

```go
package store

import (
	"context"
	"errors"
	"fmt"

	"github.com/jackc/pgx/v5/pgxpool"
)

// ErrPrivileges means the connected role does not have exactly the privileges the platform requires.
var ErrPrivileges = errors.New("store: database role privileges are wrong")

// privilegeSQL is true only for the runtime role: it can read and append audit rows and cannot change or remove them,
// and it can update but not delete environments. The owner fails it on purpose: the app must not run as the owner.
const privilegeSQL = `select
  has_table_privilege(current_user,'audit_events','SELECT')
  and has_table_privilege(current_user,'audit_events','INSERT')
  and not has_table_privilege(current_user,'audit_events','UPDATE')
  and not has_table_privilege(current_user,'audit_events','DELETE')
  and not has_table_privilege(current_user,'audit_events','TRUNCATE')
  and has_table_privilege(current_user,'environments','UPDATE')
  and not has_table_privilege(current_user,'environments','DELETE')`

func CheckPrivileges(ctx context.Context, pool *pgxpool.Pool) error {
	var ok bool
	if err := pool.QueryRow(ctx, privilegeSQL).Scan(&ok); err != nil {
		return fmt.Errorf("%w: %v", ErrPrivileges, err) // e.g. tables missing because migrations did not run
	}
	if !ok {
		return ErrPrivileges
	}
	return nil
}
```

`config.go`: `DBPrivilegeCheck string `env:"DB_PRIVILEGE_CHECK" envDefault:"warn"`` with validation `enforce|warn|off`; add to `.env.example` and the config tests. In `cmd/api/main.go` after `pool` is opened (and after migrations):

```go
	switch err := store.CheckPrivileges(ctx, pool); {
	case err == nil:
	case cfg.DBPrivilegeCheck == "enforce":
		return fmt.Errorf("refusing to start: %w", err) // a mis-granted role must fail the deploy, not a request later
	case cfg.DBPrivilegeCheck == "warn":
		slog.WarnContext(ctx, "db.privileges_wrong", "error", err)
	}
```

Do the same in `cmd/worker/main.go` once it opens a pool (Plan 2). In `store.go`, delete the old `Migrate` and its `goose` global setup.

- [ ] **Step 4: Run to see them pass**

```bash
TEST_OWNER_DATABASE_URL=… TEST_DATABASE_URL=… bazel test //internal/store/...
```

- [ ] **Step 5: Commit** — `feat(store): serialise migrations with a session lock; verify runtime privileges (ADR-0002)`

---

### Task 7: Liveness and readiness endpoints

**Files:**
- Create: `internal/probes/probes.go`, `internal/probes/probes_test.go`, `internal/probes/BUILD.bazel`
- Modify: `internal/httpapi/api.go` (`Deps.Probes`, routes), `cmd/api/main.go`, `cmd/api/BUILD.bazel`, `internal/httpapi/BUILD.bazel`, `api/openapi.json` only if routes are registered through huma (they are not: plain mux routes keep the OpenAPI diff-free)

**Interfaces:**
- Produces: `probes.New(timeout, ...Check) *Set`; `Set.Liveness()`, `Set.Readiness()`, `Set.Drain()`; `/healthz` and `/readyz` on the API (unauthenticated, no session)

**Acceptance Criteria:**
- `/healthz` is 200 even when every dependency check fails
- `/readyz` is 503 when a critical check fails or times out, 200 with only a non-critical failure, and never contains a driver error string
- After `Drain()` `/readyz` is 503
- `test_health_and_readiness_endpoints` passes against the compose stack
- `/readyz` includes the `db_privileges` check (critical in `enforce` mode)

`probes` compiled and tested when authoring (`go test -race ./probes` passes: liveness independence, critical vs non-critical with no DSN leakage, timeout, drain). Wiring is not compiled (D5).

- [ ] **Step 1: Write the failing test** — copy `reference/code/probes/probes_test.go` to `internal/probes/probes_test.go`. It contains `TestLivenessNeverDependsOnDeps`, `TestReadinessCriticalVsNonCritical` (asserts the driver error string `dsn=postgres://u:pw@h/db refused` never appears in the body), and `TestSlowCheckTimesOutAndDrainFlipsReadiness`.

- [ ] **Step 2: Run to see it fail** — `bazel test //internal/probes:probes_test` → package missing.

- [ ] **Step 3: Implement** — copy `reference/code/probes/probes.go` to `internal/probes/probes.go` (stdlib only) with this `BUILD.bazel`:

```python
load("@io_bazel_rules_go//go:def.bzl", "go_library")
load("//tools/bzl:go.bzl", "go_test")

go_library(
    name = "probes",
    srcs = ["probes.go"],
    importpath = "github.com/ephematool/ephematool/internal/probes",
    visibility = ["//:__subpackages__"],
)

go_test(
    name = "probes_test",
    srcs = ["probes_test.go"],
    embed = [":probes"],
)
```

- [ ] **Step 4: Run to see it pass** — `bazel test //internal/probes:probes_test` (expected PASS).

- [ ] **Step 5: Write the failing handler test** — in `internal/httpapi/api_test.go` (new):

```go
func TestHealthzAndReadyzArePublic(t *testing.T) {
	set := probes.New(time.Second,
		probes.Check{Name: "db", Critical: true, Fn: func(context.Context) error { return errors.New("down") }})
	h, _ := New(Deps{Config: config.Config{}, Probes: set}) // no Sessions: handler works without a session store
	for path, want := range map[string]int{"/healthz": 200, "/readyz": 503} {
		w := httptest.NewRecorder()
		h.ServeHTTP(w, httptest.NewRequest(http.MethodGet, path, nil))
		if w.Code != want {
			t.Errorf("%s = %d, want %d", path, w.Code, want)
		}
	}
}
```

Run: `undefined field Probes in Deps`.

- [ ] **Step 6: Wire** — `internal/httpapi/api.go`: add `Probes *probes.Set` to `Deps`; in `New`, before building `inner`:

```go
	if deps.Probes != nil {
		mux.Handle("GET /healthz", deps.Probes.Liveness()) // process alive; never depends on Postgres/Redis
		mux.Handle("GET /readyz", deps.Probes.Readiness()) // dependencies usable; drained on shutdown
	}
```

`cmd/api/main.go`: build the set after `pool`/`rdb` exist and pass it in `Deps`:

```go
	probeSet := probes.New(2*time.Second,
		probes.Check{Name: "postgres", Critical: true, Fn: pool.Ping},
		probes.Check{Name: "redis", Critical: true, Fn: func(c context.Context) error { return rdb.Ping(c).Err() }},
		probes.Check{Name: "db_privileges", Critical: cfg.DBPrivilegeCheck == "enforce",
			Fn: func(c context.Context) error { return store.CheckPrivileges(c, pool) }},
		probes.Check{Name: "collector", Critical: false, Fn: httpGetOK(cfg.CollectorHealthURL)}, // telemetry loss must not unready the API
	)
```

and in the shutdown branch from Task 3, call `probeSet.Drain()` before the sleep. `httpGetOK` is a 10-line helper using `http.NewRequestWithContext`; place it in `cmd/api/server.go`.

- [ ] **Step 7: Run to see it pass** — `bazel test //internal/httpapi:httpapi_test`, then against the stack `ephematest tests -k "health_and_readiness" --expect-phase 7 --repo-root .`.

- [ ] **Step 8: Commit** — `feat(api): /healthz and /readyz with draining and privilege check`

---

### Task 8: CI workflow with the conformance gate

**Files:**
- Create: `.github/workflows/ci.yaml`, `deploy/compose.quota.yaml` (overlay setting `ENV_MAX_PER_USER=3` for quota mode)

**Interfaces:**
- Produces: required checks `lint-test`, `web`, `verify-stack`, `ephematest`; `EXPECT_PHASE` variable bumped per completed phase.

**Acceptance Criteria:**
- A PR with a deliberately reverted Phase 1 behaviour (for example, remove `X-Trace-Id`) fails `ephematest`
- All four jobs green on `main`
- `test_ci_workflow_exists_and_runs_verification` passes

Workflow YAML was syntax-checked when authoring; it has not run on GitHub.

- [ ] **Step 1: Write the failing check** — the repo test already asserts the workflow's existence and contents: `ephematest tests/test_repo_static.py -k ci_workflow --repo-root . --expect-phase 7` → FAIL.

- [ ] **Step 2: Create the workflow** — copy `reference/ci/ci.yaml` to `.github/workflows/ci.yaml`. Adjust two paths for this repo layout: the install step becomes `pip install -e ./tools/ephematest` and the self-test step `python tools/ephematest/selftest.py`. Pin every `uses:` to a full commit SHA (the reference shows tags for readability). Keep the `images` job disabled until Plan 5 (remove `if: github.ref == 'refs/heads/main'` jobs or gate with `if: false`).

- [ ] **Step 3: Quota overlay** — `deploy/compose.quota.yaml`:

```yaml
# Used only by the CI quota-mode step: recreate api/worker with a low per-user limit.
services:
  api:
    environment:
      ENV_MAX_PER_USER: "3"
  worker:
    environment:
      ENV_MAX_PER_USER: "3"
```

The CI `ephematest` job runs the general suite first, then `docker compose -f deploy/compose.yaml -f deploy/compose.e2e.yaml -f deploy/compose.quota.yaml up -d api worker` and `ephematest tests --quota-mode`. (Quota tests only become meaningful once the create API exists in Plan 2; until then they xfail by phase.)

- [ ] **Step 4: Prove the gate bites** — on a throwaway branch, comment out the `TraceIDHeader` middleware in `internal/httpapi/api.go`, push, and confirm the `ephematest` job fails on `test_every_api_response_carries_x_trace_id` and `test_trace_ids_are_unique`. Revert.

- [ ] **Step 5: Branch protection** — require the four checks on `main` (repo settings; record in `docs/operations.md`).

- [ ] **Step 6: Commit** — `ci: build, verify and phase-gated conformance checks (ADR-0005)`

---

### Task 9: Documentation fixes through the GSD flow (findings D-1, D-8)

**Files:**
- Modify: `CLAUDE.md`, `README.md`, `.planning/STATE.md`, `.planning/ROADMAP.md`
- Create: `docs/architecture.md`, `docs/operations.md`, `docs/decisions/` (copy ADR-0001…0005 and INDEX), `SECURITY.md`

**Acceptance Criteria:**
- `CLAUDE.md` technology block describes the real stack (Go, huma, asynq/Redis, Postgres/sqlc/goose, React/Vite, Bazel) and no longer mentions Fastify, Drizzle or pg-boss
- README is the project overview and quickstart only; the architecture text and the runbook live under `docs/`
- `SECURITY.md` exists with a private reporting path
- `test_docs_are_not_stale` passes

- [ ] **Step 1: Write the failing check** — `ephematest tests/test_repo_static.py -k docs --repo-root . --expect-phase 7` → FAIL ("describes a stack the repo does not use").

- [ ] **Step 2: Start through GSD** — run `/gsd-quick "Refresh CLAUDE.md stack block and split README into docs/"`, since `CLAUDE.md` says direct edits are not allowed. Provide the replacement stack table from section "Decisions taken" of the spec.

- [ ] **Step 3: Split the README** — `README.md` keeps "What it is", the 5-minute `bazel run //:up_fake` quickstart and links; the pasted `ARCHITECTURE.md` section moves to `docs/architecture.md`; the "Running Ephematool" runbook moves to `docs/operations.md`.

- [ ] **Step 4: ADRs and SECURITY.md** — copy `docs/decisions/*` from this bundle; add `SECURITY.md` (report through GitHub private vulnerability reporting, supported versions, response expectations).

- [ ] **Step 5: Update planning state** — register this plan's tasks as a hardening phase through `/gsd-*` so `STATE.md` and `ROADMAP.md` stay consistent (the roadmap itself suggests a hardening pass between Phase 2 planning and execution).

- [ ] **Step 6: Run to see it pass** — `ephematest tests/test_repo_static.py --repo-root . --expect-phase 7`. Expected after this plan: the remaining failures are only the production-deploy artifact and the non-root web image (Plan 5), and the Phase 2+ contract-sync tests (Plan 2).

- [ ] **Step 7: Commit** — `docs: align CLAUDE.md with the Go stack, split README, add ADRs and SECURITY.md`

---

## Spec coverage

| Spec section | Covered by |
|---|---|
| 4 State machine and schema | Tasks 4, 5 |
| 4 Audit append-only, grants, privilege check | Tasks 4, 6 (ADR-0002) |
| 5.2 Webhook verification code | consumed by Plan 3 (code and tests exist in `reference/code/webhook`) |
| 5.1, 5.6 Create path and quotas | Plan 2 (create), Plan 4 (quotas) |
| 6 Health and readiness, graceful shutdown | Tasks 3, 7 |
| 6 SLO alerts | Plan 5 (rules drafted in `reference/deploy/prometheus`) |
| 7 Testing: conformance gate, self-test, CI | Tasks 1, 8 (ADR-0005) |
| 7 Security: server timeouts | Task 3 |
| 7 Documentation | Task 9 |
| 8 Spikes S1, S4 | scheduled at the start of Plan 2 and Plan 3 respectively |

## Follow-on plans

- **Plan 2 — Finish Phase 2:** amends existing plans 02-01…02-17 with: the D1/D2 changes above, the create transaction (validation before the lock, `Idempotency-Key`, env-id retry), `Provisioner` interface, fakegithub control endpoints (`/__fake/runs/{id}/conclude`, `/__fake/membership`, `/__fake/webhooks/pause`, `/__fake/reset`), and `ephematest --expect-phase 2` plus its contract-sync tests as the exit gate.
- **Plan 3 — Phases 3–5:** inventory API and UI, diagnostics, destroy, orphans, reconciler with stalled-row repair, webhook endpoint, health/drift signals and verdict, reaper, extension, PR-close, pre-expiry comment; exit gate `--expect-phase 5` plus the kill-the-worker exactly-once test.
- **Plan 4 — Phases 6–7:** telemetry views and trends, atomic quotas with `lock_timeout`, secrets by reference, policy engine, canary-secret redaction scan; exit gate `--expect-phase 7` and `--quota-mode`.
- **Plan 5 — Production deployment:** Helm chart (worker and web templates, ingress, RBAC, config), release and supply chain, rate limiting and CSRF, non-root web image, backup/DR drills, alert rules with `promtool test rules`, runbooks, module path rename; exit is the production readiness checklist.
