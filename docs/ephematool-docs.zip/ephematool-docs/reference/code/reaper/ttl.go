// Package reaper holds the pure TTL rules (ENV-04/05/06). The DB side is two statements, both atomic:
//
// Claim (exactly-once across replicas and restarts; no in-memory timers):
//
//	WITH due AS (
//	  SELECT id FROM environments
//	   WHERE state IN ('running','failed') AND expires_at <= now()
//	   ORDER BY expires_at LIMIT $1
//	   FOR UPDATE SKIP LOCKED)
//	UPDATE environments e SET state='destroying', state_version=state_version+1, updated_at=now()
//	  FROM due WHERE e.id=due.id RETURNING e.id;
//
// each returned id is audited ('ttl.expired') in the same transaction and enqueued as env:destroy
// (asynq TaskID = env id => duplicate enqueue is a no-op).
//
// Extend (loses cleanly against the claim because both predicate on state/expires_at):
//
//	UPDATE environments SET expires_at=$2, ttl_extensions=ttl_extensions+1
//	 WHERE id=$1 AND state='running' AND expires_at > now() AND expires_at = $3;   -- optimistic on old value
package reaper

import (
	"errors"
	"time"
)

var (
	ErrNotExtendable = errors.New("reaper: environment is not running or already expired")
	ErrCapExceeded   = errors.New("reaper: extension would exceed the maximum lifetime")
	ErrBadDuration   = errors.New("reaper: extension must be positive")
)

type Policy struct {
	DefaultTTL      time.Duration
	MaxLifetime     time.Duration // hard cap measured from created_at, not from "now"
	MaxPerExtension time.Duration
}

// NewExpiry validates the requested ttl at create time.
func (p Policy) NewExpiry(now time.Time, ttl time.Duration) (time.Time, error) {
	if ttl == 0 {
		ttl = p.DefaultTTL
	}
	if ttl <= 0 {
		return time.Time{}, ErrBadDuration
	}
	if ttl > p.MaxLifetime {
		return time.Time{}, ErrCapExceeded
	}
	return now.Add(ttl), nil
}

// Extend returns the new expiry. The cap is on total lifetime so repeated small extensions cannot bypass it.
func (p Policy) Extend(created, expires, now time.Time, running bool, add time.Duration) (time.Time, error) {
	if add <= 0 || (p.MaxPerExtension > 0 && add > p.MaxPerExtension) {
		return time.Time{}, ErrBadDuration
	}
	if !running || !expires.After(now) {
		return time.Time{}, ErrNotExtendable
	}
	next := expires.Add(add)
	if next.Sub(created) > p.MaxLifetime {
		return time.Time{}, ErrCapExceeded
	}
	return next, nil
}

// NeedsWarning is true once, inside the warning window, so the PR comment is posted exactly once
// (the DB flag expiry_warned_at is set with CAS in the same step that enqueues the comment).
func NeedsWarning(expires, now time.Time, window time.Duration, alreadyWarned bool) bool {
	return !alreadyWarned && expires.After(now) && expires.Sub(now) <= window
}
