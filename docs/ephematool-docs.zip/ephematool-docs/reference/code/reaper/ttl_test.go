package reaper

import (
	"errors"
	"testing"
	"time"
)

var (
	t0 = time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC)
	pl = Policy{DefaultTTL: 4 * time.Hour, MaxLifetime: 24 * time.Hour, MaxPerExtension: 8 * time.Hour}
)

func TestNewExpiry(t *testing.T) {
	if e, err := pl.NewExpiry(t0, 0); err != nil || !e.Equal(t0.Add(4*time.Hour)) {
		t.Fatal(e, err)
	}
	if _, err := pl.NewExpiry(t0, 25*time.Hour); !errors.Is(err, ErrCapExceeded) {
		t.Fatal(err)
	}
	if _, err := pl.NewExpiry(t0, -time.Minute); !errors.Is(err, ErrBadDuration) {
		t.Fatal(err)
	}
}

func TestExtendCapIsOnTotalLifetime(t *testing.T) {
	created, expires := t0, t0.Add(4*time.Hour)
	now := t0.Add(time.Hour)
	for i := 0; i < 2; i++ { // 4h -> 12h -> 20h
		var err error
		expires, err = pl.Extend(created, expires, now, true, 8*time.Hour)
		if err != nil {
			t.Fatalf("extension %d: %v", i, err)
		}
	}
	if _, err := pl.Extend(created, expires, now, true, 8*time.Hour); !errors.Is(err, ErrCapExceeded) { // 28h > 24h
		t.Fatalf("want cap error, got %v", err)
	}
	if _, err := pl.Extend(created, expires, now, true, 4*time.Hour); err != nil { // exactly 24h is allowed
		t.Fatal(err)
	}
}

func TestExtendRefusedWhenExpiredOrNotRunning(t *testing.T) {
	if _, err := pl.Extend(t0, t0.Add(time.Hour), t0.Add(2*time.Hour), true, time.Hour); !errors.Is(err, ErrNotExtendable) {
		t.Fatal(err)
	}
	if _, err := pl.Extend(t0, t0.Add(time.Hour), t0, false, time.Hour); !errors.Is(err, ErrNotExtendable) {
		t.Fatal(err)
	}
	if _, err := pl.Extend(t0, t0.Add(time.Hour), t0, true, 0); !errors.Is(err, ErrBadDuration) {
		t.Fatal(err)
	}
}

func TestWarningFiresOnceInsideWindow(t *testing.T) {
	exp := t0.Add(time.Hour)
	if NeedsWarning(exp, t0, 30*time.Minute, false) {
		t.Fatal("too early")
	}
	if !NeedsWarning(exp, t0.Add(40*time.Minute), 30*time.Minute, false) {
		t.Fatal("should warn")
	}
	if NeedsWarning(exp, t0.Add(40*time.Minute), 30*time.Minute, true) {
		t.Fatal("must not warn twice")
	}
	if NeedsWarning(exp, t0.Add(2*time.Hour), 30*time.Minute, false) {
		t.Fatal("no warning after expiry")
	}
}
