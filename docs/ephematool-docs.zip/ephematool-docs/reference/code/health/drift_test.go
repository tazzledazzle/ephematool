package health

import "testing"

func TestWorkflowGreenButAppBrokenIsNotLive(t *testing.T) {
	r := Classify(Signals{RecordRunning: Yes, WorkflowSuccess: Yes, NamespaceExists: Yes, WorkloadReady: Yes, ProbeOK: No})
	if r.Verdict != NotLive {
		t.Fatalf("%+v", r)
	}
}

func TestAllAgreeIsLive(t *testing.T) {
	if r := Classify(Signals{Yes, Yes, Yes, Yes, Yes}); r.Verdict != Live {
		t.Fatalf("%+v", r)
	}
}

func TestOutOfBandNamespaceDeleteIsDriftWithNamedSignals(t *testing.T) {
	r := Classify(Signals{RecordRunning: Yes, WorkflowSuccess: Yes, NamespaceExists: No, WorkloadReady: No, ProbeOK: No})
	if r.Verdict != Drifted || len(r.Conflicts) != 1 || r.Conflicts[0] != "record=running vs namespace=missing" {
		t.Fatalf("%+v", r)
	}
}

func TestNamespaceWithoutRunningRecordIsDrift(t *testing.T) {
	if r := Classify(Signals{RecordRunning: No, NamespaceExists: Yes}); r.Verdict != Drifted {
		t.Fatalf("%+v", r)
	}
}

func TestMissingDataNeverClaimsLive(t *testing.T) {
	if r := Classify(Signals{RecordRunning: Yes, NamespaceExists: Yes, WorkloadReady: Yes, ProbeOK: Unknown}); r.Verdict != Unchecked {
		t.Fatalf("%+v", r)
	}
}

func TestDebounce(t *testing.T) {
	if Debounce([]Verdict{Live, NotLive}, 3) != Unchecked {
		t.Fatal("one bad probe must not flip the label")
	}
	if Debounce([]Verdict{NotLive, NotLive, NotLive}, 3) != NotLive {
		t.Fatal("three bad probes must")
	}
	if Debounce([]Verdict{NotLive, NotLive, Live}, 3) != Live {
		t.Fatal("recovery is immediate")
	}
}
