// Package health implements STAT-03/STAT-04: an environment is "live" only when the lifecycle record, the
// cluster and a real probe agree; any disagreement is "drifted" with the conflicting signals named.
package health

import (
	"sort"
	"strings"
)

type Tri int

const (
	Unknown Tri = iota
	No
	Yes
)

// Signals are independent observations. None may be derived from another (workflow green != healthy).
type Signals struct {
	RecordRunning   Tri // DB state == running
	WorkflowSuccess Tri // last Actions run concluded success
	NamespaceExists Tri // kube API: namespace present and Active
	WorkloadReady   Tri // kube API: all Deployments available
	ProbeOK         Tri // HTTP probe through the gateway returned the expected status
}

type Verdict string

const (
	Live      Verdict = "live"
	NotLive   Verdict = "not_live"
	Drifted   Verdict = "drifted"
	Unchecked Verdict = "unchecked"
)

type Result struct {
	Verdict   Verdict  `json:"verdict"`
	Conflicts []string `json:"conflicts,omitempty"` // human-readable, stable order
	Reason    string   `json:"reason"`
}

// Classify applies the rules in this order (first match wins):
//  1. record says running but the namespace is gone -> drifted (out-of-band delete)
//  2. namespace present but record says not running/destroyed -> drifted (orphan-ish)
//  3. workflow success but probe fails -> not_live (broken app, SC1)
//  4. record running, namespace, workload ready, probe all yes -> live
//  5. any required signal Unknown -> unchecked (never claim live on missing data)
//  6. otherwise not_live
func Classify(s Signals) Result {
	var c []string
	if s.RecordRunning == Yes && s.NamespaceExists == No {
		c = append(c, "record=running vs namespace=missing")
	}
	if s.RecordRunning == No && s.NamespaceExists == Yes {
		c = append(c, "record!=running vs namespace=present")
	}
	if s.RecordRunning == Yes && s.WorkloadReady == No && s.NamespaceExists == Yes && s.ProbeOK == Yes {
		c = append(c, "probe=ok vs workload=not-ready")
	}
	if len(c) > 0 {
		sort.Strings(c)
		return Result{Verdict: Drifted, Conflicts: c, Reason: "signals disagree: " + strings.Join(c, "; ")}
	}
	if s.WorkflowSuccess == Yes && s.ProbeOK == No {
		return Result{Verdict: NotLive, Reason: "workflow succeeded but the health probe fails"}
	}
	req := []Tri{s.RecordRunning, s.NamespaceExists, s.WorkloadReady, s.ProbeOK}
	allYes, anyUnknown := true, false
	for _, v := range req {
		allYes = allYes && v == Yes
		anyUnknown = anyUnknown || v == Unknown
	}
	switch {
	case allYes:
		return Result{Verdict: Live, Reason: "lifecycle, cluster and probe agree"}
	case anyUnknown:
		return Result{Verdict: Unchecked, Reason: "a required signal has not been observed yet"}
	}
	return Result{Verdict: NotLive, Reason: "one or more signals report not ready"}
}

// Debounce requires N consecutive identical non-live verdicts before flagging, to avoid flapping on a
// single failed probe; live is promoted only when a fresh Classify says live.
func Debounce(history []Verdict, n int) Verdict {
	if len(history) == 0 {
		return Unchecked
	}
	last := history[len(history)-1]
	if last == Live || last == Unchecked || n <= 1 {
		return last
	}
	if len(history) < n {
		return Unchecked
	}
	for _, v := range history[len(history)-n:] {
		if v != last {
			return Unchecked
		}
	}
	return last
}
