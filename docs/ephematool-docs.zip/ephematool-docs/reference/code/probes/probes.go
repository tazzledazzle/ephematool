// Package probes provides /healthz (liveness: process is not wedged) and /readyz (readiness: dependencies usable).
// Liveness must NOT depend on Postgres/Redis (a DB blip must not restart every pod). Readiness checks run in
// parallel with a hard per-check timeout, and shutdown flips readiness to 503 first so the LB drains the pod.
package probes

import (
	"context"
	"encoding/json"
	"net/http"
	"sort"
	"sync"
	"sync/atomic"
	"time"
)

type Check struct {
	Name     string
	Fn       func(context.Context) error
	Critical bool // non-critical failures are reported but keep the pod Ready (e.g. Tempo down)
}

type Set struct {
	checks   []Check
	timeout  time.Duration
	draining atomic.Bool
}

func New(timeout time.Duration, checks ...Check) *Set { return &Set{checks: checks, timeout: timeout} }

// Drain is called at the start of graceful shutdown.
func (s *Set) Drain() { s.draining.Store(true) }

func (s *Set) Liveness() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"status":"ok"}`))
	})
}

type result struct {
	Name     string `json:"name"`
	OK       bool   `json:"ok"`
	Critical bool   `json:"critical"`
	Error    string `json:"error,omitempty"`
}

func (s *Set) Readiness() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		if s.draining.Load() {
			w.WriteHeader(http.StatusServiceUnavailable)
			_, _ = w.Write([]byte(`{"status":"draining"}`))
			return
		}
		res := make([]result, len(s.checks))
		var wg sync.WaitGroup
		for i, c := range s.checks {
			wg.Add(1)
			go func(i int, c Check) {
				defer wg.Done()
				ctx, cancel := context.WithTimeout(r.Context(), s.timeout)
				defer cancel()
				err := c.Fn(ctx)
				res[i] = result{Name: c.Name, OK: err == nil, Critical: c.Critical}
				if err != nil {
					res[i].Error = "check failed" // never echo driver errors (may contain DSNs)
				}
			}(i, c)
		}
		wg.Wait()
		sort.Slice(res, func(i, j int) bool { return res[i].Name < res[j].Name })
		ready := true
		for _, x := range res {
			if x.Critical && !x.OK {
				ready = false
			}
		}
		if !ready {
			w.WriteHeader(http.StatusServiceUnavailable)
		}
		_ = json.NewEncoder(w).Encode(map[string]any{"status": map[bool]string{true: "ready", false: "not_ready"}[ready], "checks": res})
	})
}
