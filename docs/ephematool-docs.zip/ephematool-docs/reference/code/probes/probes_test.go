package probes

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func get(h http.Handler) (int, string) {
	w := httptest.NewRecorder()
	h.ServeHTTP(w, httptest.NewRequest("GET", "/", nil))
	return w.Code, w.Body.String()
}

func TestLivenessNeverDependsOnDeps(t *testing.T) {
	s := New(time.Second, Check{"db", func(context.Context) error { return errors.New("down") }, true})
	if c, _ := get(s.Liveness()); c != 200 {
		t.Fatal(c)
	}
}

func TestReadinessCriticalVsNonCritical(t *testing.T) {
	bad := func(context.Context) error { return errors.New("dsn=postgres://u:pw@h/db refused") }
	ok := func(context.Context) error { return nil }
	s := New(time.Second, Check{"db", ok, true}, Check{"tempo", bad, false})
	c, body := get(s.Readiness())
	if c != 200 || !strings.Contains(body, `"ready"`) {
		t.Fatal(c, body)
	}
	if strings.Contains(body, "postgres://") || strings.Contains(body, "pw") {
		t.Fatal("driver error leaked: " + body)
	}
	s = New(time.Second, Check{"db", bad, true})
	if c, _ := get(s.Readiness()); c != 503 {
		t.Fatal(c)
	}
}

func TestSlowCheckTimesOutAndDrainFlipsReadiness(t *testing.T) {
	slow := func(ctx context.Context) error { <-ctx.Done(); return ctx.Err() }
	s := New(50*time.Millisecond, Check{"redis", slow, true})
	start := time.Now()
	if c, _ := get(s.Readiness()); c != 503 || time.Since(start) > time.Second {
		t.Fatal("slow check must fail fast", c, time.Since(start))
	}
	s = New(time.Second, Check{"x", func(context.Context) error { return nil }, true})
	s.Drain()
	if c, _ := get(s.Readiness()); c != 503 {
		t.Fatal("draining must be 503", c)
	}
}
