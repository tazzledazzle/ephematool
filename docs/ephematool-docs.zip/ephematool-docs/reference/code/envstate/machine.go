// Package envstate is the single source of truth for the environment lifecycle.
// Rule (pitfall: three sources of truth): every state change goes through Advance, which does a
// compare-and-set on the stored state, so two workers, a webhook and the reaper can race safely.
package envstate

import (
	"context"
	"errors"
	"fmt"
)

type State string

const (
	Requested    State = "requested"
	Provisioning State = "provisioning"
	Running      State = "running"
	Failed       State = "failed"
	Destroying   State = "destroying"
	Destroyed    State = "destroyed"
)

// edges is forward-only. failed -> destroying lets an SRE (or the reaper) clean up a failed env.
var edges = map[State][]State{
	Requested:    {Provisioning, Failed, Destroying},
	Provisioning: {Running, Failed, Destroying},
	Running:      {Destroying},
	Failed:       {Destroying},
	Destroying:   {Destroyed},
	Destroyed:    {},
}

var (
	ErrIllegalTransition = errors.New("envstate: illegal transition")
	// ErrLostRace means someone else already moved the environment; callers re-read and decide, they never retry blindly.
	ErrLostRace = errors.New("envstate: state changed concurrently")
)

func CanTransition(from, to State) bool {
	for _, t := range edges[from] {
		if t == to {
			return true
		}
	}
	return false
}

func IsTerminal(s State) bool { return len(edges[s]) == 0 }

// Valid reports whether s is one of the six known states (use before trusting a DB value).
func Valid(s State) bool { _, ok := edges[s]; return ok }

// Patch carries columns that must change in the SAME statement as the state (CHECK constraints tie them
// together: state='running' requires url). Zero values mean "leave unchanged".
type Patch struct {
	URL           string
	FailureReason string
	RunID         int64
}

// Store abstracts the DB. The production implementation runs, in ONE transaction:
//
//	UPDATE environments SET state=$3, state_version=state_version+1, updated_at=now(),
//	       url=COALESCE($4,url), failure_reason=COALESCE($5,failure_reason), run_id=COALESCE($6,run_id)
//	 WHERE id=$1 AND state=$2;                -- rows==0 => ErrLostRace
//	INSERT INTO audit_events(env_id, actor, action, from_state, to_state, reason) VALUES (...);
type Store interface {
	CAS(ctx context.Context, id string, from, to State, actor, reason string, p Patch) (won bool, err error)
}

// Advance validates the edge, then CASes. It is idempotent for the caller: if the row already
// moved to `to`, the caller sees ErrLostRace and can treat it as success by re-reading.
func Advance(ctx context.Context, s Store, id string, from, to State, actor, reason string, p Patch) error {
	if !Valid(from) || !Valid(to) || !CanTransition(from, to) {
		return fmt.Errorf("%w: %s -> %s", ErrIllegalTransition, from, to)
	}
	if to == Running && p.URL == "" {
		return fmt.Errorf("%w: running requires a URL", ErrIllegalTransition)
	}
	won, err := s.CAS(ctx, id, from, to, actor, reason, p)
	if err != nil {
		return err
	}
	if !won {
		return ErrLostRace
	}
	return nil
}
