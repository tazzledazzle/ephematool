module github.com/tazzledazzle/ephematool/specs

go 1.24
