package webhook

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"
)

func sign(secret, body string) string {
	m := hmac.New(sha256.New, []byte(secret))
	m.Write([]byte(body))
	return "sha256=" + hex.EncodeToString(m.Sum(nil))
}

func TestVerify(t *testing.T) {
	good := sign("s3cret", `{"a":1}`)
	if err := Verify([]byte("s3cret"), []byte(`{"a":1}`), good); err != nil {
		t.Fatal(err)
	}
	for name, h := range map[string]string{"missing": "", "wrong secret": sign("other", `{"a":1}`), "tampered": good[:len(good)-1] + "0", "no prefix": strings.TrimPrefix(good, "sha256="), "not hex": "sha256=zz"} {
		if err := Verify([]byte("s3cret"), []byte(`{"a":1}`), h); err == nil {
			t.Errorf("%s accepted", name)
		}
	}
}

func post(h http.Handler, body, sig, event, id string) int {
	r := httptest.NewRequest(http.MethodPost, "/webhooks/github", strings.NewReader(body))
	r.Header.Set("X-Hub-Signature-256", sig)
	r.Header.Set("X-GitHub-Event", event)
	r.Header.Set("X-GitHub-Delivery", id)
	w := httptest.NewRecorder()
	h.ServeHTTP(w, r)
	return w.Code
}

func TestHandlerAuthDedupeAndAllowlist(t *testing.T) {
	var got []string
	h := Handler([]byte("k"), NewMemDedupe(time.Hour), map[string]bool{"pull_request": true, "workflow_run": true},
		func(e, id string, _ []byte) error { got = append(got, e+":"+id); return nil })
	body := `{"action":"closed"}`
	if c := post(h, body, "sha256=00", "pull_request", "d1"); c != 401 {
		t.Fatalf("bad sig => %d", c)
	}
	if c := post(h, body, sign("k", body), "pull_request", "d1"); c != 202 {
		t.Fatal(c)
	}
	if c := post(h, body, sign("k", body), "pull_request", "d1"); c != 202 { // replay: accepted, not re-enqueued
		t.Fatal(c)
	}
	if c := post(h, body, sign("k", body), "star", "d2"); c != 202 { // unknown event ignored
		t.Fatal(c)
	}
	if len(got) != 1 || got[0] != "pull_request:d1" {
		t.Fatalf("enqueued %v", got)
	}
}

func TestHandlerRejectsOversizeAndWrongMethod(t *testing.T) {
	h := Handler([]byte("k"), NewMemDedupe(time.Hour), map[string]bool{"push": true}, func(string, string, []byte) error { return nil })
	if c := post(h, strings.Repeat("x", MaxBody+1), "sha256=00", "push", "d"); c != http.StatusRequestEntityTooLarge {
		t.Fatalf("oversize => %d", c)
	}
	r := httptest.NewRequest(http.MethodGet, "/", nil)
	w := httptest.NewRecorder()
	h.ServeHTTP(w, r)
	if w.Code != 405 {
		t.Fatal(w.Code)
	}
}
