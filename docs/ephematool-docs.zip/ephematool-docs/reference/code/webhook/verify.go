// Package webhook verifies GitHub webhook deliveries. Webhooks are an OPTIMISATION (pitfall: webhook
// unreliability): the reconciler in SPEC-02 §P3.2 converges state even if every delivery is lost, so this
// handler must be cheap, authenticated, replay-safe, and must never be the only path to a state change.
package webhook

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"io"
	"net/http"
	"strings"
	"sync"
	"time"
)

const MaxBody = 1 << 20 // 1 MiB; GitHub caps payloads at 25 MiB but we only accept the events we use

var (
	ErrNoSignature  = errors.New("webhook: missing X-Hub-Signature-256")
	ErrBadSignature = errors.New("webhook: signature mismatch")
)

// Verify checks "sha256=<hex>" against HMAC-SHA256(secret, body) in constant time.
func Verify(secret, body []byte, header string) error {
	if header == "" {
		return ErrNoSignature
	}
	hexsig, ok := strings.CutPrefix(header, "sha256=")
	if !ok {
		return ErrBadSignature
	}
	got, err := hex.DecodeString(hexsig)
	if err != nil {
		return ErrBadSignature
	}
	m := hmac.New(sha256.New, secret)
	m.Write(body)
	if !hmac.Equal(got, m.Sum(nil)) {
		return ErrBadSignature
	}
	return nil
}

// Dedupe remembers delivery ids (X-GitHub-Delivery). Production: Redis SET NX with TTL 24h.
type Dedupe interface{ FirstSeen(id string) bool }

type MemDedupe struct {
	mu  sync.Mutex
	ids map[string]time.Time
	ttl time.Duration
	now func() time.Time
}

func NewMemDedupe(ttl time.Duration) *MemDedupe {
	return &MemDedupe{ids: map[string]time.Time{}, ttl: ttl, now: time.Now}
}

func (d *MemDedupe) FirstSeen(id string) bool {
	d.mu.Lock()
	defer d.mu.Unlock()
	now := d.now()
	for k, t := range d.ids {
		if now.Sub(t) > d.ttl {
			delete(d.ids, k)
		}
	}
	if _, dup := d.ids[id]; dup {
		return false
	}
	d.ids[id] = now
	return true
}

// Handler returns 401 for bad signatures, 202 for accepted (including duplicates, so GitHub stops retrying),
// and hands (event, deliveryID, body) to enqueue which must be fast (push to asynq, don't process inline).
func Handler(secret []byte, dd Dedupe, allowed map[string]bool, enqueue func(event, delivery string, body []byte) error) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
			return
		}
		body, err := io.ReadAll(http.MaxBytesReader(w, r.Body, MaxBody))
		if err != nil {
			http.Error(w, "payload too large", http.StatusRequestEntityTooLarge)
			return
		}
		if err := Verify(secret, body, r.Header.Get("X-Hub-Signature-256")); err != nil {
			http.Error(w, "unauthorized", http.StatusUnauthorized)
			return
		}
		event, id := r.Header.Get("X-GitHub-Event"), r.Header.Get("X-GitHub-Delivery")
		if !allowed[event] || id == "" {
			w.WriteHeader(http.StatusAccepted) // ignore events we do not use; do not leak the allowlist
			return
		}
		if dd.FirstSeen(id) {
			if err := enqueue(event, id, body); err != nil {
				http.Error(w, "retry", http.StatusServiceUnavailable) // GitHub redelivers manually; reconciler is the backstop
				return
			}
		}
		w.WriteHeader(http.StatusAccepted)
	})
}
