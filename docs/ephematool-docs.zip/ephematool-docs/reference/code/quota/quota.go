// Package quota implements GRD-02/GRD-03: bounded concurrent environments per user, repo and team, with an
// explanation of WHY a request was rejected. The decision is pure; atomicity comes from the DB:
//
//	BEGIN;
//	SELECT pg_advisory_xact_lock(hashtextextended($scope_key, 0));   -- one lock per scope, per team AND per repo (take in sorted order: no deadlocks)
//	SELECT count(*) FROM environments WHERE <scope> AND state NOT IN ('failed','destroyed');
//	-- decide in Go using Decide(); on allow:
//	INSERT INTO environments (...);  INSERT INTO audit_events (...);
//	COMMIT;                                                            -- lock released
//
// Racing creates therefore serialise on the lock; the loser sees the winner's row and is rejected.
package quota

import (
	"sort"
	"time"
)

type Scope string

const (
	ScopeUser Scope = "user"
	ScopeRepo Scope = "repo"
	ScopeTeam Scope = "team"
)

type Limit struct {
	Scope Scope
	Key   string // login, "org/repo" or "org/team"
	Max   int
}

type Active struct {
	ID        string
	ExpiresAt time.Time
}

type Rejection struct {
	Scope    Scope      `json:"scope"`
	Key      string     `json:"key"`
	Limit    int        `json:"limit"`
	Active   int        `json:"active"`
	Existing []Existing `json:"existing"`
	// RetryAfter is when the soonest existing environment expires (a hint, not a promise).
	RetryAfter time.Duration `json:"retry_after_seconds"`
}

type Existing struct {
	ID        string        `json:"id"`
	ExpiresIn time.Duration `json:"expires_in_seconds"`
}

// Decide returns nil when allowed, otherwise the FIRST scope (user, repo, team order) that is full.
func Decide(now time.Time, limits []Limit, activeByScopeKey map[Scope]map[string][]Active) *Rejection {
	order := map[Scope]int{ScopeUser: 0, ScopeRepo: 1, ScopeTeam: 2}
	ls := append([]Limit(nil), limits...)
	sort.SliceStable(ls, func(i, j int) bool { return order[ls[i].Scope] < order[ls[j].Scope] })
	for _, l := range ls {
		act := activeByScopeKey[l.Scope][l.Key]
		if l.Max > 0 && len(act) < l.Max {
			continue
		}
		if l.Max == 0 { // 0 means "no limit configured" for that scope
			continue
		}
		r := &Rejection{Scope: l.Scope, Key: l.Key, Limit: l.Max, Active: len(act)}
		sort.Slice(act, func(i, j int) bool { return act[i].ExpiresAt.Before(act[j].ExpiresAt) })
		for _, a := range act {
			r.Existing = append(r.Existing, Existing{ID: a.ID, ExpiresIn: max0(a.ExpiresAt.Sub(now))})
		}
		if len(act) > 0 {
			r.RetryAfter = max0(act[0].ExpiresAt.Sub(now))
		}
		return r
	}
	return nil
}

// LockKeys returns advisory-lock keys in a stable order so concurrent creates cannot deadlock.
func LockKeys(limits []Limit) []string {
	keys := make([]string, 0, len(limits))
	for _, l := range limits {
		keys = append(keys, string(l.Scope)+":"+l.Key)
	}
	sort.Strings(keys)
	return keys
}

func max0(d time.Duration) time.Duration {
	if d < 0 {
		return 0
	}
	return d
}
