package quota

import (
	"testing"
	"time"
)

var now = time.Date(2026, 1, 1, 12, 0, 0, 0, time.UTC)

func act(ids ...string) []Active {
	out := []Active{}
	for i, id := range ids {
		out = append(out, Active{ID: id, ExpiresAt: now.Add(time.Duration(i+1) * time.Hour)})
	}
	return out
}

func TestAllowedWhenUnderEveryLimit(t *testing.T) {
	l := []Limit{{ScopeUser, "ann", 3}, {ScopeRepo, "o/r", 5}}
	a := map[Scope]map[string][]Active{ScopeUser: {"ann": act("a")}, ScopeRepo: {"o/r": act("a", "b")}}
	if r := Decide(now, l, a); r != nil {
		t.Fatalf("unexpected rejection %+v", r)
	}
}

func TestRejectionExplainsWhyAndWhen(t *testing.T) {
	l := []Limit{{ScopeUser, "ann", 2}}
	a := map[Scope]map[string][]Active{ScopeUser: {"ann": act("b", "a")}}
	r := Decide(now, l, a)
	if r == nil || r.Limit != 2 || r.Active != 2 || len(r.Existing) != 2 || r.RetryAfter != time.Hour {
		t.Fatalf("%+v", r)
	}
	if r.Existing[0].ID != "b" { // soonest expiry first
		t.Fatalf("order: %+v", r.Existing)
	}
}

func TestFirstFullScopeWinsAndZeroMeansUnlimited(t *testing.T) {
	l := []Limit{{ScopeTeam, "o/t", 1}, {ScopeUser, "ann", 0}, {ScopeRepo, "o/r", 1}}
	a := map[Scope]map[string][]Active{ScopeUser: {"ann": act("a", "b", "c")}, ScopeRepo: {"o/r": act("x")}, ScopeTeam: {"o/t": act("x")}}
	if r := Decide(now, l, a); r == nil || r.Scope != ScopeRepo {
		t.Fatalf("want repo scope first, got %+v", r)
	}
}

func TestLockKeysAreSorted(t *testing.T) {
	k := LockKeys([]Limit{{ScopeTeam, "z", 1}, {ScopeRepo, "a", 1}, {ScopeUser, "m", 1}})
	if k[0] != "repo:a" || k[1] != "team:z" || k[2] != "user:m" {
		t.Fatal(k)
	}
}

func TestExpiredEntriesNeverProduceNegativeHints(t *testing.T) {
	a := map[Scope]map[string][]Active{ScopeUser: {"ann": {{ID: "old", ExpiresAt: now.Add(-time.Hour)}}}}
	r := Decide(now, []Limit{{ScopeUser, "ann", 1}}, a)
	if r == nil || r.RetryAfter != 0 {
		t.Fatalf("%+v", r)
	}
}
