-- Idempotent runtime grants. Run as the OWNER role after every migration (Helm post-upgrade hook / `api grant`).
-- The runtime role must exist already; \set app_role ephematool_app  (override with psql -v app_role=...)
\if :{?app_role}
\else
\set app_role ephematool_app
\endif
GRANT USAGE ON SCHEMA public TO :"app_role";
GRANT SELECT, INSERT, UPDATE ON environments TO :"app_role";      -- no DELETE: environments are tombstoned
GRANT SELECT, INSERT ON audit_events TO :"app_role";             -- no UPDATE/DELETE/TRUNCATE (triggers enforce it for everyone)
GRANT USAGE ON SEQUENCE audit_events_seq_seq TO :"app_role";
