"""Phase 1: GitHub OAuth login, allowlist, session handling (AUTH-*)."""
import pytest
from ephematest.clients import ApiClient, LoginDenied

pytestmark = pytest.mark.phase(1)


def test_auth_config_is_public(anon):
    r = anon.get("/api/auth/config")
    assert r.status == 200 and isinstance(r.body, dict)


def test_me_requires_session(anon):
    assert anon.get("/api/me").status == 401


def test_admin_login_and_role(admin, settings):
    r = admin.get("/api/me")
    assert r.status == 200
    assert r.body["login"] == settings.admin_login and r.body["role"] == "admin"


def test_viewer_role(viewer):
    assert viewer.get("/api/me").body["role"] == "viewer"


def test_non_member_is_denied_without_session(outsider_login):
    assert outsider_login.session_cookie == ""
    assert outsider_login.get("/api/me").status == 401


def test_session_cookie_flags(settings):
    c = ApiClient(settings)
    r = c.get("/api/auth/github/login")
    loc = r.headers["location"]
    import requests, urllib.parse
    r2 = requests.get(f"{loc}&login={settings.admin_login}", allow_redirects=False, timeout=10)
    cb = urllib.parse.urlsplit(r2.headers["location"])
    r3 = c.get(cb.path + "?" + cb.query)
    sc = r3.headers.get("set-cookie", "").lower()
    assert "httponly" in sc, sc
    assert "samesite" in sc, sc
    assert "path=/" in sc, sc


def test_callback_rejects_unknown_state(anon):
    assert anon.get("/api/auth/github/callback?code=octo-admin&state=forged").status in (400, 401, 403)


@pytest.mark.fault("open_redirect")
@pytest.mark.parametrize("evil", ["https://evil.example/x", "//evil.example/x", "/\\evil.example"])
def test_next_param_is_not_an_open_redirect(settings, evil):
    import requests, urllib.parse
    c = ApiClient(settings)
    r = c.get("/api/auth/github/login", params={"next": evil})
    loc = r.headers["location"]
    r2 = requests.get(f"{loc}&login={settings.admin_login}", allow_redirects=False, timeout=10)
    cb = urllib.parse.urlsplit(r2.headers["location"])
    r3 = c.get(cb.path + "?" + cb.query)
    dest = r3.headers.get("location", "")
    assert dest.startswith("/") and not dest.startswith("//") and "\\" not in dest, f"redirected to {dest!r}"


def test_logout_invalidates_session(settings):
    c = ApiClient(settings).login(settings.admin_login)
    assert c.get("/api/me").status == 200
    assert c.post("/api/auth/logout").status in (200, 204)
    old = c.http.cookies.get_dict().get("ephematool_session")
    c2 = ApiClient(settings)
    if old:  # replaying the old token must fail even if the cookie jar kept it
        c2.http.cookies.set("ephematool_session", old)
        assert c2.get("/api/me").status == 401
