"""Operational/resilience tests against the docker-compose stack and (Phase 2+) the kind cluster.
These need real infrastructure; they FAIL (not skip) when docker/kubectl are absent."""
import json, subprocess, time
import pytest

COMPOSE = lambda s: ["docker", "compose", "-f", f"{s.repo_root}/{s.compose_file}"]


def sh(cmd, timeout=60) -> str:
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    assert p.returncode == 0, f"{' '.join(cmd)} -> {p.stderr[:300]}"
    return p.stdout


@pytest.mark.phase(1)
@pytest.mark.requires("docker", "repo")
def test_worker_heartbeat_key_in_redis(settings):
    out = sh(COMPOSE(settings) + ["exec", "-T", "redis", "redis-cli", "EXISTS", "worker:heartbeat"])
    assert out.strip() == "1"


@pytest.mark.phase(1)
@pytest.mark.requires("docker", "repo")
def test_loki_outage_is_reflected_then_recovers(settings, admin):
    """Port of status.sh: stop loki -> Down within 25s; start -> healthy within 60s. Always restores loki."""
    def loki_status():
        return next(s["status"] for s in admin.get("/api/status").body["services"] if s["id"] == "loki")
    try:
        sh(COMPOSE(settings) + ["stop", "loki"])
        t0 = time.time()
        while loki_status() != "down" and time.time() - t0 < 25: time.sleep(1)
        assert loki_status() == "down"
    finally:
        sh(COMPOSE(settings) + ["start", "loki"])
    t0 = time.time()
    while loki_status() != "healthy" and time.time() - t0 < 60: time.sleep(2)
    assert loki_status() == "healthy"


@pytest.mark.phase(1)
@pytest.mark.requires("docker", "repo")
def test_redis_outage_degrades_not_crashes_api(settings, admin):
    try:
        sh(COMPOSE(settings) + ["stop", "redis"])
        time.sleep(3)
        assert admin.get("/api/auth/config").status == 200           # process alive, public route works
    finally:
        sh(COMPOSE(settings) + ["start", "redis"])
    time.sleep(5)
    assert admin.get("/api/status").status in (200, 401)


@pytest.mark.phase(2)
@pytest.mark.requires("docker", "repo")
def test_audit_events_db_role_cannot_update_or_delete(settings):
    base = COMPOSE(settings) + ["exec", "-T", "postgres", "psql", "-U", "ephematool_app", "-d", "ephematool", "-tAc"]
    for stmt in ("UPDATE audit_events SET actor='x'", "DELETE FROM audit_events"):
        p = subprocess.run(base + [stmt], capture_output=True, text=True, timeout=30)
        assert p.returncode != 0 or "permission denied" in p.stderr.lower() or "append-only" in (p.stderr + p.stdout).lower(), \
            f"{stmt!r} succeeded for the app role"


@pytest.mark.phase(2)
@pytest.mark.requires("kubectl")
def test_preview_namespaces_have_quota_limitrange_networkpolicy(admin):
    env = admin.create_env().body
    done = admin.wait_state(env["id"], {"running", "failed"}, timeout=600)
    assert done["state"] == "running"
    ns = json.loads(sh(["kubectl", "get", "ns", "-l", f"ephematool.io/env-id={env['id']}", "-o", "json"]))["items"]
    assert len(ns) == 1, "exactly one namespace per environment"
    name = ns[0]["metadata"]["name"]
    for kind in ("resourcequota", "limitrange", "networkpolicy"):
        items = json.loads(sh(["kubectl", "-n", name, "get", kind, "-o", "json"]))["items"]
        assert items, f"namespace {name} has no {kind}"
    labels = ns[0]["metadata"]["labels"]
    assert labels.get("ephematool.io/owner") and labels.get("ephematool.io/expires-at")


@pytest.mark.phase(4)
@pytest.mark.requires("kubectl")
def test_destroy_leaves_no_orphan_namespace(admin):
    env = admin.create_env().body
    admin.wait_state(env["id"], {"running"}, timeout=600)
    admin.delete(f"/api/environments/{env['id']}")
    admin.wait_state(env["id"], {"destroyed"}, timeout=300)
    out = sh(["kubectl", "get", "ns", "-l", f"ephematool.io/env-id={env['id']}", "-o", "name"])
    assert out.strip() == "", f"orphan namespace remains: {out}"


@pytest.mark.phase(5)
@pytest.mark.requires("kubectl")
def test_reconciler_finds_no_cluster_orphans(admin):
    """Every labelled namespace must map to a non-terminal environment (drift/orphan check, pitfall #1)."""
    ns = sh(["kubectl", "get", "ns", "-l", "ephematool.io/env-id", "-o", "jsonpath={range .items[*]}{.metadata.labels.ephematool\\.io/env-id}{\"\\n\"}{end}"]).split()
    for env_id in ns:
        r = admin.get(f"/api/environments/{env_id}")
        assert r.status == 200 and r.body["state"] not in ("destroyed",), f"orphan namespace for env {env_id}"


@pytest.mark.phase(7)
@pytest.mark.requires("docker", "repo")
def test_restart_during_provisioning_still_converges(settings, admin):
    env = admin.create_env().body
    sh(COMPOSE(settings) + ["restart", "worker"])
    done = admin.wait_state(env["id"], {"running", "failed"}, timeout=600)
    assert done["state"] in ("running", "failed"), "environment stuck after worker restart (reaper/CAS recovery broken)"
