"""Concurrency + light load: races on quota and TTL, and request-latency budget."""
import concurrent.futures as cf
import statistics
import pytest
from ephematest.clients import ApiClient


@pytest.mark.quota
@pytest.mark.phase(7)
@pytest.mark.fault("quota_off")
def test_parallel_creates_cannot_exceed_quota(settings):
    """Quota must be atomic (Phase 7 hardening): N parallel creates never yield more than max_per_user."""
    c = ApiClient(settings).login(settings.admin_login)
    base = sum(1 for e in c.get("/api/environments").body["environments"]
               if e["owner"] == c.login_name and e["state"] not in ("failed", "destroyed"))
    n = settings.max_per_user + 5
    with cf.ThreadPoolExecutor(n) as ex:
        res = list(ex.map(lambda _: c.create_env().status, range(n)))
    accepted = res.count(202)
    assert accepted <= max(settings.max_per_user - base, 0) + 0, f"{accepted} accepted with {base} already active: {res}"


@pytest.mark.phase(1)
def test_status_endpoint_latency_budget(admin):
    lat = sorted(admin.get("/api/status").elapsed for _ in range(30))
    assert statistics.median(lat) < 1.0 and lat[int(len(lat) * 0.95)] < 2.5, f"p50={lat[15]:.3f}s p95={lat[28]:.3f}s"


@pytest.mark.phase(1)
def test_session_isolation_under_parallel_logins(settings):
    def who(login):
        c = ApiClient(settings).login(login)
        return c.get("/api/me").body["login"]
    logins = [settings.admin_login, settings.viewer_login] * 8
    with cf.ThreadPoolExecutor(8) as ex:
        assert list(ex.map(who, logins)) == logins
