"""Phases 3-7 (numbering = .planning/ROADMAP.md): 3 inventory/destroy/orphans, 4 health+drift, 5 TTL/extend,
6 per-env telemetry links, 7 quota + secrets guardrails + hardening."""
import time
import pytest
from ephematest.clients import ApiClient


# ---- Phase 4: live health + drift --------------------------------------------------
@pytest.mark.phase(4)
def test_health_reports_probe_and_workflow_signals(admin):
    env = admin.create_env().body
    admin.wait_state(env["id"], {"running"})
    h = admin.get(f"/api/environments/{env['id']}/health")
    assert h.status == 200 and h.body["healthy"] is True and {"workflow", "probe"} <= set(h.body["signals"])


@pytest.mark.phase(4)
def test_failed_env_is_never_reported_healthy(admin):
    env = admin.create_env(values={"fail": True}).body
    admin.wait_state(env["id"], {"failed"})
    assert admin.get(f"/api/environments/{env['id']}/health").body["healthy"] is False


# ---- Phase 3: inventory, destroy, orphans -------------------------------------------------------
@pytest.mark.phase(3)
def test_list_filters_and_pagination(admin):
    for _ in range(2): admin.create_env(values={"fail": True})
    time.sleep(1.0)
    r = admin.get("/api/environments", params={"state": "failed", "limit": 1})
    assert r.status == 200 and len(r.body["environments"]) == 1 and r.body["next_cursor"]
    nxt = admin.get("/api/environments", params={"state": "failed", "limit": 1, "cursor": r.body["next_cursor"]})
    assert nxt.body["environments"][0]["id"] != r.body["environments"][0]["id"]
    assert all(e["state"] == "failed" for e in r.body["environments"] + nxt.body["environments"])


@pytest.mark.phase(3)
def test_orphans_endpoint_is_admin_only_and_well_formed(admin, viewer, anon):
    assert anon.get("/api/orphans").status == 401
    assert viewer.get("/api/orphans").status == 403
    r = admin.get("/api/orphans")
    assert r.status == 200 and isinstance(r.body["orphans"], list)


@pytest.mark.phase(3)
def test_destroy_reaches_destroyed_and_is_audited(admin):
    env = admin.create_env().body
    admin.wait_state(env["id"], {"running"})
    assert admin.delete(f"/api/environments/{env['id']}").status == 202
    admin.wait_state(env["id"], {"destroyed"})
    acts = [e["action"] for e in admin.get(f"/api/environments/{env['id']}/events").body["events"]]
    assert "destroy.request" in acts and "destroy.ok" in acts


@pytest.mark.phase(3)
def test_destroy_is_idempotent(admin):
    env = admin.create_env().body
    admin.wait_state(env["id"], {"running"})
    assert admin.delete(f"/api/environments/{env['id']}").status == 202
    assert admin.delete(f"/api/environments/{env['id']}").status in (200, 202, 404, 409)


@pytest.mark.phase(3)
@pytest.mark.fault("delete_any")
def test_viewer_cannot_destroy_someone_elses_env(admin, viewer):
    env = admin.create_env().body
    assert viewer.delete(f"/api/environments/{env['id']}").status in (403, 404)


# ---- Phase 5: TTL, extension, auto-teardown ------------------------------------------------------
@pytest.mark.phase(5)
def test_extend_ttl_and_cap(admin, settings):
    env = admin.create_env(ttl_seconds=600).body
    r = admin.post(f"/api/environments/{env['id']}/extend", json={"ttl_seconds": 300})
    assert r.status == 200 and r.body["ttl_seconds"] == 900
    assert admin.post(f"/api/environments/{env['id']}/extend", json={"ttl_seconds": settings.max_ttl}).status == 422
    assert admin.post(f"/api/environments/{env['id']}/extend", json={"ttl_seconds": -1}).status == 422


@pytest.mark.phase(5)
@pytest.mark.fault("ttl_ignored")
def test_ttl_expiry_destroys_environment(admin):
    env = admin.create_env(ttl_seconds=2).body
    done = admin.wait_state(env["id"], {"destroyed"}, timeout=20)
    acts = [e["action"] for e in admin.get(f"/api/environments/{env['id']}/events").body["events"]]
    assert "ttl.expired" in acts and done["state"] == "destroyed"


@pytest.mark.phase(5)
def test_extend_before_expiry_prevents_destroy(admin):
    env = admin.create_env(ttl_seconds=2).body
    admin.wait_state(env["id"], {"running"})
    assert admin.post(f"/api/environments/{env['id']}/extend", json={"ttl_seconds": 600}).status == 200
    time.sleep(3)
    assert admin.get(f"/api/environments/{env['id']}").body["state"] == "running"


# ---- Phase 6: observability deep links ------------------------------------------------------
@pytest.mark.phase(6)
def test_environment_links_to_grafana_and_traces(admin):
    env = admin.create_env().body
    r = admin.get(f"/api/environments/{env['id']}/links")
    assert r.status == 200 and env["id"] in r.body["grafana"] and "traces" in r.body


# ---- Phase 7: hardening ---------------------------------------------------------------------
@pytest.mark.phase(7)
@pytest.mark.fault("no_security_headers")
def test_security_headers_present(admin):
    h = admin.get("/api/me").headers
    assert h.get("x-content-type-options") == "nosniff"
    assert h.get("x-frame-options") in ("DENY", "SAMEORIGIN")
    assert "no-store" in h.get("cache-control", "")


@pytest.mark.phase(7)
def test_secret_by_reference_is_accepted_and_value_never_returned(admin):
    r = admin.create_env(values={"db": {"secretRef": "sampleapp-db"}})
    assert r.status == 202, r.text
    assert "secretRef" in r.text and "password" not in r.text.lower()


@pytest.mark.phase(7)
def test_out_of_scope_secret_reference_refused(admin):
    assert admin.create_env(values={"db": {"secretRef": "prod-database-root"}}).status in (403, 422)


@pytest.mark.quota
@pytest.mark.phase(7)
def test_quota_rejection_explains_remaining_quota(settings):
    """GRD-03 success criterion 2: the rejection body says why (limit, active, soonest expiry)."""
    c = ApiClient(settings).login(settings.admin_login)
    r = None
    for _ in range(settings.max_per_user + 2):
        r = c.create_env()
        if r.status == 429: break
    assert r.status == 429 and {"limit", "active"} <= set(r.body), r.text
