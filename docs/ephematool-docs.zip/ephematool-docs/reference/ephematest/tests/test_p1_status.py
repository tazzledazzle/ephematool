"""Phase 1: /api/status contract (10 services, order, trace header) and health endpoints."""
import pytest

pytestmark = pytest.mark.phase(1)
WANT = ["api", "worker", "dashboard", "postgres", "redis", "otel-collector", "tempo", "loki", "prometheus", "grafana"]
ALLOWED = {"healthy", "degraded", "down", "unknown"}


def test_status_requires_session(anon):
    assert anon.get("/api/status").status == 401


@pytest.mark.fault("status_wrong_order")
def test_status_ten_services_in_contract_order(admin):
    r = admin.get("/api/status")
    assert r.status == 200
    ids = [s["id"] for s in r.body["services"]]
    assert ids == WANT


def test_status_values_are_from_the_vocabulary(admin):
    for s in admin.get("/api/status").body["services"]:
        assert s["status"] in ALLOWED and "detail" in s


@pytest.mark.fault("no_trace_header")
def test_every_api_response_carries_x_trace_id(admin, anon):
    for r in (admin.get("/api/status"), admin.get("/api/me"), anon.get("/api/me"), anon.get("/api/auth/config")):
        assert len(r.trace_id) == 32 and int(r.trace_id, 16) >= 0, f"bad trace id {r.trace_id!r}"


def test_trace_ids_are_unique(admin):
    assert len({admin.get("/api/me").trace_id for _ in range(5)}) == 5


@pytest.mark.phase(1)
def test_unknown_route_is_json_404(admin):
    r = admin.get("/api/definitely-not-a-route")
    assert r.status == 404


@pytest.mark.phase(7)
def test_health_and_readiness_endpoints(anon):
    assert anon.get("/healthz").status == 200
    assert anon.get("/readyz").status == 200
