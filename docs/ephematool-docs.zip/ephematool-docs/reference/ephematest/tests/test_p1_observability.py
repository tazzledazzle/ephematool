"""Phase 1: OTel-first - one request yields trace, log and metric (OBS-*). Needs Tempo/Loki/Prom."""
import re
import pytest

pytestmark = [pytest.mark.phase(1), pytest.mark.requires("obs")]


def test_trace_contains_api_service(admin, obs):
    tid = admin.get("/api/status").trace_id
    svcs = obs.poll(lambda: obs.tempo_services(tid), lambda s: "ephematool-api" in s)
    assert "ephematool-api" in svcs, svcs


def test_trace_spans_api_and_worker(admin, obs):
    svcs = set()
    for _ in range(3):                      # PING_THROTTLE may skip the enqueue
        tid = admin.get("/api/status").trace_id
        svcs = obs.poll(lambda: obs.tempo_services(tid), lambda s: {"ephematool-api", "ephematool-worker"} <= s, timeout=20)
        if "ephematool-worker" in svcs: break
    assert {"ephematool-api", "ephematool-worker"} <= svcs, svcs


def test_logs_correlate_by_trace_id(admin, obs):
    tid = admin.get("/api/status").trace_id
    lines = obs.poll(lambda: obs.loki_lines(f'{{service_name="ephematool-api"}} | trace_id="{tid}"'), bool)
    assert lines, f"no loki lines for trace {tid}"


def test_http_server_duration_metric_exists(admin, obs):
    admin.get("/api/status")
    v = obs.poll(lambda: obs.prom_value('sum(http_server_request_duration_seconds_count{service_name="ephematool-api",http_route="/api/status"})'),
                 lambda v: v is not None and v > 0)
    assert v and v > 0


def test_worker_task_counter(admin, obs):
    admin.get("/api/status")
    v = obs.poll(lambda: obs.prom_value('sum(ephematool_queue_task_processed_total{service_name="ephematool-worker"})'),
                 lambda v: v is not None and v > 0)
    assert v and v > 0


def test_auth_denied_is_logged(outsider_login, obs, settings):
    lines = obs.poll(lambda: obs.loki_lines(f'{{service_name="ephematool-api"}} |= "auth.denied" | login="{settings.outsider_login}"'), bool)
    assert lines, "no auth.denied line for the outsider"


@pytest.mark.fault("leak_secret")
def test_no_secret_material_in_traces_or_logs(admin, obs, settings):
    """Mirror of scripts/verify.d/redaction.sh: cookie value, auth headers, client secret never stored."""
    tids = [admin.get(p).trace_id for p in ("/api/status", "/api/me")]
    cookie = admin.session_cookie
    assert cookie
    needles = [cookie, "ephematool_session=", "Bearer ", "access_token=", '"access_token"',
               "http.request.header.cookie", "http.response.header.set-cookie", "http.request.header.authorization",
               *settings.secret_needles]
    corpus = ""
    for t in tids:
        raw = obs.poll(lambda t=t: obs.tempo_raw(t), bool)
        assert raw, f"trace {t} never reached Tempo"
        corpus += raw
    corpus += "\n".join(obs.loki_lines('{service_namespace="ephematool"}', 900, 5000))
    hits = [n for n in needles if n and n.lower() in corpus.lower()]
    assert not hits, f"secret material in telemetry: {hits}"
