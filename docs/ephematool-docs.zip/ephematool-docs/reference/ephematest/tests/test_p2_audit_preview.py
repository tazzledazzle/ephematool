"""Phase 2: audit trail (append-only, admin-only) and the preview gate (ENV-09)."""
import pytest

pytestmark = pytest.mark.phase(2)


def test_audit_admin_only(anon, viewer, admin):
    assert anon.get("/api/audit").status == 401
    assert viewer.get("/api/audit").status == 403
    assert admin.get("/api/audit").status == 200


def test_create_is_audited_with_actor(admin):
    env = admin.create_env().body
    ev = [e for e in admin.get("/api/audit").body["events"] if e["env_id"] == env["id"]]
    assert ev and ev[0]["actor"] == admin.login_name and ev[0]["action"] == "env.create"


@pytest.mark.fault("audit_mutable")
@pytest.mark.parametrize("method", ["PUT", "PATCH", "DELETE", "POST"])
def test_audit_log_is_append_only(admin, method):
    admin.create_env()
    before = len(admin.get("/api/audit").body["events"])
    r = admin.request(method, "/api/audit/1", json={})
    assert r.status in (404, 405, 403), r.status
    r = admin.request(method, "/api/audit", json={})
    assert r.status in (404, 405, 403), r.status
    assert len(admin.get("/api/audit").body["events"]) >= before


def test_audit_sequence_is_gapless_and_monotonic(admin):
    seqs = [e["seq"] for e in admin.get("/api/audit").body["events"]]
    assert seqs == list(range(seqs[0], seqs[0] + len(seqs)))


def _running(admin):
    env = admin.create_env().body
    return admin.wait_state(env["id"], {"running"})


@pytest.mark.fault("preview_gate_open")
def test_preview_gate_requires_valid_env_bound_token(admin, anon, settings):
    a, b = _running(admin), _running(admin)
    tok_a = admin.post(f"/api/environments/{a['id']}/preview-link").body["token"]
    from urllib.parse import urlsplit
    host_a, host_b = urlsplit(a["url"]).hostname, urlsplit(b["url"]).hostname     # the URL the server issued
    gate = lambda host, tok=None: anon.get(settings.preview_gate_path, headers={"X-Forwarded-Host": host, **({"X-Preview-Token": tok} if tok else {})}).status
    assert gate(host_a) == 401                 # no token
    assert gate(host_a, "garbage") in (401, 403)
    assert gate(host_a, tok_a) == 200          # right token, right env
    assert gate(host_b, tok_a) in (401, 403)   # token is bound to one environment
    assert gate("ffffffff.preview.localhost", tok_a) in (401, 403, 404)


def test_preview_link_only_for_running_env(admin):
    env = admin.create_env().body
    r = admin.post(f"/api/environments/{env['id']}/preview-link")
    assert r.status in (200, 409)
