"""Phase 2: create a secure preview environment (ENV-*): validation, authz, quota, idempotency, state machine."""
import time
import pytest
from ephematest.clients import ApiClient

pytestmark = pytest.mark.phase(2)

# Forward-only graph (D-12/CAS). Terminal: failed, destroyed.
EDGES = {None: {"requested"}, "requested": {"provisioning", "failed"}, "provisioning": {"running", "failed"},
         "running": {"destroying"}, "failed": {"destroying"}, "destroying": {"destroyed"}, "destroyed": set()}


@pytest.mark.fault("no_auth_on_create")
def test_create_requires_session(anon):
    assert anon.create_env().status == 401


@pytest.mark.fault("viewer_can_create")
def test_viewer_cannot_create(viewer):
    assert viewer.create_env().status == 403


@pytest.mark.fault("allowlist_off")
def test_repo_outside_allowlist_is_forbidden(admin, settings):
    assert admin.create_env(repo=settings.denied_repo).status in (403, 422)


@pytest.mark.parametrize("patch", [
    {"template": "does-not-exist"}, {"ttl_seconds": 0}, {"ttl_seconds": -5}, {"ttl_seconds": "soon"},
    {"ttl_seconds": True}, {"values": "notanobject"}, {"repo": ""}, {"ref": None}])
def test_invalid_payloads_are_422_not_500(admin, settings, patch):
    body = {"repo": settings.allowed_repo, "ref": settings.ref, "template": settings.template, **patch}
    r = admin.post("/api/environments", json=body)
    assert r.status in (400, 422), f"{patch} -> {r.status} {r.text[:120]}"


def test_malformed_json_is_400(admin):
    r = admin.post("/api/environments", data="{not json", headers={"Content-Type": "application/json"})
    assert r.status in (400, 422)


@pytest.mark.fault("no_ttl_cap")
def test_ttl_above_maximum_rejected(admin, settings):
    assert admin.create_env(ttl_seconds=settings.max_ttl + 1).status == 422


def test_create_returns_202_with_location_and_requested_state(admin):
    r = admin.create_env()
    assert r.status == 202, r.text
    assert r.body["state"] == "requested" and r.body["owner"] == admin.login_name
    assert r.headers.get("location", "").endswith(r.body["id"])
    assert r.trace_id


def test_environment_id_is_server_generated_dns_label(admin, settings):
    import re
    env = admin.create_env().body
    assert re.match(settings.env_id_pattern, env["id"]), env["id"]
    assert settings.ref not in env["id"], "id must never be branch-derived (D-03)"


def test_environment_reaches_running_with_url(admin, settings):
    env = admin.create_env().body
    done = admin.wait_state(env["id"], {"running", "failed"})
    assert done["state"] == "running", done
    assert done["url"] and done["ttl_expires_at"]


def test_failed_provision_is_terminal_and_visible(admin):
    env = admin.create_env(values={"fail": True}).body
    done = admin.wait_state(env["id"], {"failed", "running"})
    assert done["state"] == "failed"


@pytest.mark.fault("regress_state")
def test_events_follow_forward_only_state_machine(admin):
    env = admin.create_env().body
    admin.wait_state(env["id"], {"running", "failed"})
    time.sleep(0.8)                                       # let a buggy server regress, if it will
    ev = admin.get(f"/api/environments/{env['id']}/events").body["events"]
    prev = None
    for e in ev:
        assert e["to"] in EDGES.get(e["from"], set()) or e["from"] == e["to"], f"illegal transition {e['from']}->{e['to']}"
        assert e["from"] == prev or prev is None or e["from"] is None, "event chain has a gap"
        prev = e["to"]
    assert [e["seq"] for e in ev] == sorted(e["seq"] for e in ev)


@pytest.mark.fault("idempotency_broken")
def test_idempotency_key_returns_same_environment(admin, uid):
    a = admin.create_env(idem_key=f"k-{uid}")
    b = admin.create_env(idem_key=f"k-{uid}")
    assert a.status == 202 and b.status in (200, 202)
    assert a.body["id"] == b.body["id"]


@pytest.mark.quota
@pytest.mark.fault("quota_off")
def test_per_user_quota_enforced_with_retry_after(settings):
    c = ApiClient(settings).login(settings.admin_login)
    # Other tests may already hold slots, so create until the first rejection (bounded).
    codes = []
    for _ in range(settings.max_per_user + 3):
        r = c.create_env(); codes.append(r.status)
        if r.status == 429:
            assert "retry-after" in r.headers
            break
    assert 429 in codes, f"quota never enforced: {codes}"


@pytest.mark.fault("echo_secrets")
def test_secret_values_never_echoed(admin):
    r = admin.create_env(values={"db_password": "hunter2-canary", "color": "blue"})
    assert r.status in (202, 422)
    if r.status == 202:                                    # accepted => must be redacted everywhere
        got = admin.get(f"/api/environments/{r.body['id']}")
        assert "hunter2-canary" not in r.text and "hunter2-canary" not in got.text


def test_get_unknown_environment_is_404(admin):
    assert admin.get("/api/environments/deadbeef").status == 404


def test_environment_endpoints_require_session(anon):
    assert anon.get("/api/environments").status == 401
    assert anon.get("/api/environments/deadbeef").status == 401


def test_viewer_can_read_but_list_is_consistent(admin, viewer):
    env = admin.create_env().body
    assert viewer.get(f"/api/environments/{env['id']}").status == 200
    assert env["id"] in [e["id"] for e in viewer.get("/api/environments").body["environments"]]
