"""pytest plugin: phase gating, capability checks that FAIL instead of skip, shared fixtures."""
from __future__ import annotations
import shutil
import subprocess
import uuid
from pathlib import Path

import pytest
import requests

from .clients import ApiClient, LoginDenied, Obs
from .config import SETTINGS, Settings


def pytest_addoption(parser):
    g = parser.getgroup("ephematest")
    g.addoption("--expect-phase", type=int, default=7,
                help="Highest roadmap phase believed implemented (1-7). Tests for later phases are "
                     "expected to fail (xfail); tests for <= this phase must pass.")
    g.addoption("--strict-caps", action="store_true", default=True,
                help="A test whose capability (docker/kubectl/obs/repo) is missing FAILS (default).")
    g.addoption("--allow-missing-caps", action="store_true", default=False,
                help="Downgrade missing capabilities to an explicit xfail instead of a failure.")
    g.addoption("--quota-mode", action="store_true", default=False,
                help="Run ONLY quota tests (stack must have ENV_MAX_PER_USER == EPHEMA_MAX_PER_USER, low). "
                     "Without it quota tests are deselected, because the other suites need headroom.")
    g.addoption("--repo-root", default=None, help="Path to a checkout of ephematool (enables repo tests).")
    g.addoption("--api-url", default=None)


def pytest_report_header(config):
    return [f"ephematest: expect-phase={config.getoption('--expect-phase')} quota-mode={config.getoption('--quota-mode')} "
            f"(quota tests are {'the only tests' if config.getoption('--quota-mode') else 'deselected; run again with --quota-mode'})"]


def pytest_configure(config):
    config.addinivalue_line("markers", "quota: needs a low per-user quota; run with --quota-mode")
    if config.getoption("--api-url"):
        SETTINGS.api_url = config.getoption("--api-url").rstrip("/")
    root = config.getoption("--repo-root") or SETTINGS.repo_root
    SETTINGS.repo_root = root or ""


# ---- capabilities -------------------------------------------------------------------
def _cap_docker(s: Settings) -> str | None:
    if not shutil.which("docker"): return "docker CLI not found"
    return None


def _cap_kubectl(s: Settings) -> str | None:
    if not shutil.which("kubectl"): return "kubectl not found"
    p = subprocess.run(["kubectl", "cluster-info"], capture_output=True, timeout=20)
    return None if p.returncode == 0 else "kubectl cannot reach a cluster"


def _cap_obs(s: Settings) -> str | None:
    for name, url in (("tempo", s.tempo_url + "/ready"), ("loki", s.loki_url + "/ready"), ("prometheus", s.prom_url + "/-/ready")):
        try:
            if requests.get(url, timeout=3).status_code != 200: return f"{name} not ready"
        except requests.RequestException:
            return f"{name} unreachable"
    return None


def _cap_repo(s: Settings) -> str | None:
    return None if s.repo_root and (Path(s.repo_root) / "go.mod").exists() else "no --repo-root checkout (go.mod missing)"


def _cap_db(s: Settings) -> str | None:
    return _cap_docker(s)


_CAPS = {"docker": _cap_docker, "kubectl": _cap_kubectl, "obs": _cap_obs, "repo": _cap_repo, "db": _cap_db, "redis": _cap_docker}
_cap_cache: dict[str, str | None] = {}


def pytest_collection_modifyitems(config, items):
    expect = config.getoption("--expect-phase")
    qmode = config.getoption("--quota-mode")
    drop = [i for i in items if bool(i.get_closest_marker("quota")) != qmode]
    if drop:                                   # never silent: reported in the run header
        config.hook.pytest_deselected(items=drop)
        items[:] = [i for i in items if i not in drop]
    for item in items:
        m = item.get_closest_marker("phase")
        if m and m.args[0] > expect:
            item.add_marker(pytest.mark.xfail(
                reason=f"phase {m.args[0]} not expected before phase {expect} is complete", strict=False, run=True))


@pytest.hookimpl(tryfirst=True)
def pytest_runtest_setup(item):
    """Missing capabilities are loud: fail (or explicit xfail), never a silent skip."""
    for m in item.iter_markers("requires"):
        for cap in m.args:
            if cap not in _cap_cache:
                _cap_cache[cap] = _CAPS[cap](SETTINGS)
            why = _cap_cache[cap]
            if why:
                if item.config.getoption("--allow-missing-caps"):
                    pytest.xfail(f"capability '{cap}' missing: {why}")
                pytest.fail(f"capability '{cap}' missing: {why} (use --allow-missing-caps to downgrade)", pytrace=False)


# ---- fixtures -----------------------------------------------------------------------
@pytest.fixture(scope="session")
def settings() -> Settings: return SETTINGS


@pytest.fixture(scope="session")
def obs(settings) -> Obs: return Obs(settings)


@pytest.fixture(scope="session")
def anon(settings) -> ApiClient: return ApiClient(settings)


@pytest.fixture(scope="session")
def admin(settings) -> ApiClient: return ApiClient(settings).login(settings.admin_login)


@pytest.fixture(scope="session")
def viewer(settings) -> ApiClient: return ApiClient(settings).login(settings.viewer_login)


@pytest.fixture()
def fresh_admin(settings) -> ApiClient:
    """A new session per test for tests that mutate quotas."""
    return ApiClient(settings).login(settings.admin_login)


@pytest.fixture()
def outsider_login(settings):
    c = ApiClient(settings)
    with pytest.raises(LoginDenied):
        c.login(settings.outsider_login)
    return c


@pytest.fixture()
def uid() -> str: return uuid.uuid4().hex[:8]


@pytest.fixture()
def created_env(admin):
    """Create an environment, hand back its body, best-effort cleanup via DELETE (Phase 4+)."""
    r = admin.create_env()
    assert r.status in (200, 201, 202), f"create failed {r.status} {r.text[:200]}"
    env = r.body
    yield env
    admin.delete(f"/api/environments/{env['id']}")
