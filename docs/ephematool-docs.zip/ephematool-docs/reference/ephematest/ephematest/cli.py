"""`ephematest` entry point: thin wrapper around pytest with friendly defaults."""
from __future__ import annotations
import sys
import pytest


def main() -> None:
    args = sys.argv[1:] or ["tests"]
    sys.exit(pytest.main(["-p", "ephematest.plugin", *args]))


if __name__ == "__main__":
    main()
