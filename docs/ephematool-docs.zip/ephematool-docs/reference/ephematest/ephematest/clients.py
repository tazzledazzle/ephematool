"""HTTP clients: platform API (with the fake-GitHub OAuth dance) and observability backends."""
from __future__ import annotations
import time
import urllib.parse
from dataclasses import dataclass
from typing import Any, Callable

import requests

from .config import Settings

SESSION_COOKIE = "ephematool_session"


class LoginDenied(Exception):
    """Raised when sign-in ends in /denied (non-member)."""


@dataclass
class Resp:
    status: int
    headers: dict[str, str]
    body: Any
    text: str
    elapsed: float

    @property
    def trace_id(self) -> str:
        return self.headers.get("x-trace-id", "")


class ApiClient:
    """One cookie jar == one browser session. Redirects are never followed implicitly."""

    def __init__(self, settings: Settings, login: str | None = None):
        self.s = settings
        self.http = requests.Session()
        self.login_name = login

    # ---- raw -------------------------------------------------------------------------
    def request(self, method: str, path: str, *, json: Any = None, headers: dict | None = None,
                follow: bool = False, params: dict | None = None, data: Any = None) -> Resp:
        url = path if path.startswith("http") else self.s.api_url + path
        t0 = time.time()
        r = self.http.request(method, url, json=json, headers=headers, params=params, data=data,
                              allow_redirects=follow, timeout=self.s.http_timeout)
        try:
            body = r.json()
        except ValueError:
            body = None
        return Resp(r.status_code, {k.lower(): v for k, v in r.headers.items()}, body, r.text, time.time() - t0)

    def get(self, path: str, **kw) -> Resp: return self.request("GET", path, **kw)
    def post(self, path: str, **kw) -> Resp: return self.request("POST", path, **kw)
    def delete(self, path: str, **kw) -> Resp: return self.request("DELETE", path, **kw)

    # ---- login (mirrors scripts/lib/verify-lib.sh ensure_session) ----------------------
    def login(self, login: str | None = None) -> "ApiClient":
        login = login or self.login_name
        r = self.get("/api/auth/github/login")
        loc = r.headers.get("location")
        assert r.status in (302, 303, 307) and loc, f"login start must redirect, got {r.status}"
        r2 = requests.get(f"{loc}&login={login}" if "?" in loc else f"{loc}?login={login}",
                          allow_redirects=False, timeout=self.s.http_timeout)
        cb = r2.headers.get("location", "")
        assert cb, "fake GitHub returned no callback Location"
        cb_path = urllib.parse.urlsplit(cb)
        cb_rel = cb_path.path + ("?" + cb_path.query if cb_path.query else "")
        r3 = self.get(cb_rel)
        dest = r3.headers.get("location", "")
        if dest.startswith("/denied"):
            raise LoginDenied(login)
        assert SESSION_COOKIE in self.http.cookies.get_dict(), "no session cookie after callback"
        self.login_name = login
        return self

    @property
    def session_cookie(self) -> str:
        return self.http.cookies.get_dict().get(SESSION_COOKIE, "")

    # ---- environments (Phase 2+) -----------------------------------------------------
    def create_env(self, *, repo: str | None = None, ref: str | None = None, template: str | None = None,
                   ttl_seconds: int | None = None, values: dict | None = None,
                   idem_key: str | None = None) -> Resp:
        body: dict[str, Any] = {"repo": repo or self.s.allowed_repo, "ref": ref or self.s.ref,
                                "template": template or self.s.template}
        if ttl_seconds is not None: body["ttl_seconds"] = ttl_seconds
        if values is not None: body["values"] = values
        h = {"Idempotency-Key": idem_key} if idem_key else None
        return self.post("/api/environments", json=body, headers=h)

    def wait_state(self, env_id: str, want: Callable[[str], bool] | set[str], timeout: float | None = None) -> dict:
        timeout = timeout or self.s.provision_timeout
        pred = want if callable(want) else (lambda st: st in want)
        deadline, last = time.time() + timeout, None
        while time.time() < deadline:
            r = self.get(f"/api/environments/{env_id}")
            if r.status == 200 and isinstance(r.body, dict):
                last = r.body
                if pred(last.get("state", "")):
                    return last
            time.sleep(0.25)
        raise TimeoutError(f"env {env_id} did not reach wanted state in {timeout}s (last={last})")


class Obs:
    """Tempo / Loki / Prometheus query helpers with the same query shapes as verify-lib.sh."""

    def __init__(self, s: Settings):
        self.s = s

    def _get(self, url: str, **kw):
        return requests.get(url, timeout=self.s.http_timeout, **kw)

    def poll(self, fn: Callable[[], Any], ok: Callable[[Any], bool], timeout: float | None = None, every: float = 1.0):
        deadline, last = time.time() + (timeout or self.s.obs_timeout), None
        while time.time() < deadline:
            try:
                last = fn()
                if ok(last):
                    return last
            except requests.RequestException:
                pass
            time.sleep(every)
        return last

    def tempo_services(self, trace_id: str) -> set[str]:
        r = self._get(f"{self.s.tempo_url}/api/traces/{trace_id}")
        if r.status_code != 200:
            return set()
        out: set[str] = set()
        for b in r.json().get("batches", []):
            for a in b.get("resource", {}).get("attributes", []):
                if a.get("key") == "service.name":
                    out.add(a["value"].get("stringValue", ""))
        return out

    def tempo_raw(self, trace_id: str) -> str:
        r = self._get(f"{self.s.tempo_url}/api/traces/{trace_id}")
        return r.text if r.status_code == 200 else ""

    def loki_lines(self, query: str, seconds: int = 300, limit: int = 1000) -> list[str]:
        now = int(time.time())
        r = self._get(f"{self.s.loki_url}/loki/api/v1/query_range", params={
            "query": query, "start": f"{now - seconds}000000000", "end": f"{now}000000000", "limit": limit})
        if r.status_code != 200:
            return []
        return [v[1] for st in r.json().get("data", {}).get("result", []) for v in st.get("values", [])]

    def prom_value(self, query: str) -> float | None:
        r = self._get(f"{self.s.prom_url}/api/v1/query", params={"query": query})
        if r.status_code != 200:
            return None
        res = r.json().get("data", {}).get("result", [])
        return float(res[0]["value"][1]) if res else None
