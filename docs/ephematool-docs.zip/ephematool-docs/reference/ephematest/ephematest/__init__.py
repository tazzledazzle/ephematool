"""ephematest: conformance test tool for Ephematool."""
__version__ = "0.1.0"
