"""Environment-driven settings. Every URL mirrors a variable used by scripts/lib/verify-lib.sh."""
from __future__ import annotations
import os
from dataclasses import dataclass, field


def _env(name: str, default: str) -> str:
    return os.environ.get(name, default).rstrip("/")


@dataclass
class Settings:
    api_url: str = field(default_factory=lambda: _env("API_URL", "http://localhost:8080"))
    tempo_url: str = field(default_factory=lambda: _env("TEMPO_URL", "http://localhost:3200"))
    loki_url: str = field(default_factory=lambda: _env("LOKI_URL", "http://localhost:3100"))
    prom_url: str = field(default_factory=lambda: _env("PROM_URL", "http://localhost:9090"))
    grafana_url: str = field(default_factory=lambda: _env("GRAFANA_URL", "http://localhost:3000"))
    collector_health_url: str = field(default_factory=lambda: _env("COLLECTOR_HEALTH_URL", "http://localhost:13133"))
    # Users seeded by cmd/fakegithub (admin / viewer / outsider). Override for a real IdP.
    admin_login: str = field(default_factory=lambda: os.environ.get("EPHEMA_ADMIN_LOGIN", "octo-admin"))
    viewer_login: str = field(default_factory=lambda: os.environ.get("EPHEMA_VIEWER_LOGIN", "octo-viewer"))
    outsider_login: str = field(default_factory=lambda: os.environ.get("EPHEMA_OUTSIDER_LOGIN", "octo-outsider"))
    # Repo allowed by ALLOWED_REPOS and one that is not.
    allowed_repo: str = field(default_factory=lambda: os.environ.get("EPHEMA_ALLOWED_REPO", "tazzledazzle/sampleapp"))
    denied_repo: str = field(default_factory=lambda: os.environ.get("EPHEMA_DENIED_REPO", "evil/notallowed"))
    template: str = field(default_factory=lambda: os.environ.get("EPHEMA_TEMPLATE", "sampleapp"))
    ref: str = field(default_factory=lambda: os.environ.get("EPHEMA_REF", "main"))
    compose_file: str = field(default_factory=lambda: os.environ.get("EPHEMA_COMPOSE_FILE", "deploy/compose.yaml"))
    repo_root: str = field(default_factory=lambda: os.environ.get("EPHEMA_REPO_ROOT", ""))
    # Contract knobs so the suite can be pointed at the real implementation (see SPEC-05 "Contract alignment").
    env_id_pattern: str = field(default_factory=lambda: os.environ.get("EPHEMA_ENV_ID_RE", r"^[a-z0-9][a-z0-9-]{2,62}$"))
    preview_gate_path: str = field(default_factory=lambda: os.environ.get("EPHEMA_PREVIEW_GATE_PATH", "/preview/auth"))
    # Seconds to wait for async state transitions (provisioning takes minutes on real kind).
    provision_timeout: float = field(default_factory=lambda: float(os.environ.get("EPHEMA_PROVISION_TIMEOUT", "30")))
    obs_timeout: float = field(default_factory=lambda: float(os.environ.get("EPHEMA_OBS_TIMEOUT", "45")))
    http_timeout: float = field(default_factory=lambda: float(os.environ.get("EPHEMA_HTTP_TIMEOUT", "10")))
    # Concurrency quota the server is configured with (ENV_MAX_PER_USER); used by quota tests.
    max_per_user: int = field(default_factory=lambda: int(os.environ.get("EPHEMA_MAX_PER_USER", "3")))
    # Optional: expected maximum TTL (seconds) the server enforces.
    max_ttl: int = field(default_factory=lambda: int(os.environ.get("EPHEMA_MAX_TTL", "86400")))
    # Names of secrets that must never appear in telemetry.
    secret_needles: list[str] = field(default_factory=lambda: [
        s for s in os.environ.get("EPHEMA_SECRET_NEEDLES", "e2e-secret").split(",") if s])


SETTINGS = Settings()
