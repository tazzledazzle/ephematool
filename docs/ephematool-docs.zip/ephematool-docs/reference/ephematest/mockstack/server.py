"""Single-process mock of the Ephematool platform (API + fake GitHub + Tempo/Loki/Prometheus).

Purpose: let ephematest be developed and self-tested without Docker/kind/Go. It implements the
contract in SPEC-05 and can inject named faults (MOCK_FAULTS=a,b) so we can prove each test
actually detects the bug it is meant to detect. It is NOT a reference implementation.

Run:  python -m mockstack.server --port 18080 --phase 7 --faults regress_state,quota_off
"""
from __future__ import annotations
import argparse, json, re, secrets, threading, time, uuid
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit

USERS = {"octo-admin": "admin", "octo-viewer": "viewer"}          # octo-outsider is not a member
ALLOWED_REPOS = {"tazzledazzle/sampleapp"}
TEMPLATES = {"sampleapp"}
MAX_PER_USER, MAX_TTL, MIN_TTL, DEFAULT_TTL = 3, 86400, 1, 3600
SERVICE_IDS = ["api", "worker", "dashboard", "postgres", "redis", "otel-collector", "tempo", "loki", "prometheus", "grafana"]
SECRET_KEY_RE = re.compile(r"(secret|password|token|apikey|api_key|private)", re.I)
SEC_HEADERS = {"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY",
               "Referrer-Policy": "same-origin", "Cache-Control": "no-store"}


class State:
    def __init__(self, phase: int, faults: set[str], max_per_user: int = MAX_PER_USER):
        self.phase, self.faults, self.max_per_user = phase, faults, max_per_user
        self.lock = threading.RLock()
        self.sessions: dict[str, str] = {}          # token -> login
        self.oauth_states: dict[str, str] = {}
        self.envs: dict[str, dict] = {}
        self.events: list[dict] = []
        self.idem: dict[tuple[str, str], str] = {}
        self.traces: dict[str, dict] = {}
        self.logs: list[tuple[float, str]] = []
        self.status_hits = 0
        self.tasks = 0
        threading.Thread(target=self._tick, daemon=True).start()

    # ---- audit / state machine -------------------------------------------------------
    def emit(self, env: dict, to: str, actor: str, action: str):
        with self.lock:
            frm = env["state"]; env["state"] = to
            if to == "destroying": env["_destroy_at"] = time.time()
            self.events.append({"seq": len(self.events) + 1, "at": time.time(), "actor": actor, "action": action,
                                "env_id": env["id"], "from": frm, "to": to})

    def _tick(self):
        while True:
            time.sleep(0.1)
            now = time.time()
            with self.lock:
                for e in list(self.envs.values()):
                    age = now - e["_created"]
                    st = e["state"]
                    if st == "requested" and age > 0.2:
                        self.emit(e, "provisioning", "system", "provision.start")
                    elif st == "provisioning" and age > 0.6:
                        if e["_fail"]:
                            self.emit(e, "failed", "system", "provision.fail")
                        else:
                            self.emit(e, "running", "system", "provision.ok")
                            e["url"] = f"http://env-{e['id']}.preview.localhost"
                            if "regress_state" in self.faults:     # BUG: goes backwards
                                self.emit(e, "provisioning", "system", "provision.retry")
                                self.emit(e, "running", "system", "provision.ok")
                    elif st == "running" and self.phase >= 5 and "ttl_ignored" not in self.faults and now >= e["_expires"]:
                        self.emit(e, "destroying", "system", "ttl.expired")
                    elif st == "destroying" and now - e["_destroy_at"] > 0.3:
                        self.emit(e, "destroyed", "system", "destroy.ok")

    # ---- observability stores --------------------------------------------------------
    def register_trace(self, tid: str, services: set[str], leak: str = ""):
        with self.lock:
            self.traces[tid] = {"services": services, "leak": leak}

    def log(self, tid: str, msg: str, svc="ephematool-api", **kv):
        line = json.dumps({"msg": msg, "trace_id": tid, "service_name": svc, **kv})
        with self.lock:
            self.logs.append((time.time(), line))


def public(e: dict, hide_secrets=True) -> dict:
    out = {k: v for k, v in e.items() if not k.startswith("_")}
    if hide_secrets:
        out["values"] = {k: ("[redacted]" if SECRET_KEY_RE.search(k) else v) for k, v in e["values"].items()}
    return out


def make_handler(st: State):
    class H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        def log_message(self, *a): pass

        # ---- plumbing ----------------------------------------------------------------
        def _send(self, code: int, body=None, headers: dict | None = None, raw: str | None = None):
            data = (raw if raw is not None else (json.dumps(body) if body is not None else "")).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            if "no_trace_header" not in st.faults and self.path.startswith("/api"):
                self.send_header("X-Trace-Id", self.tid)
            if "no_security_headers" not in st.faults:
                for k, v in SEC_HEADERS.items(): self.send_header(k, v)
            for k, v in (headers or {}).items():
                if isinstance(v, list):
                    for i in v: self.send_header(k, i)
                else: self.send_header(k, v)
            self.end_headers()
            self.wfile.write(data)

        def _json(self):
            if not self._body: return {}
            try: return json.loads(self._body)
            except ValueError: return None

        def _login(self):
            c = SimpleCookie(self.headers.get("Cookie", ""))
            tok = c.get("ephematool_session")
            return (st.sessions.get(tok.value), tok.value) if tok and tok.value in st.sessions else (None, "")

        def _err(self, code, msg): self._send(code, {"error": msg, "status": code})

        def handle_any(self, method: str):
            u = urlsplit(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
            self.tid = uuid.uuid4().hex
            # Always drain the body up front: leaving it unread corrupts the next keep-alive request.
            self._body = self.rfile.read(int(self.headers.get("Content-Length") or 0))
            p = u.path
            who, tok = self._login()
            try:
                if p.startswith(("/tempo", "/loki", "/prom")): return self.obs(p, q)
                if p.startswith("/fakegh/authorize"): return self.fakegh(q)
                if p == "/preview/auth": return self.preview_gate()
                st.register_trace(self.tid, {"ephematool-api"} | ({"ephematool-worker"} if p == "/api/status" else set()),
                                  leak=(f"cookie: ephematool_session={tok}" if "leak_secret" in st.faults and tok else ""))
                st.log(self.tid, f"{method} {p}")
                return self.route(method, p, q, who, tok)
            except BrokenPipeError:
                pass
            except Exception as ex:   # mock bug => 500 so tests show it
                self._err(500, repr(ex))

        do_GET = lambda s: s.handle_any("GET")
        do_POST = lambda s: s.handle_any("POST")
        do_DELETE = lambda s: s.handle_any("DELETE")
        do_PUT = lambda s: s.handle_any("PUT")
        do_PATCH = lambda s: s.handle_any("PATCH")

        # ---- fake GitHub ---------------------------------------------------------------
        def fakegh(self, q):
            self._send(302, headers={"Location": f"/api/auth/github/callback?code={q.get('login','')}&state={q.get('state','')}"})

        # ---- routes --------------------------------------------------------------------
        def route(self, m, p, q, who, tok):
            if p in ("/healthz", "/readyz") and m == "GET": return self._send(200, {"status": "ok"})
            if p == "/api/auth/config": return self._send(200, {"provider": "github", "login_url": "/api/auth/github/login"})
            if p == "/api/auth/github/login":
                state = secrets.token_hex(8)
                st.oauth_states[state] = q.get("next", "/")
                return self._send(302, headers={"Location": f"http://{self.headers['Host']}/fakegh/authorize?state={state}"})
            if p == "/api/auth/github/callback":
                nxt = st.oauth_states.pop(q.get("state", ""), None)
                if nxt is None: return self._err(400, "bad state")
                login = q.get("code", "")
                if login not in USERS:
                    st.log(self.tid, "auth.denied", login=login)
                    return self._send(302, headers={"Location": "/denied?reason=not_member"})
                t = secrets.token_hex(16); st.sessions[t] = login
                safe = nxt if (nxt.startswith("/") and not nxt.startswith("//") and "\\" not in nxt) or "open_redirect" in st.faults else "/"
                return self._send(302, headers={"Location": safe, "Set-Cookie": f"ephematool_session={t}; Path=/; HttpOnly; SameSite=Lax"})
            if p == "/api/auth/logout" and m == "POST":
                st.sessions.pop(tok, None)
                return self._send(204, headers={"Set-Cookie": "ephematool_session=; Path=/; Max-Age=0"})
            if p == "/api/me":
                if not who: return self._err(401, "unauthenticated")
                return self._send(200, {"login": who, "role": USERS[who]})
            if p == "/api/status":
                if not who: return self._err(401, "unauthenticated")
                st.status_hits += 1; st.tasks += 1
                ids = list(SERVICE_IDS)
                if "status_wrong_order" in st.faults: ids[0], ids[1] = ids[1], ids[0]
                st.log(self.tid, "worker ping", svc="ephematool-worker")
                return self._send(200, {"services": [{"id": i, "status": "healthy", "detail": ""} for i in ids]})
            if p == "/api/orphans" and st.phase >= 3:
                if not who: return self._err(401, "unauthenticated")
                return self._send(200, {"orphans": []}) if USERS[who] == "admin" else self._err(403, "admin only")
            if p.startswith("/api/environments") or p.startswith("/api/audit"):
                if st.phase < 2: return self._err(404, "not implemented")
                return self.envs(m, p, q, who)
            return self._err(404, "not found")

        # ---- environments --------------------------------------------------------------
        def envs(self, m, p, q, who):
            if p.startswith("/api/audit"): return self.audit(m, p, q, who)
            create_open = "no_auth_on_create" in st.faults
            if not who and not (m == "POST" and p == "/api/environments" and create_open):
                return self._err(401, "unauthenticated")
            who = who or "octo-admin"
            role = USERS[who]
            parts = p.strip("/").split("/")          # api environments [id [sub]]
            if p == "/api/environments" and m == "POST": return self.create(who, role)
            if p == "/api/environments" and m == "GET": return self.list_envs(q)
            if len(parts) >= 3:
                env = st.envs.get(parts[2])
                if not env: return self._err(404, "no such environment")
                sub = parts[3] if len(parts) > 3 else ""
                if sub == "" and m == "GET": return self._send(200, public(env, "echo_secrets" not in st.faults))
                if sub == "events" and m == "GET":
                    return self._send(200, {"events": [e for e in st.events if e["env_id"] == env["id"]]})
                if sub == "health" and m == "GET" and st.phase >= 4:
                    return self._send(200, {"state": env["state"], "healthy": env["state"] == "running",
                                            "signals": {"workflow": env["state"] != "failed", "probe": env["state"] == "running"}})
                if sub == "links" and m == "GET" and st.phase >= 6:
                    return self._send(200, {"grafana": f"http://grafana/d/env?var-env={env['id']}", "traces": f"http://grafana/explore?env={env['id']}"})
                if sub == "preview-link" and m == "POST":
                    if env["state"] != "running": return self._err(409, "environment not running")
                    return self._send(200, {"url": env["url"], "token": env["_ptoken"]})
                if sub == "" and m == "DELETE" and st.phase >= 3:
                    if role != "admin" and env["owner"] != who and "delete_any" not in st.faults:
                        return self._err(403, "not owner")
                    if env["state"] in ("destroying", "destroyed"): return self._send(202, public(env))
                    st.emit(env, "destroying", who, "destroy.request"); env["_destroy_at"] = time.time()
                    return self._send(202, public(env))
                if sub == "extend" and m == "POST" and st.phase >= 5:
                    body = self._json() or {}
                    add = body.get("ttl_seconds", 0)
                    if not isinstance(add, int) or add <= 0 or env["ttl_seconds"] + add > MAX_TTL: return self._err(422, "bad ttl")
                    env["ttl_seconds"] += add; env["_expires"] += add
                    env["ttl_expires_at"] = env["_expires"]
                    st.events.append({"seq": len(st.events) + 1, "at": time.time(), "actor": who, "action": "ttl.extend",
                                      "env_id": env["id"], "from": env["state"], "to": env["state"]})
                    return self._send(200, public(env))
            return self._err(404, "not found")

        def create(self, who, role):
            if role == "viewer" and "viewer_can_create" not in st.faults: return self._err(403, "viewer role is read-only")
            b = self._json()
            if not isinstance(b, dict): return self._err(400, "invalid json")
            repo, tmpl, ref = b.get("repo"), b.get("template"), b.get("ref")
            if not all(isinstance(x, str) and x for x in (repo, tmpl, ref)): return self._err(422, "repo, ref, template required")
            if repo not in ALLOWED_REPOS and "allowlist_off" not in st.faults: return self._err(403, "repo not allowed")
            if tmpl not in TEMPLATES: return self._err(422, "unknown template")
            ttl = b.get("ttl_seconds", DEFAULT_TTL)
            if not isinstance(ttl, int) or isinstance(ttl, bool) or ttl < MIN_TTL: return self._err(422, "ttl too small")
            if ttl > MAX_TTL and "no_ttl_cap" not in st.faults: return self._err(422, "ttl too large")
            values = b.get("values", {})
            if not isinstance(values, dict): return self._err(422, "values must be an object")
            for v in values.values():
                if isinstance(v, dict) and "secretRef" in v and v["secretRef"] not in {"sampleapp-db"}:
                    return self._err(403, "secret not in scope")
            if any(SECRET_KEY_RE.search(k) for k in values) and "echo_secrets" not in st.faults and "plain_secrets" not in st.faults:
                return self._err(422, "secret-looking keys are not allowed in values")
            idem = self.headers.get("Idempotency-Key")
            with st.lock:
                if idem and (who, idem) in st.idem and "idempotency_broken" not in st.faults:
                    return self._send(200, public(st.envs[st.idem[(who, idem)]]))
                active = [e for e in st.envs.values() if e["owner"] == who and e["state"] not in ("failed", "destroyed")]
                if len(active) >= st.max_per_user and "quota_off" not in st.faults:
                    return self._send(429, {"error": "quota exceeded", "status": 429, "limit": st.max_per_user, "active": len(active)}, headers={"Retry-After": "5"})
                eid = secrets.token_hex(4); now = time.time()
                env = {"id": eid, "state": "requested", "owner": who, "repo": repo, "ref": ref, "template": tmpl,
                       "ttl_seconds": ttl, "ttl_expires_at": now + ttl, "url": None, "values": values, "created_at": now,
                       "_created": now, "_expires": now + ttl, "_fail": bool(values.get("fail")), "_ptoken": secrets.token_hex(12)}
                st.envs[eid] = env
                st.events.append({"seq": len(st.events) + 1, "at": now, "actor": who, "action": "env.create",
                                  "env_id": eid, "from": None, "to": "requested"})
                if idem: st.idem[(who, idem)] = eid
            return self._send(202, public(env, "echo_secrets" not in st.faults), headers={"Location": f"/api/environments/{eid}"})

        def list_envs(self, q):
            items = [public(e) for e in sorted(st.envs.values(), key=lambda e: e["created_at"])]
            if st.phase >= 3:
                if "state" in q: items = [i for i in items if i["state"] == q["state"]]
                if "owner" in q: items = [i for i in items if i["owner"] == q["owner"]]
                lim = int(q.get("limit", 50)); off = int(q.get("cursor", 0))
                page = items[off:off + lim]
                nxt = str(off + lim) if off + lim < len(items) else None
                return self._send(200, {"environments": page, "next_cursor": nxt})
            return self._send(200, {"environments": items})

        def audit(self, m, p, q, who):
            if not who: return self._err(401, "unauthenticated")
            if USERS[who] != "admin": return self._err(403, "admin only")
            if m == "GET" and p == "/api/audit": return self._send(200, {"events": list(st.events)})
            if m in ("PUT", "PATCH", "DELETE", "POST"):
                if "audit_mutable" in st.faults:
                    if m == "DELETE" and st.events: st.events.pop(); return self._send(204)
                return self._err(405, "audit log is append-only")
            return self._err(404, "not found")

        def preview_gate(self):
            host = self.headers.get("X-Forwarded-Host", ""); tokh = self.headers.get("X-Preview-Token", "")
            mt = re.match(r"env-([0-9a-f]+)\.", host)
            if "preview_gate_open" in st.faults: return self._send(200, {"ok": True})
            if not mt or mt.group(1) not in st.envs: return self._send(404, {"error": "unknown env"})
            if not tokh: return self._send(401, {"error": "token required"})
            return self._send(200, {"ok": True}) if tokh == st.envs[mt.group(1)]["_ptoken"] else self._send(403, {"error": "wrong env token"})

        # ---- fake Tempo / Loki / Prometheus --------------------------------------------
        def obs(self, p, q):
            if p.endswith(("/ready", "/-/ready")): return self._send(200, raw="ready")
            if p.startswith("/tempo/api/traces/"):
                t = st.traces.get(p.rsplit("/", 1)[1])
                if not t: return self._send(404, {"error": "not found"})
                attrs = [{"key": "service.name", "value": {"stringValue": s}} for s in t["services"]]
                span_attrs = [{"key": "http.route", "value": {"stringValue": "/api/status"}}]
                if t["leak"]: span_attrs.append({"key": "http.request.header.cookie", "value": {"stringValue": t["leak"]}})
                return self._send(200, {"batches": [{"resource": {"attributes": attrs}, "scopeSpans": [{"spans": [{"name": "x", "attributes": span_attrs}]}]}]})
            if p.startswith("/loki/loki/api/v1/query_range"):
                query = q.get("query", "")
                tid = re.search(r'trace_id="([0-9a-f]+)"', query)
                svc = re.search(r'service_name="([^"]+)"', query)
                out = []
                for ts, line in st.logs:
                    d = json.loads(line)
                    if tid and d["trace_id"] != tid.group(1): continue
                    if svc and d["service_name"] != svc.group(1): continue
                    if "auth.denied" in query and d["msg"] != "auth.denied": continue
                    out.append([str(int(ts * 1e9)), line])
                return self._send(200, {"data": {"result": [{"values": out}] if out else []}})
            if p.startswith("/prom/api/v1/query"):
                qq = q.get("query", "")
                val = st.status_hits if "http_server_request_duration_seconds_count" in qq else st.tasks if "queue_task_processed_total" in qq else None
                return self._send(200, {"data": {"result": [{"value": [time.time(), str(val)]}] if val else []}})
            return self._err(404, "not found")
    return H


class QuietServer(ThreadingHTTPServer):
    daemon_threads = True
    def handle_error(self, request, client_address): pass     # client aborts are not mock bugs


def serve(port: int, phase: int, faults: set[str], max_per_user: int = 1000) -> ThreadingHTTPServer:
    srv = QuietServer(("127.0.0.1", port), make_handler(State(phase, faults, max_per_user)))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=18080); ap.add_argument("--phase", type=int, default=7)
    ap.add_argument("--faults", default=""); ap.add_argument("--max-per-user", type=int, default=1000)
    a = ap.parse_args()
    serve(a.port, a.phase, {f for f in a.faults.split(",") if f}, a.max_per_user)
    print(f"mock listening on :{a.port} phase={a.phase} faults={a.faults or '-'}", flush=True)
    while True: time.sleep(3600)
