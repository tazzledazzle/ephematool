# ephematest

Conformance test tool for Ephematool (black-box API + observability + repo + ops).

## Install & run
    python -m venv .venv && . .venv/bin/activate && pip install -e .
    # against a running docker-compose stack (bazel run //:up_fake), Phase 1 only:
    ephematest tests --expect-phase 1 --repo-root ../ephematool
    # full productionized target:
    ephematest tests --expect-phase 7 --repo-root ../ephematool
    # quota tests need a stack with a LOW ENV_MAX_PER_USER (= EPHEMA_MAX_PER_USER):
    EPHEMA_MAX_PER_USER=3 ephematest tests --quota-mode
    # prove the tests themselves work (no Docker needed):
    python selftest.py

## Semantics
* `--expect-phase N`: tests marked phase<=N must pass; later ones are non-strict xfail. An XPASS means the
  feature landed early: bump the number.
* Missing docker/kubectl/obs/repo capability **fails** the test (never skips). `--allow-missing-caps` downgrades to xfail.
* Env vars: API_URL TEMPO_URL LOKI_URL PROM_URL EPHEMA_* (see ephematest/config.py).
