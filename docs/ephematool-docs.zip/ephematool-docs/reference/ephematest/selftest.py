"""Prove the tests detect what they claim to: run the suite against the mock with no faults (must pass),
then once per injected fault (the designated detector tests must fail).
Usage: python selftest.py [--phase N]"""
from __future__ import annotations
import ast, subprocess, sys, os, re, time, argparse
from pathlib import Path
import threading
from mockstack.server import serve

HERE = Path(__file__).parent
FAULT_RE = re.compile(r'pytest\.mark\.fault\("([a-z_]+)"\)')


def all_faults() -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    for f in (HERE / "tests").glob("test_*.py"):
        for m in FAULT_RE.finditer(f.read_text()):
            out.setdefault(m.group(1), []).append(f.name)
    return out


def run(port: int, phase: int, extra: list[str], quota: bool = False) -> tuple[int, str]:
    env = {**os.environ, "API_URL": f"http://127.0.0.1:{port}", "TEMPO_URL": f"http://127.0.0.1:{port}/tempo",
           "LOKI_URL": f"http://127.0.0.1:{port}/loki", "PROM_URL": f"http://127.0.0.1:{port}/prom",
           "EPHEMA_MAX_PER_USER": "3", "EPHEMA_PROVISION_TIMEOUT": "15", "EPHEMA_OBS_TIMEOUT": "5"}
    p = subprocess.run([sys.executable, "-m", "pytest", "tests", "-q", "--expect-phase", str(phase),
                        "--allow-missing-caps", *(["--quota-mode"] if quota else []), "-p", "no:cacheprovider", *extra], capture_output=True, text=True, cwd=HERE, env=env)
    return p.returncode, p.stdout + p.stderr


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--phase", type=int, default=7)
    a = ap.parse_args()
    ok = True
    for label, port, quota in (("general", 18100, False), ("quota-mode", 18099, True)):
        srv = serve(port, a.phase, set(), 3 if quota else 1000)
        rc, out = run(port, a.phase, [], quota)
        print(f"BASELINE {label} (no faults):", next(l for l in reversed(out.splitlines()) if " passed" in l or " failed" in l)); srv.shutdown()
        if rc != 0: print(out[-3000:]); ok = False
    for i, (fault, _) in enumerate(sorted(all_faults().items())):
        port = 18101 + i
        quota = fault == "quota_off"
        srv = serve(port, a.phase, {fault}, 3 if quota else 1000)
        rc, out = run(port, a.phase, ["-m", "fault"], quota)
        failed = [l for l in out.splitlines() if l.startswith("FAILED")]
        detected = rc != 0 and bool(failed)
        print(f"fault {fault:22s} -> {'DETECTED' if detected else 'MISSED  <<<<'} ({len(failed)} failing)")
        ok &= detected; srv.shutdown()
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
