# ADR-0003: Enforce concurrency quotas with transaction-scoped advisory locks

Date: 2026-10-20
Status: Accepted
Spec: `.internal/specs/2026-10-20-ephematool-completion-and-productionization-design.md` (section 5.6)

## Context
GRD-02 says a create attempt is rejected "even when two requests race". A count-then-insert check is not atomic. Quotas apply per user, per repo and per team, so one INSERT cannot be guarded by one unique constraint.

## Decision
- The create transaction takes `pg_advisory_xact_lock(hashtextextended(key, 0))` for each applicable scope key, in sorted order (`quota.LockKeys`), counts active environments per scope, runs the pure `quota.Decide`, and inserts the environment and its audit row, then commits.
- All external validation (GitHub sha resolution, fork check, team membership, GHCR manifest) happens before the transaction, so no lock is held across a network call. The transaction sets `lock_timeout = '2s'`; timeout returns 503 with `Retry-After`.
- A scope counts every environment that is not `destroyed`, including `failed`: a failed environment still occupies a namespace until destroyed. Failed environments are given a short expiry (`FAILED_RETENTION`, default 2h) so they free their slot automatically after diagnostics are snapshotted.
- Rejection is 429 with `Retry-After` and a body naming scope, limit, active count and the soonest expiry.

## Rationale
Advisory locks serialise exactly the contending creators and nothing else, need no extra tables, and release on commit or rollback. Sorted acquisition rules out deadlocks.

## Consequences
- Creates for the same user/repo/team are serialised; at the expected create rate this is negligible, and the lock excludes slow work.
- Hash collisions between unrelated keys only over-serialise; they never admit extra environments.
- Verified on Postgres 16, 12 concurrent creators, limit 3: 3 rows with the lock, 11 without. `lock_timeout` behaviour is not yet exercised and is covered by Plan 3's quota task.
- A load test in quota mode (`ephematest --quota-mode`) is the regression gate.
