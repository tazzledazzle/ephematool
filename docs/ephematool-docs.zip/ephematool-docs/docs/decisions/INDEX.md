# Decision Index

| ADR | Title | Date | Status |
|---|---|---|---|
| [ADR-0001](ADR-0001-cas-only-forward-state-machine.md) | Environment state changes only through a forward-only compare-and-set | 2026-10-20 | Accepted |
| [ADR-0002](ADR-0002-database-enforced-append-only-audit.md) | Enforce the append-only audit log in the database, and verify privileges at runtime | 2026-10-20 | Accepted |
| [ADR-0003](ADR-0003-atomic-quotas-with-advisory-locks.md) | Enforce concurrency quotas with transaction-scoped advisory locks | 2026-10-20 | Accepted |
| [ADR-0004](ADR-0004-webhooks-are-hints-reconciler-is-truth.md) | Webhooks are hints; a polling reconciler is the source of convergence | 2026-10-20 | Accepted |
| [ADR-0005](ADR-0005-phase-gated-conformance-suite-as-ci-gate.md) | Gate CI on a phase-gated, self-verifying conformance suite | 2026-10-20 | Accepted |
