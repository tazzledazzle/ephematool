# ADR-0004: Webhooks are hints; a polling reconciler is the source of convergence

Date: 2026-10-20
Status: Accepted
Spec: `.internal/specs/2026-10-20-ephematool-completion-and-productionization-design.md` (section 5.2)

## Context
Roadmap Phase 3 SC2 requires state to converge "after a missed webhook". GitHub webhooks can be dropped, delayed, duplicated or reordered, and deliveries during an outage are not retried automatically. Phase 5 also needs PR close to destroy an environment, which is naturally webhook-driven.

## Decision
- The webhook endpoint (`POST /webhooks/github`) verifies the HMAC, caps the body at 1 MiB, allows only `pull_request`, `workflow_run` and `ping`, de-duplicates on `X-GitHub-Delivery`, and only enqueues `env:reconcile` or `env:destroy`. It never changes state itself.
- The reconciler runs on a sweep interval and on startup for every non-terminal environment, polling the run and PR state with conditional requests (ETag), and is the only component that decides `provisioning → running|failed` from GitHub facts.
- Webhooks therefore reduce latency; their loss increases it to one sweep interval and nothing else.
- The GitHub REST API version is pinned (`X-GitHub-Api-Version`) and dispatch handling accepts both the 204 (no run id) and run-details responses, with run-name correlation as the fallback (plan decision D-15).

## Rationale
A system whose correctness depends on delivery of external events cannot meet "no environment lingers". Making the safety net the primary mechanism and the events an optimisation keeps the failure mode benign.

## Consequences
- GitHub API budget is spent on polling; conditional requests answered with 304 are documented as not counting against the primary rate limit, to be confirmed in spike S4.
- Time-to-ready includes up to one poll interval unless a webhook arrives first.
- Webhook secret rotation accepts two secrets for an overlap window.
