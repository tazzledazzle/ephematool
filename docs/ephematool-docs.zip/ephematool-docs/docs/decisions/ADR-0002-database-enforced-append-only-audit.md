# ADR-0002: Enforce the append-only audit log in the database, and verify privileges at runtime

Date: 2026-10-20
Status: Accepted
Spec: `.internal/specs/2026-10-20-ephematool-completion-and-productionization-design.md` (section 4)

## Context
AUTH-03 requires an audit trail of who created, extended and destroyed environments. An application-level "never update audit rows" convention fails the first time someone ships a fix-up query. Phase 2 plan 02-04 already chose two database roles, but the first draft granted privileges inside the migration only `IF EXISTS` the runtime role. In production the role is usually created after migrations run, so the grant silently skips and the app fails at runtime (reproduced on Postgres 16).

## Decision
- `audit_events` has `BEFORE UPDATE OR DELETE` and `BEFORE TRUNCATE` triggers that raise for every role, including the owner. The runtime role `ephematool_app` has `SELECT, INSERT` only; `environments` gets `SELECT, INSERT, UPDATE` and no `DELETE` (tombstones, not deletes).
- Migrations run as the owner role (`MIGRATE_DATABASE_URL`) and contain no grants.
- Grants live in `deploy/postgres/grants.sql`, idempotent, run after every migration (Helm post-upgrade hook and `bazel run //:up`).
- The API and worker call `store.CheckPrivileges` at startup and in `/readyz`: required privileges present, forbidden ones absent. A wrongly privileged role fails readiness, not a request three hours later.
- No foreign key from `audit_events.env_id` to `environments`, so the log outlives any environment row.

## Rationale
A trigger cannot be bypassed by a forgotten code path, and checking privileges at start turns a silent misconfiguration into a visible deploy failure.

## Consequences
- Tests cannot `TRUNCATE audit_events`; integration tests use one throwaway database per test.
- Retention is by partition drop (future work), not by `DELETE`.
- Verified on Postgres 16: app role gets `permission denied` for UPDATE/DELETE/TRUNCATE; the owner is blocked by the trigger; the privilege query returns `f,f,t,t,t,f,t` before grants and `t,t,t,t,t,t,t` after; grants apply twice without error.
