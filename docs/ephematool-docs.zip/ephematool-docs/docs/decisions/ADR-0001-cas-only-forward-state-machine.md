# ADR-0001: Environment state changes only through a forward-only compare-and-set

Date: 2026-10-20
Status: Accepted
Spec: `.internal/specs/2026-10-20-ephematool-completion-and-productionization-design.md` (section 4)

## Context
Six actors can change an environment's state: the create handler, the dispatch/poll worker, a GitHub webhook, the reconciler, the TTL reaper, and an SRE clicking destroy. Pitfalls research names three sources of truth (database, GitHub run, cluster) and TTL races as the main causes of orphaned namespaces. The database and Redis (asynq) cannot be updated in one transaction, so a state change can commit while its follow-up task is lost, or the reverse.

## Decision
- `environments.state` is written only by `envstate.Advance`, which validates the edge in a fixed forward-only graph and executes `UPDATE … SET state=$to … WHERE id=$1 AND state=$from`. Zero rows means `ErrLostRace`; callers re-read, never retry blindly.
- Columns tied to a state by a CHECK constraint travel in the same statement (`Patch{URL, FailureReason, RunID}`): `running` requires `url`.
- Every transition writes one `audit_events` row in the same transaction.
- No transactional outbox in v1. Lost or duplicated follow-up tasks are repaired by the reconciler, which re-enqueues work for rows stalled in `requested`, `provisioning` or `destroying`. Task ids equal `<kind>:<env-id>`, so duplicate enqueues are no-ops.
- Every state can reach `destroyed` (tested), so nothing can leak by construction.

## Rationale
A single choke point with optimistic concurrency makes races harmless without distributed locks, and the graph is small enough to test exhaustively. An outbox would close the lost-enqueue window but adds a poller and a table whose job the reconciler already does.

## Consequences
- A crash between COMMIT and enqueue delays progress by up to one sweep interval; this delay is an SLO input (spec section 6).
- Adding a state or edge is a code change plus a CHECK-constraint migration; both are covered by `envstate` tests and `test_environments_state_has_check_constraint`.
- If measured lost-enqueue rate or sweep latency becomes a problem, introduce the outbox behind the same `Store` interface.
- Verified: a 64-goroutine race yields exactly one winner (`go test -race ./envstate`); on Postgres, `state='running'` without `url` is rejected by the CHECK, which is why `Patch` exists.
