# ADR-0005: Gate CI on a phase-gated, self-verifying conformance suite

Date: 2026-10-20
Status: Accepted
Spec: `.internal/specs/2026-10-20-ephematool-completion-and-productionization-design.md` (section 7)

## Context
Phase 1 has strong bash verification scripts, but they cover only Phase 1, run only by hand, and Go integration tests skip silently without Docker (backlog #13). Seven phases will land incrementally, and an earlier phase must not regress while a later one is built. A test suite that has never been seen to fail also proves nothing.

## Decision
- Adopt `ephematest` (Python/pytest, `tools/ephematest/`) as the black-box, observability, repo and ops conformance suite.
- `--expect-phase N` makes tests for phases ≤ N mandatory and later ones non-strict xfail; CI sets N to the last completed phase and raises it in the same PR that completes a phase.
- A missing capability (docker, kubectl, observability, repo checkout) fails a test rather than skipping it.
- `selftest.py` runs the suite against a mock with one injected fault per designated detector test and fails CI if a fault is not detected.
- A contract-sync test requires `api/openapi.json` to contain every path `ephematest/clients.py` calls once the corresponding phase is expected.

## Rationale
Phase gating gives a ratchet; self-verification stops tests from rotting into always-green; failing on missing capabilities removes the quiet way for coverage to disappear.

## Consequences
- A second language (Python) in the repo's test tooling; contained under `tools/ephematest/` and run in its own CI job.
- Phase 2+ tests encode a contract written before the implementation exists; the contract-sync test and plan tasks reconcile them when each API lands.
- The mock must be kept faithful for the faults it models; adding a detector test means adding its fault.
- Verified: 73 passing at `--expect-phase 7` on the mock, 17 of 17 injected faults detected, and the repo tests find 8 real gaps in the current checkout.
